-- ============================================================
-- Crear la única tabla que el código NO crea automáticamente
-- ------------------------------------------------------------
-- 23 de las 24 tablas de grafiluz_db se crean solas la primera vez
-- que PHP ejecuta db-conexion.php / auth-admin.php / auth-cliente.php
-- (usan "CREATE TABLE IF NOT EXISTS"). Basta con visitar una vez:
--   1. tienda.php   -> crea clientes, pedidos, detalle_pedido, resenas,
--                      pagos, direcciones, cupones, favoritos,
--                      calificaciones_vendedor, carritos, carrito_items,
--                      notificaciones, comisiones, pagos_vendedor,
--                      movimientos_inventario, categorias,
--                      auditoria_admin, eventos_analitica,
--                      configuracion, tarifas_envio, producto_variantes,
--                      tokens_recuperacion
--   2. login.php    -> crea usuarios_admin_tb_baycodec
--
-- La única excepción es "productos_tb_baycodec": nunca tuvo un
-- CREATE TABLE en el código (se creaba a mano en phpMyAdmin desde antes
-- de la Sesión 8). Ejecuta esto UNA vez, después de visitar tienda.php
-- y login.php, para tenerla lista:
-- ============================================================

CREATE TABLE IF NOT EXISTS productos_tb_baycodec (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(60) NOT NULL UNIQUE,
    categoria VARCHAR(120) NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    medidas VARCHAR(120) DEFAULT NULL,
    material VARCHAR(120) DEFAULT NULL,
    colores VARCHAR(255) DEFAULT NULL,
    imagen_url VARCHAR(255) DEFAULT NULL,
    precio_referencial_pen DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock INT DEFAULT NULL,
    activo TINYINT(1) NOT NULL DEFAULT 1,
    vendedor_id INT DEFAULT NULL,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
