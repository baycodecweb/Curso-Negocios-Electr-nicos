<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// TARIFAS DE ENVÍO POR ZONA — mejora post-Sesión 8
// ------------------------------------------------------------
// Administra tarifas_envio (ver db-conexion.php); carrito.php lee las
// zonas activas para el selector al pagar, y crear-pedido.php vuelve
// a buscar el costo aquí por el nombre de la zona.
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

$errorFormulario_baycodec = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar') {
    $zona_baycodec = trim($_POST['zona'] ?? '');
    $costo_baycodec = str_replace(',', '.', trim($_POST['costo'] ?? ''));
    $diasEstimados_baycodec = trim($_POST['dias_estimados'] ?? '');
    $activo_baycodec = isset($_POST['activo']) ? 1 : 0;

    if ($zona_baycodec === '') {
        $errorFormulario_baycodec = 'El nombre de la zona es obligatorio.';
    } elseif (!is_numeric($costo_baycodec) || (float) $costo_baycodec < 0) {
        $errorFormulario_baycodec = 'El costo debe ser un número mayor o igual a 0.';
    } else {
        try {
            $pdo_baycodec->prepare('INSERT INTO tarifas_envio_tb_baycodec (zona, costo, dias_estimados, activo) VALUES (?, ?, ?, ?)')
                ->execute([$zona_baycodec, $costo_baycodec, $diasEstimados_baycodec, $activo_baycodec]);
            registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'crear_tarifa_envio', (int) $pdo_baycodec->lastInsertId(), $zona_baycodec);
            header('Location: admin-envios.php?guardado=1');
            exit;
        } catch (PDOException $error) {
            $errorFormulario_baycodec = str_contains($error->getMessage(), 'Duplicate')
                ? 'Ya existe una tarifa para esa zona.'
                : 'No se pudo guardar la tarifa.';
        }
    }
}

if (isset($_GET['alternar_activo'])) {
    $id_baycodec = (int) $_GET['alternar_activo'];
    $pdo_baycodec->prepare('UPDATE tarifas_envio_tb_baycodec SET activo = 1 - activo WHERE id = ?')->execute([$id_baycodec]);
    header('Location: admin-envios.php');
    exit;
}

if (isset($_GET['eliminar'])) {
    $id_baycodec = (int) $_GET['eliminar'];
    $pdo_baycodec->prepare('DELETE FROM tarifas_envio_tb_baycodec WHERE id = ?')->execute([$id_baycodec]);
    registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'eliminar_tarifa_envio', $id_baycodec);
    header('Location: admin-envios.php?eliminado=1');
    exit;
}

$tarifas_baycodec = $pdo_baycodec->query('SELECT * FROM tarifas_envio_tb_baycodec ORDER BY costo ASC')->fetchAll();

function v_env_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tarifas de Envío — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .btn_baycodec.peligro_baycodec { background: #fee2e2; color: #991b1b; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"], input[type="number"] { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .campos-en-fila_baycodec { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0 16px; }
  .checkbox-linea_baycodec { display: flex; align-items: center; gap: 8px; margin-top: 14px; }
  .checkbox-linea_baycodec input { width: auto; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; }
  th { background: #f3f4f6; }
  .fila-acciones_baycodec { display: flex; gap: 6px; }
  .fila-acciones_baycodec .btn_baycodec { font-size: 0.75rem; padding: 4px 8px; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .etiqueta-inactivo_baycodec { display: inline-block; background: #f3f4f6; color: #6b7280; border-radius: 10px; padding: 1px 8px; font-size: 0.72rem; }
</style>
</head>
<body>

<h1>🚚 Tarifas de Envío — Grafiluz</h1>
<p class="subtitulo_baycodec">Zonas que el cliente elige al pagar en <code>carrito.php</code>. Solo las zonas activas aparecen ahí.</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="admin-productos.php" style="background:#C41F25;">🛠️ Panel de Productos</a>
</div>

<?php if (isset($_GET['guardado'])): ?><p class="exito_baycodec">✅ Tarifa guardada.</p><?php endif; ?>
<?php if (isset($_GET['eliminado'])): ?><p class="exito_baycodec">🗑️ Tarifa eliminada.</p><?php endif; ?>
<?php if ($errorFormulario_baycodec): ?><p class="error_baycodec">⚠️ <?= v_env_baycodec($errorFormulario_baycodec) ?></p><?php endif; ?>

<h2 style="font-size:1.1rem;">➕ Agregar zona</h2>
<div class="caja_baycodec">
  <form method="post" action="admin-envios.php">
    <input type="hidden" name="accion" value="guardar">
    <div class="campos-en-fila_baycodec">
      <div>
        <label for="zona">Zona</label>
        <input type="text" id="zona" name="zona" placeholder="Ej: Cusco" required>
      </div>
      <div>
        <label for="costo">Costo (S/)</label>
        <input type="number" id="costo" name="costo" step="0.01" min="0" required>
      </div>
      <div>
        <label for="dias_estimados">Días estimados</label>
        <input type="text" id="dias_estimados" name="dias_estimados" placeholder="Ej: 3-5 días">
      </div>
    </div>
    <div class="checkbox-linea_baycodec">
      <input type="checkbox" id="activo" name="activo" checked>
      <label for="activo" style="margin:0;">Zona activa</label>
    </div>
    <button class="btn_baycodec" type="submit" style="margin-top:14px;">💾 Agregar zona</button>
  </form>
</div>

<h2 style="font-size:1.1rem;">Zonas (<?= count($tarifas_baycodec) ?>)</h2>
<table>
  <thead><tr><th>Zona</th><th>Costo</th><th>Días estimados</th><th>Estado</th><th style="width:150px">Acciones</th></tr></thead>
  <tbody>
    <?php if (empty($tarifas_baycodec)): ?>
      <tr><td colspan="5" class="vacio_baycodec">(sin zonas)</td></tr>
    <?php else: foreach ($tarifas_baycodec as $t_baycodec): ?>
      <tr>
        <td><?= v_env_baycodec($t_baycodec['zona']) ?></td>
        <td><?= (float) $t_baycodec['costo'] > 0 ? 'S/ ' . number_format((float) $t_baycodec['costo'], 2) : 'Gratis' ?></td>
        <td><?= v_env_baycodec($t_baycodec['dias_estimados']) ?: '—' ?></td>
        <td><?= $t_baycodec['activo'] ? 'Activa' : '<span class="etiqueta-inactivo_baycodec">Inactiva</span>' ?></td>
        <td class="fila-acciones_baycodec">
          <a class="btn_baycodec secundario_baycodec" href="admin-envios.php?alternar_activo=<?= (int) $t_baycodec['id'] ?>"><?= $t_baycodec['activo'] ? '⏸ Pausar' : '▶ Activar' ?></a>
          <a class="btn_baycodec peligro_baycodec" href="admin-envios.php?eliminar=<?= (int) $t_baycodec['id'] ?>"
             onclick="return confirm('¿Eliminar la zona &quot;<?= v_env_baycodec($t_baycodec['zona']) ?>&quot;?');">🗑️</a>
        </td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

</body>
</html>
