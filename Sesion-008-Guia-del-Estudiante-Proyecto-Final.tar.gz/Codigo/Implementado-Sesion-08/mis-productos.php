<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// MIS PRODUCTOS (panel de vendedor C2C) — Sesión 8: marketplace
// ------------------------------------------------------------
// Espejo de admin-productos.php, pero para el CLIENTE (no para el
// equipo de Grafiluz): un revendedor (C2C) publica y administra SUS
// propios productos, que aparecen mezclados en el catálogo público
// (tienda.php) junto a los de Grafiluz. La diferencia clave con el
// panel de admin es el alcance: cada consulta va SIEMPRE filtrada
// por "WHERE vendedor_id = <su propia cuenta>", para que un vendedor
// jamás pueda ver ni tocar productos de otro — ni siquiera cambiando
// el id en la URL (ver las consultas de editar/actualizar/eliminar
// más abajo). El administrador (baycodec) sigue siendo el único que
// ve y edita TODO desde admin-productos.php.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

$clienteActual_baycodec = clienteActual_baycodec();
if (!$clienteActual_baycodec) {
    header('Location: login-cliente.php');
    exit;
}

// Solo las cuentas C2C (revendedor) publican productos propios; B2C
// y B2B son perfiles de compra, igual que se explicó al registrarse.
if ($clienteActual_baycodec['tipo_cliente'] !== 'C2C') {
    http_response_code(403);
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head><meta charset="UTF-8"><title>Mis Productos — Grafiluz</title></head>
    <body style="font-family:system-ui,sans-serif;max-width:600px;margin:60px auto;text-align:center;color:#1f2937;">
      <h1>🔒 Solo para cuentas de revendedor (C2C)</h1>
      <p>Publicar productos propios es una función para cuentas <strong>C2C</strong> (revendedor).
      Tu cuenta es <strong><?= htmlspecialchars($clienteActual_baycodec['tipo_cliente'], ENT_QUOTES, 'UTF-8') ?></strong>.</p>
      <p><a href="carrito.php">← Volver a mi pedido</a> · <a href="tienda.php">Ir a la tienda</a></p>
    </body>
    </html>
    <?php
    exit;
}

$vendedorId_baycodec = (int) $clienteActual_baycodec['id'];

// Categorías (mejora post-Sesión 8): antes era un arreglo fijo escrito
// a mano aquí mismo (y otra copia distinta en admin-productos.php).
// Ahora ambos paneles leen la misma tabla "categorias" (ver
// db-conexion.php) — un vendedor ya no puede terminar con una
// categoría distinta a la que usa el resto del catálogo.
$CATEGORIAS_VALIDAS_BAYCODEC = $pdo_baycodec->query('SELECT nombre FROM categorias_tb_baycodec ORDER BY nombre')->fetchAll(PDO::FETCH_COLUMN);

function limpiarTexto_mp_baycodec($valor) {
    return trim($valor ?? '');
}

function v_mp_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

$errorFormulario_baycodec = '';
$idEditando_baycodec = isset($_GET['editar']) ? (int) $_GET['editar'] : null;

// ------------------------------------------------------------
// Procesa el formulario (agregar o guardar edición) por POST
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar') {
    $codigo = limpiarTexto_mp_baycodec($_POST['codigo'] ?? '');
    $categoria = limpiarTexto_mp_baycodec($_POST['categoria'] ?? '');
    $nombre = limpiarTexto_mp_baycodec($_POST['nombre'] ?? '');
    $medidas = limpiarTexto_mp_baycodec($_POST['medidas'] ?? '');
    $material = limpiarTexto_mp_baycodec($_POST['material'] ?? '');
    $colores = limpiarTexto_mp_baycodec($_POST['colores'] ?? '');
    $imagenUrl = limpiarTexto_mp_baycodec($_POST['imagen_url'] ?? '');
    $precio = str_replace(',', '.', limpiarTexto_mp_baycodec($_POST['precio'] ?? ''));
    $activo = isset($_POST['activo']) ? 1 : 0;
    $idFormulario = (int) ($_POST['id'] ?? 0);
    $stockFormulario_baycodec = trim($_POST['stock'] ?? '');
    $stock_baycodec = $stockFormulario_baycodec === '' ? null : (int) $stockFormulario_baycodec;

    if ($codigo === '' || $categoria === '' || $nombre === '') {
        $errorFormulario_baycodec = 'Código, categoría y nombre son obligatorios.';
    } elseif (!in_array($categoria, $CATEGORIAS_VALIDAS_BAYCODEC, true)) {
        $errorFormulario_baycodec = 'Elige una categoría válida de la lista (así tu producto aparece en la sección correcta del catálogo).';
    } elseif (!is_numeric($precio) || (float) $precio < 0) {
        $errorFormulario_baycodec = 'El precio referencial debe ser un número mayor o igual a 0.';
    } elseif ($stockFormulario_baycodec !== '' && (!is_numeric($stockFormulario_baycodec) || $stock_baycodec < 0)) {
        $errorFormulario_baycodec = 'El stock debe ser un número mayor o igual a 0, o quedar vacío si no controlas stock.';
    } elseif ($imagenUrl !== '' && !filter_var(explode(',', $imagenUrl)[0], FILTER_VALIDATE_URL)) {
        $errorFormulario_baycodec = 'La URL de la imagen no es válida (debe empezar con http:// o https://).';
    } else {
        try {
            if ($idFormulario > 0) {
                // AND vendedor_id = ? -> nunca edita un producto que no sea suyo,
                // ni cambiando el id en la URL a mano.
                $stockAnteriorMp_baycodec = $pdo_baycodec->prepare('SELECT stock FROM productos_tb_baycodec WHERE id = ? AND vendedor_id = ?');
                $stockAnteriorMp_baycodec->execute([$idFormulario, $vendedorId_baycodec]);
                $stockAnteriorValor_baycodec = $stockAnteriorMp_baycodec->fetchColumn();

                $consulta = $pdo_baycodec->prepare(
                    'UPDATE productos_tb_baycodec SET codigo = ?, categoria = ?, nombre = ?, medidas = ?, material = ?,
                     colores = ?, imagen_url = ?, precio_referencial_pen = ?, stock = ?, activo = ?
                     WHERE id = ? AND vendedor_id = ?'
                );
                $consulta->execute([$codigo, $categoria, $nombre, $medidas, $material, $colores, $imagenUrl, $precio, $stock_baycodec, $activo, $idFormulario, $vendedorId_baycodec]);

                if ($stockAnteriorValor_baycodec !== false && $stock_baycodec !== null && (int) $stockAnteriorValor_baycodec !== $stock_baycodec) {
                    $diferenciaMp_baycodec = $stock_baycodec - (int) $stockAnteriorValor_baycodec;
                    $pdo_baycodec->prepare('INSERT INTO movimientos_inventario_tb_baycodec (producto_codigo, tipo, cantidad, motivo) VALUES (?, ?, ?, ?)')
                        ->execute([$codigo, $diferenciaMp_baycodec >= 0 ? 'entrada' : 'salida', abs($diferenciaMp_baycodec), 'Ajuste manual del vendedor']);
                }
            } else {
                $consulta = $pdo_baycodec->prepare(
                    'INSERT INTO productos_tb_baycodec (codigo, categoria, nombre, medidas, material, colores, imagen_url, precio_referencial_pen, stock, activo, vendedor_id)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $consulta->execute([$codigo, $categoria, $nombre, $medidas, $material, $colores, $imagenUrl, $precio, $stock_baycodec, $activo, $vendedorId_baycodec]);

                if ($stock_baycodec !== null && $stock_baycodec > 0) {
                    $pdo_baycodec->prepare('INSERT INTO movimientos_inventario_tb_baycodec (producto_codigo, tipo, cantidad, motivo) VALUES (?, "entrada", ?, "Stock inicial al publicar el producto")')
                        ->execute([$codigo, $stock_baycodec]);
                }
            }
            header('Location: mis-productos.php?guardado=1');
            exit;
        } catch (PDOException $error) {
            // El código es único en TODO el catálogo (Grafiluz + todos
            // los vendedores) — un choque aquí es normal si otro
            // vendedor ya usó ese mismo código.
            $errorFormulario_baycodec = str_contains($error->getMessage(), 'Duplicate')
                ? 'Ese código ya está en uso por otro producto del catálogo. Prueba con otro.'
                : 'No se pudo guardar el producto.';
        }
    }
}

// ------------------------------------------------------------
// Elimina un producto propio (por GET con confirmación en el navegador)
// ------------------------------------------------------------
if (isset($_GET['eliminar'])) {
    $consulta = $pdo_baycodec->prepare('DELETE FROM productos_tb_baycodec WHERE id = ? AND vendedor_id = ?');
    $consulta->execute([(int) $_GET['eliminar'], $vendedorId_baycodec]);
    header('Location: mis-productos.php?eliminado=1');
    exit;
}

// ------------------------------------------------------------
// Variantes de producto (mejora post-Sesión 8): mismo mecanismo que
// admin-productos.php, pero verificando SIEMPRE que el producto sea
// suyo antes de tocar sus variantes (AND vendedor_id = ? en la
// comprobación) — un vendedor jamás puede agregar/borrar variantes de
// un producto que no es suyo, ni cambiando el código o el id a mano.
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'agregar_variante') {
    $productoCodigoVariante_baycodec = trim($_POST['producto_codigo_variante'] ?? '');
    $nombreVariante_baycodec = trim($_POST['nombre_variante'] ?? '');
    $precioExtraVariante_baycodec = str_replace(',', '.', trim($_POST['precio_extra'] ?? '0'));
    $stockVariante_baycodec = (int) ($_POST['stock_variante'] ?? 0);
    $idProductoVariante_baycodec = (int) ($_POST['id_producto_variante'] ?? 0);

    $esDueno_baycodec = $pdo_baycodec->prepare('SELECT COUNT(*) FROM productos_tb_baycodec WHERE codigo = ? AND vendedor_id = ?');
    $esDueno_baycodec->execute([$productoCodigoVariante_baycodec, $vendedorId_baycodec]);

    if ((int) $esDueno_baycodec->fetchColumn() > 0 && $nombreVariante_baycodec !== '' && is_numeric($precioExtraVariante_baycodec)) {
        $pdo_baycodec->prepare('INSERT INTO producto_variantes_tb_baycodec (producto_codigo, nombre_variante, precio_extra, stock) VALUES (?, ?, ?, ?)')
            ->execute([$productoCodigoVariante_baycodec, $nombreVariante_baycodec, $precioExtraVariante_baycodec, max(0, $stockVariante_baycodec)]);
    }
    header('Location: mis-productos.php?editar=' . $idProductoVariante_baycodec);
    exit;
}

if (isset($_GET['eliminar_variante'])) {
    $idProductoVolver_baycodec = (int) ($_GET['producto_id'] ?? 0);
    $pdo_baycodec->prepare(
        'DELETE pv FROM producto_variantes_tb_baycodec pv
         JOIN productos_tb_baycodec p ON p.codigo = pv.producto_codigo
         WHERE pv.id = ? AND p.vendedor_id = ?'
    )->execute([(int) $_GET['eliminar_variante'], $vendedorId_baycodec]);
    header('Location: mis-productos.php?editar=' . $idProductoVolver_baycodec);
    exit;
}

// ------------------------------------------------------------
// Datos para precargar el formulario si se está editando (solo si
// el producto es realmente suyo)
// ------------------------------------------------------------
$productoEditando_baycodec = null;
$variantesProductoEditando_baycodec = [];
if ($idEditando_baycodec) {
    $consulta = $pdo_baycodec->prepare('SELECT * FROM productos_tb_baycodec WHERE id = ? AND vendedor_id = ?');
    $consulta->execute([$idEditando_baycodec, $vendedorId_baycodec]);
    $productoEditando_baycodec = $consulta->fetch();

    if ($productoEditando_baycodec) {
        $consultaVariantesMp_baycodec = $pdo_baycodec->prepare('SELECT * FROM producto_variantes_tb_baycodec WHERE producto_codigo = ? ORDER BY nombre_variante');
        $consultaVariantesMp_baycodec->execute([$productoEditando_baycodec['codigo']]);
        $variantesProductoEditando_baycodec = $consultaVariantesMp_baycodec->fetchAll();
    }
}

$consultaMisProductos_baycodec = $pdo_baycodec->prepare('SELECT * FROM productos_tb_baycodec WHERE vendedor_id = ? ORDER BY categoria, nombre');
$consultaMisProductos_baycodec->execute([$vendedorId_baycodec]);
$misProductos_baycodec = $consultaMisProductos_baycodec->fetchAll();

// Historial de stock (mejora post-Sesión 8): movimientos_inventario
// se escribía desde admin-productos.php/mis-productos.php/pagar-pedido.php
// pero nadie lo mostraba — aquí un vendedor ve el historial SOLO de
// sus propios productos (nunca los de otro vendedor ni los de Grafiluz).
$misCodigosProductos_baycodec = array_column($misProductos_baycodec, 'codigo');
$misMovimientosStock_baycodec = [];
if (!empty($misCodigosProductos_baycodec)) {
    $marcadores_baycodec = implode(',', array_fill(0, count($misCodigosProductos_baycodec), '?'));
    $consultaMovimientos_baycodec = $pdo_baycodec->prepare(
        "SELECT * FROM movimientos_inventario_tb_baycodec WHERE producto_codigo IN ({$marcadores_baycodec}) ORDER BY id DESC LIMIT 20"
    );
    $consultaMovimientos_baycodec->execute($misCodigosProductos_baycodec);
    $misMovimientosStock_baycodec = $consultaMovimientos_baycodec->fetchAll();
}

// ------------------------------------------------------------
// Quién me compró: vendedor_id se guarda fijo en detalle_pedido al
// momento de la compra (ver crear-pedido.php), así que esta lista
// sigue mostrando la venta aunque después edites o borres el
// producto. Solo ve SUS propias ventas — nunca las de otro vendedor.
// ------------------------------------------------------------
$consultaMisVentas_baycodec = $pdo_baycodec->prepare(
    'SELECT dp.producto_nombre, dp.cantidad, dp.precio_unitario, dp.variante_nombre,
            p.id AS pedido_id, p.estado AS pedido_estado, p.creado_en,
            c.nombre AS comprador_nombre, c.usuario AS comprador_usuario,
            pg.estado AS pago_estado
     FROM detalle_pedido_tb_baycodec dp
     JOIN pedidos_tb_baycodec p ON p.id = dp.pedido_id
     JOIN clientes_tb_baycodec c ON c.id = p.cliente_id
     LEFT JOIN pagos_tb_baycodec pg ON pg.pedido_id = p.id
     WHERE dp.vendedor_id = ?
     ORDER BY p.id DESC'
);
$consultaMisVentas_baycodec->execute([$vendedorId_baycodec]);
$misVentas_baycodec = $consultaMisVentas_baycodec->fetchAll();

// Reputación como vendedor (mejora post-Sesión 8): promedio y total de
// calificaciones que le dejaron los compradores (ver calificar-vendedor.php),
// distinta de las reseñas que califican cada producto por separado.
$consultaMiReputacion_baycodec = $pdo_baycodec->prepare('SELECT AVG(calificacion) AS promedio, COUNT(*) AS total FROM calificaciones_vendedor_tb_baycodec WHERE vendedor_id = ?');
$consultaMiReputacion_baycodec->execute([$vendedorId_baycodec]);
$miReputacion_baycodec = $consultaMiReputacion_baycodec->fetch();

// Mis ganancias (mejora post-Sesión 8): lo que generó en ventas ya
// pagadas (neto, con la comisión de Grafiluz descontada — ver
// pagar-pedido.php), cuánto ya se le pagó (admin-comisiones.php) y el
// saldo pendiente. Sin esto, un vendedor no tenía forma de saber
// cuánto le corresponde recibir.
$consultaMisGanancias_baycodec = $pdo_baycodec->prepare(
    'SELECT
        COALESCE(SUM(monto_venta), 0) AS total_vendido,
        COALESCE(SUM(monto_comision), 0) AS total_comision,
        COALESCE(SUM(monto_vendedor), 0) AS total_neto
     FROM comisiones_tb_baycodec WHERE vendedor_id = ?'
);
$consultaMisGanancias_baycodec->execute([$vendedorId_baycodec]);
$misGanancias_baycodec = $consultaMisGanancias_baycodec->fetch();

$consultaMisPagosRecibidos_baycodec = $pdo_baycodec->prepare('SELECT COALESCE(SUM(monto), 0) FROM pagos_vendedor_tb_baycodec WHERE vendedor_id = ?');
$consultaMisPagosRecibidos_baycodec->execute([$vendedorId_baycodec]);
$misPagosRecibidos_baycodec = (float) $consultaMisPagosRecibidos_baycodec->fetchColumn();
$miSaldoPendiente_baycodec = (float) $misGanancias_baycodec['total_neto'] - $misPagosRecibidos_baycodec;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Productos — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 1000px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  h2 { font-size: 1.1rem; margin-top: 34px; padding-top: 10px; border-top: 1px solid #e5e7eb; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .nota_baycodec { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; }
  .btn_baycodec:hover { background: #1e40af; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .btn_baycodec.secundario_baycodec:hover { background: #d1d5db; }
  .btn_baycodec.peligro_baycodec { background: #fee2e2; color: #991b1b; }
  .btn_baycodec.peligro_baycodec:hover { background: #fecaca; }
  a.btn_baycodec { text-decoration: none; display: inline-block; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"], input[type="number"], select { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .ayuda_baycodec { font-size: 0.78rem; color: #6b7280; margin-top: 3px; }
  .campos-en-fila_baycodec { display: grid; grid-template-columns: 1fr 1fr; gap: 0 16px; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; vertical-align: top; }
  th { background: #f3f4f6; }
  .fila-acciones_baycodec { display: flex; gap: 6px; }
  .fila-acciones_baycodec .btn_baycodec { font-size: 0.75rem; padding: 4px 8px; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .etiqueta-inactivo_baycodec { display: inline-block; background: #f3f4f6; color: #6b7280; border-radius: 10px; padding: 1px 8px; font-size: 0.72rem; }
  .checkbox-linea_baycodec { display: flex; align-items: center; gap: 8px; margin-top: 14px; }
  .checkbox-linea_baycodec input { width: auto; }
</style>
</head>
<body>

<h1>🛍️ Mis Productos — Grafiluz Marketplace</h1>
<p class="subtitulo_baycodec">
  Publica, edita o retira tus propios productos. Aparecen mezclados en el catálogo público
  (<a href="tienda.php">tienda.php</a>) junto a los de Grafiluz, y solo tú puedes administrarlos.
  <?php if ((int) $miReputacion_baycodec['total'] > 0): ?>
    <br>Tu reputación como vendedor: <strong>⭐ <?= number_format((float) $miReputacion_baycodec['promedio'], 1) ?></strong>
    (<?= (int) $miReputacion_baycodec['total'] ?> calificación<?= (int) $miReputacion_baycodec['total'] === 1 ? '' : 'es' ?>)
  <?php endif; ?>
</p>

<div class="caja_baycodec" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px;">
  <div>
    <a class="btn_baycodec" href="tienda.php" style="background:#C41F25;">🌐 Ir al sitio</a>
    <a class="btn_baycodec secundario_baycodec" href="carrito.php" style="margin-left:8px;">🧾 Mi pedido</a>
    <a class="btn_baycodec secundario_baycodec" href="mi-perfil.php" style="margin-left:8px;">👤 Mi perfil</a>
    <a class="btn_baycodec secundario_baycodec" href="mis-direcciones.php" style="margin-left:8px;">📍 Mis direcciones</a>
    <a class="btn_baycodec secundario_baycodec" href="mis-favoritos.php" style="margin-left:8px;">❤️ Mis favoritos</a>
    <a class="btn_baycodec secundario_baycodec" href="mis-notificaciones.php" style="margin-left:8px;">📨 Notificaciones</a>
  </div>
  <div style="font-size:0.85rem; color:#6b7280;">
    Sesión: <strong><?= v_mp_baycodec($clienteActual_baycodec['nombre']) ?></strong> (C2C)
    · <a href="logout-cliente.php">Cerrar sesión</a>
  </div>
</div>

<?php if (isset($_GET['guardado'])): ?>
  <p class="exito_baycodec">✅ Producto guardado correctamente.</p>
<?php endif; ?>
<?php if (isset($_GET['eliminado'])): ?>
  <p class="exito_baycodec">🗑️ Producto eliminado.</p>
<?php endif; ?>
<?php if ($errorFormulario_baycodec): ?>
  <p class="error_baycodec">⚠️ <?= v_mp_baycodec($errorFormulario_baycodec) ?></p>
<?php endif; ?>

<div class="nota_baycodec">
  <strong>Cómo funciona:</strong> solo ves y puedes editar los productos que TÚ publicaste — ni Grafiluz
  ni otros vendedores aparecen aquí. El administrador de Grafiluz sí puede ver y editar todo el catálogo
  (incluidos tus productos) desde su propio panel interno.
</div>

<h2><?= $productoEditando_baycodec ? '✏️ Editar mi producto' : '➕ Publicar nuevo producto' ?></h2>
<div class="caja_baycodec">
  <form method="post" action="mis-productos.php">
    <input type="hidden" name="accion" value="guardar">
    <input type="hidden" name="id" value="<?= v_mp_baycodec($productoEditando_baycodec['id'] ?? '') ?>">

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="codigo">Código (único, sin espacios)</label>
        <input type="text" id="codigo" name="codigo" placeholder="Ej: mi-tienda-llavero-01"
               value="<?= v_mp_baycodec($productoEditando_baycodec['codigo'] ?? '') ?>" required>
      </div>
      <div>
        <label for="categoria">Categoría</label>
        <select id="categoria" name="categoria" required>
          <option value="">Elige una categoría...</option>
          <?php foreach ($CATEGORIAS_VALIDAS_BAYCODEC as $categoriaOpcion_baycodec): ?>
            <option value="<?= v_mp_baycodec($categoriaOpcion_baycodec) ?>"
              <?= ($productoEditando_baycodec['categoria'] ?? '') === $categoriaOpcion_baycodec ? 'selected' : '' ?>>
              <?= v_mp_baycodec($categoriaOpcion_baycodec) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

    <label for="nombre">Nombre del producto</label>
    <input type="text" id="nombre" name="nombre" placeholder="Ej: Llavero de Cuero Grabado"
           value="<?= v_mp_baycodec($productoEditando_baycodec['nombre'] ?? '') ?>" required>

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="medidas">Medidas</label>
        <input type="text" id="medidas" name="medidas" placeholder="Ej: 6 x 4 cm"
               value="<?= v_mp_baycodec($productoEditando_baycodec['medidas'] ?? '') ?>">
      </div>
      <div>
        <label for="material">Material</label>
        <input type="text" id="material" name="material" placeholder="Ej: Cuero sintético"
               value="<?= v_mp_baycodec($productoEditando_baycodec['material'] ?? '') ?>">
      </div>
    </div>

    <label for="colores">Colores disponibles</label>
    <input type="text" id="colores" name="colores" placeholder="Ej: marrón,negro,camel"
           value="<?= v_mp_baycodec($productoEditando_baycodec['colores'] ?? '') ?>">
    <p class="ayuda_baycodec">Sepáralos con comas.</p>

    <label for="imagen_url">URL(s) de la imagen del producto</label>
    <input type="text" id="imagen_url" name="imagen_url" placeholder="https://... , https://... , https://..."
           value="<?= v_mp_baycodec($productoEditando_baycodec['imagen_url'] ?? '') ?>"
           oninput="document.getElementById('vista-previa-imagen_baycodec').src = this.value.split(',')[0].trim();">
    <p class="ayuda_baycodec">Pega una URL, o varias separadas por comas para que la tarjeta muestre un carrusel con las fotos de tu producto.</p>
    <img id="vista-previa-imagen_baycodec" alt="Vista previa (primera imagen)"
         src="<?= v_mp_baycodec(trim(explode(',', $productoEditando_baycodec['imagen_url'] ?? '')[0])) ?>"
         style="max-width:160px;max-height:160px;margin-top:8px;border-radius:6px;border:1px solid #e5e7eb;<?= empty($productoEditando_baycodec['imagen_url']) ? 'display:none;' : '' ?>"
         onerror="this.style.display='none';" onload="this.style.display='block';">

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="precio">Precio referencial (S/)</label>
        <input type="number" id="precio" name="precio" step="0.01" min="0" placeholder="Ej: 9.90"
               value="<?= v_mp_baycodec($productoEditando_baycodec['precio_referencial_pen'] ?? '') ?>" required>
      </div>
      <div>
        <label for="stock">Stock disponible</label>
        <input type="number" id="stock" name="stock" step="1" min="0" placeholder="Vacío = sin control"
               value="<?= v_mp_baycodec($productoEditando_baycodec['stock'] ?? '') ?>">
      </div>
    </div>
    <p class="ayuda_baycodec">Déjalo vacío si no quieres controlar stock (se sigue vendiendo siempre). Se descuenta solo cuando te pagan.</p>

    <div class="checkbox-linea_baycodec">
      <input type="checkbox" id="activo" name="activo"
             <?= (!$productoEditando_baycodec || $productoEditando_baycodec['activo']) ? 'checked' : '' ?>>
      <label for="activo" style="margin:0;">Producto activo (visible en el catálogo)</label>
    </div>

    <div style="margin-top:14px;">
      <button class="btn_baycodec" type="submit">💾 <?= $productoEditando_baycodec ? 'Guardar cambios' : 'Publicar producto' ?></button>
      <?php if ($productoEditando_baycodec): ?>
        <a class="btn_baycodec secundario_baycodec" href="mis-productos.php">✖ Cancelar edición</a>
      <?php endif; ?>
    </div>
  </form>
</div>

<?php if ($productoEditando_baycodec): ?>
<h2>🎨 Variantes de "<?= v_mp_baycodec($productoEditando_baycodec['nombre']) ?>"</h2>
<div class="caja_baycodec">
  <p class="ayuda_baycodec">Opcional: si tu producto viene en tallas/colores con stock o precio distinto, agrégalos aquí.
    Sin variantes, sigue funcionando igual que antes (con el stock de arriba).</p>

  <?php if (!empty($variantesProductoEditando_baycodec)): ?>
    <table>
      <thead><tr><th>Variante</th><th>Precio extra</th><th>Stock</th><th style="width:80px">Acciones</th></tr></thead>
      <tbody>
        <?php foreach ($variantesProductoEditando_baycodec as $variante_baycodec): ?>
          <tr>
            <td><?= v_mp_baycodec($variante_baycodec['nombre_variante']) ?></td>
            <td><?= (float) $variante_baycodec['precio_extra'] > 0 ? '+ S/ ' . number_format((float) $variante_baycodec['precio_extra'], 2) : '—' ?></td>
            <td><?= (int) $variante_baycodec['stock'] ?></td>
            <td>
              <a class="btn_baycodec peligro_baycodec" style="font-size:0.75rem; padding:4px 8px;"
                 href="mis-productos.php?eliminar_variante=<?= (int) $variante_baycodec['id'] ?>&producto_id=<?= (int) $productoEditando_baycodec['id'] ?>"
                 onclick="return confirm('¿Eliminar esta variante?');">🗑️</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p class="vacio_baycodec">Este producto todavía no tiene variantes.</p>
  <?php endif; ?>

  <form method="post" action="mis-productos.php" style="margin-top:10px;">
    <input type="hidden" name="accion" value="agregar_variante">
    <input type="hidden" name="producto_codigo_variante" value="<?= v_mp_baycodec($productoEditando_baycodec['codigo']) ?>">
    <input type="hidden" name="id_producto_variante" value="<?= (int) $productoEditando_baycodec['id'] ?>">
    <div class="campos-en-fila_baycodec">
      <div>
        <label for="nombre_variante">Nombre de la variante</label>
        <input type="text" id="nombre_variante" name="nombre_variante" placeholder="Ej: Talla M - Azul" required>
      </div>
      <div>
        <label for="precio_extra">Precio extra (S/, puede ser 0)</label>
        <input type="number" id="precio_extra" name="precio_extra" step="0.01" min="0" value="0" required>
      </div>
    </div>
    <label for="stock_variante">Stock de esta variante</label>
    <input type="number" id="stock_variante" name="stock_variante" step="1" min="0" value="0" required>
    <button class="btn_baycodec" type="submit" style="margin-top:10px;">➕ Agregar variante</button>
  </form>
</div>
<?php endif; ?>

<h2>Mis productos publicados (<?= count($misProductos_baycodec) ?>)</h2>
<table>
  <thead>
    <tr>
      <th style="width:64px">Imagen</th><th>Código</th><th>Categoría</th><th>Nombre</th><th>Precio (S/)</th><th>Stock</th><th>Estado</th><th style="width:140px">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php if (empty($misProductos_baycodec)): ?>
      <tr><td colspan="8" class="vacio_baycodec">(todavía no publicaste ningún producto)</td></tr>
    <?php else: foreach ($misProductos_baycodec as $p): ?>
      <tr>
        <td>
          <?php if (!empty($p['imagen_url'])): ?>
            <img src="<?= v_mp_baycodec(trim(explode(',', $p['imagen_url'])[0])) ?>" alt="<?= v_mp_baycodec($p['nombre']) ?>"
                 style="width:44px;height:44px;object-fit:cover;border-radius:5px;border:1px solid #e5e7eb;"
                 onerror="this.replaceWith(document.createTextNode('—'));">
          <?php else: ?>
            <span class="vacio_baycodec">—</span>
          <?php endif; ?>
        </td>
        <td><?= v_mp_baycodec($p['codigo']) ?></td>
        <td><?= v_mp_baycodec($p['categoria']) ?></td>
        <td><?= v_mp_baycodec($p['nombre']) ?></td>
        <td>S/ <?= number_format((float) $p['precio_referencial_pen'], 2) ?></td>
        <td>
          <?php if ($p['stock'] === null): ?>
            <span class="vacio_baycodec">Sin control</span>
          <?php elseif ((int) $p['stock'] <= 0): ?>
            <span class="etiqueta-inactivo_baycodec">Agotado</span>
          <?php else: ?>
            <?= (int) $p['stock'] ?>
          <?php endif; ?>
        </td>
        <td><?= $p['activo'] ? 'Activo' : '<span class="etiqueta-inactivo_baycodec">Inactivo</span>' ?></td>
        <td class="fila-acciones_baycodec">
          <a class="btn_baycodec secundario_baycodec" href="mis-productos.php?editar=<?= (int) $p['id'] ?>">✏️ Editar</a>
          <a class="btn_baycodec peligro_baycodec" href="mis-productos.php?eliminar=<?= (int) $p['id'] ?>"
             onclick="return confirm('¿Eliminar tu producto &quot;<?= v_mp_baycodec($p['nombre']) ?>&quot;? Esta acción no se puede deshacer.');">🗑️</a>
        </td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

<h2>💰 Mis ganancias</h2>
<p class="ayuda_baycodec" style="margin-top:-6px;">Solo cuenta lo ya <strong>pagado</strong> por el comprador — un pedido Pendiente todavía no genera ganancia.</p>
<div class="caja_baycodec" style="display:grid; grid-template-columns:repeat(auto-fit,minmax(140px,1fr)); gap:12px; text-align:center;">
  <div><div style="font-size:1.3rem; font-weight:700; color:#1A1C72;">S/ <?= number_format((float) $misGanancias_baycodec['total_vendido'], 2) ?></div><div class="ayuda_baycodec">Vendido (bruto)</div></div>
  <div><div style="font-size:1.3rem; font-weight:700; color:#92400e;">S/ <?= number_format((float) $misGanancias_baycodec['total_comision'], 2) ?></div><div class="ayuda_baycodec">Comisión Grafiluz</div></div>
  <div><div style="font-size:1.3rem; font-weight:700; color:#166534;">S/ <?= number_format((float) $misGanancias_baycodec['total_neto'], 2) ?></div><div class="ayuda_baycodec">Neto a recibir</div></div>
  <div><div style="font-size:1.3rem; font-weight:700; color:#6b7280;">S/ <?= number_format($misPagosRecibidos_baycodec, 2) ?></div><div class="ayuda_baycodec">Ya pagado</div></div>
  <div><div style="font-size:1.3rem; font-weight:700; color:<?= $miSaldoPendiente_baycodec > 0.009 ? '#dc2626' : '#166534' ?>;">S/ <?= number_format($miSaldoPendiente_baycodec, 2) ?></div><div class="ayuda_baycodec">Saldo pendiente</div></div>
</div>

<h2>Quién me compró (<?= count($misVentas_baycodec) ?>)</h2>
<p class="ayuda_baycodec" style="margin-top:-6px;">Solo ves TUS ventas — nunca las de otro vendedor. Si otro cliente compró tu producto junto con productos de Grafiluz u otro vendedor en el mismo pedido, aquí solo aparece la parte que te corresponde a ti.</p>
<table>
  <thead>
    <tr>
      <th>Fecha</th><th>Comprador</th><th>Producto</th><th>Cantidad</th><th>Subtotal</th><th>Pedido</th><th>Estado pago</th>
    </tr>
  </thead>
  <tbody>
    <?php if (empty($misVentas_baycodec)): ?>
      <tr><td colspan="7" class="vacio_baycodec">(todavía nadie te compró)</td></tr>
    <?php else: foreach ($misVentas_baycodec as $venta_baycodec): ?>
      <tr>
        <td><?= v_mp_baycodec(date('d/m/Y', strtotime($venta_baycodec['creado_en']))) ?></td>
        <td><?= v_mp_baycodec($venta_baycodec['comprador_nombre']) ?><br><span class="vacio_baycodec"><?= v_mp_baycodec($venta_baycodec['comprador_usuario']) ?></span></td>
        <td><?= v_mp_baycodec($venta_baycodec['producto_nombre']) ?><?= $venta_baycodec['variante_nombre'] ? ' (' . v_mp_baycodec($venta_baycodec['variante_nombre']) . ')' : '' ?></td>
        <td><?= (int) $venta_baycodec['cantidad'] ?></td>
        <td>S/ <?= number_format($venta_baycodec['cantidad'] * $venta_baycodec['precio_unitario'], 2) ?></td>
        <td>#<?= (int) $venta_baycodec['pedido_id'] ?></td>
        <td><?= $venta_baycodec['pago_estado'] === 'Pagado' ? '<span style="color:#166534;font-weight:600;">Pagado</span>' : '<span style="color:#92400e;font-weight:600;">' . v_mp_baycodec($venta_baycodec['pago_estado'] ?? 'Pendiente') . '</span>' ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

<h2>📦 Historial de mi stock (últimos 20)</h2>
<p class="ayuda_baycodec" style="margin-top:-6px;">Solo tus productos: ajustes manuales, ventas y reembolsos que movieron el stock.</p>
<table>
  <thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th>Cantidad</th><th>Motivo</th></tr></thead>
  <tbody>
    <?php if (empty($misMovimientosStock_baycodec)): ?>
      <tr><td colspan="5" class="vacio_baycodec">(sin movimientos todavía)</td></tr>
    <?php else: foreach ($misMovimientosStock_baycodec as $mov_baycodec): ?>
      <tr>
        <td><?= v_mp_baycodec(date('d/m/Y H:i', strtotime($mov_baycodec['creado_en']))) ?></td>
        <td><code><?= v_mp_baycodec($mov_baycodec['producto_codigo']) ?></code></td>
        <td style="color:<?= $mov_baycodec['tipo'] === 'entrada' ? '#166534' : '#991b1b' ?>; font-weight:600;">
          <?= $mov_baycodec['tipo'] === 'entrada' ? '⬆ Entrada' : '⬇ Salida' ?>
        </td>
        <td><?= (int) $mov_baycodec['cantidad'] ?></td>
        <td><?= v_mp_baycodec($mov_baycodec['motivo']) ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

</body>
</html>
