<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// RESTABLECER CONTRASEÑA (ADMIN) — mejora post-Sesión 8
// ============================================================

require __DIR__ . '/auth-admin.php';

$token_baycodec = trim($_GET['token'] ?? $_POST['token'] ?? '');
$error_baycodec = '';
$exito_baycodec = false;

$consultaToken_baycodec = $pdo_baycodec->prepare(
    'SELECT * FROM tokens_recuperacion_tb_baycodec WHERE token = ? AND tipo = "admin" AND usado = 0 AND expira_en > NOW()'
);
$consultaToken_baycodec->execute([$token_baycodec]);
$filaToken_baycodec = $consultaToken_baycodec->fetch();

if (!$filaToken_baycodec) {
    $error_baycodec = 'Este enlace de recuperación no es válido, ya se usó o ya venció. Solicita uno nuevo.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clave_baycodec = $_POST['clave'] ?? '';
    $claveConfirmacion_baycodec = $_POST['clave_confirmacion'] ?? '';

    if (strlen($clave_baycodec) < 4) {
        $error_baycodec = 'La contraseña debe tener al menos 4 caracteres.';
    } elseif ($clave_baycodec !== $claveConfirmacion_baycodec) {
        $error_baycodec = 'Las contraseñas no coinciden.';
    } else {
        $pdo_baycodec->prepare('UPDATE usuarios_admin_tb_baycodec SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($clave_baycodec, PASSWORD_DEFAULT), $filaToken_baycodec['usuario_id']]);
        $pdo_baycodec->prepare('UPDATE tokens_recuperacion_tb_baycodec SET usado = 1 WHERE id = ?')->execute([$filaToken_baycodec['id']]);
        $exito_baycodec = true;
    }
}

function v_resta_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Restablecer contraseña — Panel Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; background: #fafafa; color: #1f2937; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 10px; padding: 30px 32px; width: 100%; max-width: 380px; box-shadow: 0 4px 14px rgba(0,0,0,0.05); }
  h1 { font-size: 1.2rem; margin: 0 0 4px; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="password"] { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 600; width: 100%; margin-top: 18px; text-decoration: none; display: block; text-align: center; box-sizing: border-box; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0; }
</style>
</head>
<body>

<div class="caja_baycodec">
  <h1>🔑 Elegir nueva contraseña — Admin</h1>

  <?php if ($exito_baycodec): ?>
    <p class="exito_baycodec">✅ Tu contraseña se actualizó. Ya puedes iniciar sesión.</p>
    <a class="btn_baycodec" href="login.php">Ir a iniciar sesión</a>
  <?php elseif ($error_baycodec && !$filaToken_baycodec): ?>
    <p class="error_baycodec">⚠️ <?= v_resta_baycodec($error_baycodec) ?></p>
    <a class="btn_baycodec" href="recuperar-clave-admin.php">Solicitar un enlace nuevo</a>
  <?php else: ?>
    <?php if ($error_baycodec): ?><p class="error_baycodec">⚠️ <?= v_resta_baycodec($error_baycodec) ?></p><?php endif; ?>
    <form method="post" action="restablecer-clave-admin.php">
      <input type="hidden" name="token" value="<?= v_resta_baycodec($token_baycodec) ?>">
      <label for="clave">Nueva contraseña</label>
      <input type="password" id="clave" name="clave" minlength="4" required>
      <label for="clave_confirmacion">Confirmar contraseña</label>
      <input type="password" id="clave_confirmacion" name="clave_confirmacion" minlength="4" required>
      <button class="btn_baycodec" type="submit">Guardar nueva contraseña</button>
    </form>
  <?php endif; ?>
</div>

</body>
</html>
