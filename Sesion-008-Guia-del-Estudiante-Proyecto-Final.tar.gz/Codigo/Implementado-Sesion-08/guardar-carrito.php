<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// GUARDAR CARRITO EN SERVIDOR (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// El carrito sigue viviendo principalmente en localStorage (rápido,
// sin esperar al servidor en cada clic "Agregar" — ver tienda.php).
// Este endpoint solo sincroniza una COPIA de respaldo en las tablas
// carritos/carrito_items cuando hay sesión de cliente iniciada, para
// que el carrito no se pierda si cambia de navegador o de
// dispositivo. Se llama "en segundo plano" desde carritoGuardar_baycodec()
// cada vez que el carrito cambia — nunca bloquea la interfaz.
//
// Reemplaza TODO el contenido del carrito guardado por el que manda
// el navegador (borra e inserta de nuevo) — es más simple y seguro
// que tratar de calcular diferencias, y el carrito nunca es tan
// grande como para que importe el costo.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

$cliente_baycodec = clienteActual_baycodec();
if (!$cliente_baycodec) {
    http_response_code(401);
    echo json_encode(['ok' => false]);
    exit;
}

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$items_baycodec = $cuerpo_baycodec['items'] ?? [];

if (!is_array($items_baycodec)) {
    http_response_code(400);
    echo json_encode(['ok' => false]);
    exit;
}

$pdo_baycodec->prepare('INSERT INTO carritos_tb_baycodec (cliente_id) VALUES (?) ON DUPLICATE KEY UPDATE actualizado_en = CURRENT_TIMESTAMP')
    ->execute([$cliente_baycodec['id']]);

$consultaCarritoId_baycodec = $pdo_baycodec->prepare('SELECT id FROM carritos_tb_baycodec WHERE cliente_id = ?');
$consultaCarritoId_baycodec->execute([$cliente_baycodec['id']]);
$carritoId_baycodec = (int) $consultaCarritoId_baycodec->fetchColumn();

$pdo_baycodec->prepare('DELETE FROM carrito_items_tb_baycodec WHERE carrito_id = ?')->execute([$carritoId_baycodec]);

$insertarItem_baycodec = $pdo_baycodec->prepare('INSERT INTO carrito_items_tb_baycodec (carrito_id, producto_codigo, cantidad) VALUES (?, ?, ?)');
foreach ($items_baycodec as $codigo_baycodec => $item_baycodec) {
    $cantidad_baycodec = (int) ($item_baycodec['cantidad'] ?? 0);
    $codigo_baycodec = trim((string) $codigo_baycodec);
    if ($codigo_baycodec === '' || $cantidad_baycodec <= 0) {
        continue;
    }
    $insertarItem_baycodec->execute([$carritoId_baycodec, $codigo_baycodec, $cantidad_baycodec]);
}

echo json_encode(['ok' => true]);
