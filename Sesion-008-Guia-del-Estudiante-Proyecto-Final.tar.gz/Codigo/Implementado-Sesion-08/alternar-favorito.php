<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// ALTERNAR FAVORITO (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// Guarda o quita un producto de favoritos.php con un solo clic desde
// el corazón de cada tarjeta en tienda.php. Un simple toggle: si ya
// estaba guardado, lo quita; si no estaba, lo guarda.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

$cliente_baycodec = clienteActual_baycodec();
if (!$cliente_baycodec) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión para guardar favoritos.']);
    exit;
}

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$codigo_baycodec = trim($cuerpo_baycodec['producto_codigo'] ?? '');

if ($codigo_baycodec === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'mensaje' => 'Falta el código del producto.']);
    exit;
}

$consultaExiste_baycodec = $pdo_baycodec->prepare('SELECT id FROM favoritos_tb_baycodec WHERE cliente_id = ? AND producto_codigo = ?');
$consultaExiste_baycodec->execute([$cliente_baycodec['id'], $codigo_baycodec]);

if ($consultaExiste_baycodec->fetch()) {
    $pdo_baycodec->prepare('DELETE FROM favoritos_tb_baycodec WHERE cliente_id = ? AND producto_codigo = ?')
        ->execute([$cliente_baycodec['id'], $codigo_baycodec]);
    echo json_encode(['ok' => true, 'favorito' => false]);
} else {
    $pdo_baycodec->prepare('INSERT INTO favoritos_tb_baycodec (cliente_id, producto_codigo) VALUES (?, ?)')
        ->execute([$cliente_baycodec['id'], $codigo_baycodec]);
    echo json_encode(['ok' => true, 'favorito' => true]);
}
