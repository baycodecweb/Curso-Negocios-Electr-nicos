<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// RECUPERAR CONTRASEÑA (ADMIN) — mejora post-Sesión 8
// ------------------------------------------------------------
// Mismo mecanismo que recuperar-clave-cliente.php pero para
// usuarios_admin (tipo="admin" en tokens_recuperacion). El enlace se
// muestra en pantalla por el mismo motivo (sandbox sin servidor de
// correo real) — ver la nota completa en recuperar-clave-cliente.php.
// ============================================================

require __DIR__ . '/auth-admin.php';

$enlaceGenerado_baycodec = '';
$mensaje_baycodec = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_baycodec = trim($_POST['usuario'] ?? '');

    $consultaAdmin_baycodec = $pdo_baycodec->prepare('SELECT id FROM usuarios_admin_tb_baycodec WHERE usuario = ?');
    $consultaAdmin_baycodec->execute([$usuario_baycodec]);
    $adminId_baycodec = $consultaAdmin_baycodec->fetchColumn();

    if ($adminId_baycodec) {
        $token_baycodec = bin2hex(random_bytes(32));
        $pdo_baycodec->prepare(
            'INSERT INTO tokens_recuperacion_tb_baycodec (tipo, usuario_id, token, expira_en) VALUES ("admin", ?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))'
        )->execute([$adminId_baycodec, $token_baycodec]);

        $enlaceGenerado_baycodec = 'restablecer-clave-admin.php?token=' . $token_baycodec;
    }

    $mensaje_baycodec = 'Si ese usuario existe, se generó un enlace de recuperación.';
}

function v_reca_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recuperar contraseña — Panel Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; background: #fafafa; color: #1f2937; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 10px; padding: 30px 32px; width: 100%; max-width: 380px; box-shadow: 0 4px 14px rgba(0,0,0,0.05); }
  h1 { font-size: 1.2rem; margin: 0 0 4px; }
  .subtitulo_baycodec { color: #6b7280; margin: 0 0 18px; font-size: 0.85rem; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"] { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 600; width: 100%; margin-top: 18px; }
  .aviso_baycodec { background: #eff6ff; border-left: 4px solid #1d4ed8; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0 14px; }
  .enlace-caja_baycodec { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 10px 14px; border-radius: 4px; font-size: 0.82rem; margin: 14px 0; word-break: break-all; }
  .enlace-caja_baycodec a { color: #1d4ed8; }
  .enlace-volver_baycodec { text-align: center; font-size: 0.85rem; margin-top: 14px; }
</style>
</head>
<body>

<form method="post" action="recuperar-clave-admin.php" class="caja_baycodec">
  <h1>🔑 Recuperar contraseña — Admin</h1>
  <p class="subtitulo_baycodec">Escribe tu usuario del panel y te generamos un enlace para elegir una nueva contraseña.</p>

  <?php if ($mensaje_baycodec): ?>
    <p class="aviso_baycodec"><?= v_reca_baycodec($mensaje_baycodec) ?></p>
  <?php endif; ?>

  <?php if ($enlaceGenerado_baycodec): ?>
    <div class="enlace-caja_baycodec">
      ⚠️ <strong>Sandbox educativo:</strong> sin servidor de correo real, el enlace queda aquí en vez de enviarse por email:<br>
      <a href="<?= v_reca_baycodec($enlaceGenerado_baycodec) ?>"><?= v_reca_baycodec($enlaceGenerado_baycodec) ?></a>
    </div>
  <?php endif; ?>

  <label for="usuario">Usuario</label>
  <input type="text" id="usuario" name="usuario" required>

  <button class="btn_baycodec" type="submit">Generar enlace de recuperación</button>
  <p class="enlace-volver_baycodec"><a href="login.php">← Volver a iniciar sesión</a></p>
</form>

</body>
</html>
