<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// GUARDAR RESEÑA / CALIFICACIÓN (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// Se llama desde mis-pedidos.php, donde cada producto de un pedido ya
// PAGADO trae su propio widget de estrellas. Igual que en
// crear-pedido.php ("nunca se confía en lo que manda el navegador"):
// aquí se vuelve a comprobar en la base de datos que este cliente de
// verdad compró y pagó ese producto — no basta con mandar cualquier
// código de producto desde las herramientas de desarrollador.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

$cliente_baycodec = clienteActual_baycodec();
if (!$cliente_baycodec) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión para dejar una reseña.']);
    exit;
}

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$codigo_baycodec = trim($cuerpo_baycodec['producto_codigo'] ?? '');
$calificacion_baycodec = (int) ($cuerpo_baycodec['calificacion'] ?? 0);
$comentario_baycodec = mb_substr(trim($cuerpo_baycodec['comentario'] ?? ''), 0, 500);

if ($codigo_baycodec === '' || $calificacion_baycodec < 1 || $calificacion_baycodec > 5) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'mensaje' => 'Elige una calificación de 1 a 5 estrellas.']);
    exit;
}

// Solo puede reseñar un producto que de verdad compró Y pagó — nunca
// uno que solo tiene en un pedido pendiente, ni uno al azar por su
// código.
$verificarCompra_baycodec = $pdo_baycodec->prepare(
    'SELECT COUNT(*) FROM detalle_pedido_tb_baycodec dp
     JOIN pedidos_tb_baycodec p ON p.id = dp.pedido_id
     WHERE p.cliente_id = ? AND p.estado = "Pagado" AND dp.producto_codigo = ?'
);
$verificarCompra_baycodec->execute([$cliente_baycodec['id'], $codigo_baycodec]);

if ((int) $verificarCompra_baycodec->fetchColumn() === 0) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'mensaje' => 'Solo puedes calificar productos que ya compraste y pagaste.']);
    exit;
}

// ON DUPLICATE KEY UPDATE: la UNIQUE (producto_codigo, cliente_id) de
// la tabla resenas (ver auth-cliente.php) hace que volver a calificar
// el mismo producto actualice la reseña existente en vez de duplicarla.
$guardar_baycodec = $pdo_baycodec->prepare(
    'INSERT INTO resenas_tb_baycodec (producto_codigo, cliente_id, calificacion, comentario)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE calificacion = VALUES(calificacion), comentario = VALUES(comentario)'
);
$guardar_baycodec->execute([$codigo_baycodec, $cliente_baycodec['id'], $calificacion_baycodec, $comentario_baycodec]);

echo json_encode(['ok' => true]);
