<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// MI PERFIL (editar datos de envío del cliente) — mejora post-Sesión 8
// ------------------------------------------------------------
// Hasta ahora los datos que se llenaban en registro-cliente.php
// (nombre, teléfono, dirección, ubicación en el mapa) quedaban fijos
// para siempre: si el cliente se mudaba o se equivocó al escribir su
// DNI, no había forma de corregirlo sin tocar la base de datos a mano.
// Esta página reutiliza el mismo formulario y el mismo mapa Leaflet
// de registro-cliente.php, pero para EDITAR una cuenta que ya existe
// en vez de crear una nueva.
//
// El usuario (login) y el tipo de cliente (B2C/B2B/C2C) NO se pueden
// cambiar aquí a propósito: el usuario es la llave con la que inició
// sesión, y el tipo de cliente decide reglas importantes en otras
// páginas (ej. mis-productos.php exige ser C2C) — cambiarlo a mitad
// de camino podría dejar productos o pedidos en un estado confuso.
// Si un cliente necesita cambiar de tipo, que lo pida al administrador
// desde admin-productos.php.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

$clienteSesion_baycodec = clienteActual_baycodec();
if (!$clienteSesion_baycodec) {
    header('Location: login-cliente.php');
    exit;
}

$consultaPerfil_baycodec = $pdo_baycodec->prepare('SELECT * FROM clientes_tb_baycodec WHERE id = ?');
$consultaPerfil_baycodec->execute([$clienteSesion_baycodec['id']]);
$perfil_baycodec = $consultaPerfil_baycodec->fetch();

$errorPerfil_baycodec = '';
$exitoPerfil_baycodec = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_baycodec = trim($_POST['nombre'] ?? '');
    $apellidos_baycodec = trim($_POST['apellidos'] ?? '');
    $dni_baycodec = trim($_POST['dni'] ?? '');
    $telefono_baycodec = trim($_POST['telefono'] ?? '');
    $direccion_baycodec = trim($_POST['direccion'] ?? '');
    $latitud_baycodec = trim($_POST['latitud'] ?? '');
    $longitud_baycodec = trim($_POST['longitud'] ?? '');
    $ruc_baycodec = trim($_POST['ruc'] ?? '');
    $plataformaReventa_baycodec = trim($_POST['plataforma_reventa'] ?? '');

    if ($nombre_baycodec === '' || $dni_baycodec === '' || $telefono_baycodec === '' || $direccion_baycodec === '') {
        $errorPerfil_baycodec = 'Nombre, DNI, teléfono y dirección son obligatorios.';
    } else {
        $latitudGuardar_baycodec = is_numeric($latitud_baycodec) ? (float) $latitud_baycodec : null;
        $longitudGuardar_baycodec = is_numeric($longitud_baycodec) ? (float) $longitud_baycodec : null;

        $actualizar_baycodec = $pdo_baycodec->prepare(
            'UPDATE clientes_tb_baycodec SET nombre = ?, apellidos = ?, dni = ?, telefono = ?, direccion = ?,
             latitud = ?, longitud = ?, ruc = ?, plataforma_reventa = ? WHERE id = ?'
        );
        $actualizar_baycodec->execute([
            $nombre_baycodec,
            $apellidos_baycodec,
            $dni_baycodec,
            $telefono_baycodec,
            $direccion_baycodec,
            $latitudGuardar_baycodec,
            $longitudGuardar_baycodec,
            $perfil_baycodec['tipo_cliente'] === 'B2B' ? $ruc_baycodec : $perfil_baycodec['ruc'],
            $perfil_baycodec['tipo_cliente'] === 'C2C' ? $plataformaReventa_baycodec : $perfil_baycodec['plataforma_reventa'],
            $clienteSesion_baycodec['id'],
        ]);

        // El nombre se muestra en el <nav> de todo el sitio desde la
        // sesión (no se vuelve a consultar la base en cada página) —
        // si cambió, hay que actualizar la sesión para que se refleje
        // de inmediato, sin pedirle reiniciar sesión.
        $_SESSION['cliente_nombre_baycodec'] = $nombre_baycodec;

        $consultaPerfil_baycodec->execute([$clienteSesion_baycodec['id']]);
        $perfil_baycodec = $consultaPerfil_baycodec->fetch();
        $exitoPerfil_baycodec = true;
    }
}

function v_perfil_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mi Perfil — Grafiluz</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
<style>
  body { font-family: system-ui, sans-serif; min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; background: #fafafa; color: #1f2937; padding: 30px 16px; box-sizing: border-box; }
  .caja-perfil_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 10px; padding: 30px 32px; width: 100%; max-width: 420px; box-shadow: 0 4px 14px rgba(0,0,0,0.05); }
  h1 { font-size: 1.2rem; margin: 0 0 4px; }
  .subtitulo_baycodec { color: #6b7280; margin: 0 0 18px; font-size: 0.85rem; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"] { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  input[disabled] { background: #f3f4f6; color: #6b7280; }
  .ayuda_baycodec { font-size: 0.78rem; color: #6b7280; margin-top: 3px; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 600; width: 100%; margin-top: 18px; }
  .btn_baycodec:hover { background: #1e40af; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; margin-top: 8px; }
  .btn_baycodec.secundario_baycodec:hover { background: #d1d5db; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0 14px; }
  .enlace-volver_baycodec { text-align: center; font-size: 0.85rem; margin-top: 14px; }
  .mapa-envio_baycodec { height: 220px; border-radius: 6px; margin-top: 8px; border: 1px solid #d1d5db; }
  .mapa-acciones_baycodec { display: flex; align-items: center; gap: 10px; margin-top: 6px; flex-wrap: wrap; }
  .btn-ubicacion_baycodec {
    background: #f3f4f6; color: #1f2937; border: 1px solid #d1d5db; border-radius: 6px;
    padding: 6px 12px; font-size: 0.82rem; cursor: pointer; font-family: inherit;
  }
  .btn-ubicacion_baycodec:hover { background: #e5e7eb; }
  .mapa-coordenadas_baycodec { font-size: 0.78rem; color: #6b7280; }
</style>
</head>
<body>

<form method="post" action="mi-perfil.php" class="caja-perfil_baycodec">
  <h1>👤 Mi Perfil — Grafiluz</h1>
  <p class="subtitulo_baycodec">Actualiza tus datos de contacto y tu dirección de envío.</p>

  <?php if ($exitoPerfil_baycodec): ?>
    <p class="exito_baycodec">✅ Tus datos se actualizaron correctamente.</p>
  <?php endif; ?>
  <?php if ($errorPerfil_baycodec): ?>
    <p class="error_baycodec">⚠️ <?= v_perfil_baycodec($errorPerfil_baycodec) ?></p>
  <?php endif; ?>

  <label for="usuario_solo_lectura">Usuario (no editable)</label>
  <input type="text" id="usuario_solo_lectura" value="<?= v_perfil_baycodec($perfil_baycodec['usuario']) ?>" disabled>
  <p class="ayuda_baycodec">Tipo de cuenta: <strong><?= v_perfil_baycodec($perfil_baycodec['tipo_cliente']) ?></strong> — si necesitas cambiarlo, pídeselo al administrador.</p>

  <label for="nombre">Nombres / Razón social</label>
  <input type="text" id="nombre" name="nombre" value="<?= v_perfil_baycodec($perfil_baycodec['nombre']) ?>" required>

  <label for="apellidos">Apellidos</label>
  <input type="text" id="apellidos" name="apellidos" value="<?= v_perfil_baycodec($perfil_baycodec['apellidos']) ?>">

  <label for="dni">DNI</label>
  <input type="text" id="dni" name="dni" maxlength="15" value="<?= v_perfil_baycodec($perfil_baycodec['dni']) ?>" required>

  <label for="telefono">Teléfono</label>
  <input type="text" id="telefono" name="telefono" maxlength="20" value="<?= v_perfil_baycodec($perfil_baycodec['telefono']) ?>" required>

  <label for="direccion">Dirección de envío</label>
  <input type="text" id="direccion" name="direccion" value="<?= v_perfil_baycodec($perfil_baycodec['direccion']) ?>" required>
  <p class="ayuda_baycodec">Si te mudaste, actualiza el punto exacto en el mapa.</p>

  <div id="mapa-envio_baycodec" class="mapa-envio_baycodec"></div>
  <div class="mapa-acciones_baycodec">
    <button type="button" class="btn-ubicacion_baycodec" onclick="perfilUsarUbicacionActual_baycodec(this)">📍 Usar mi ubicación actual</button>
    <span class="mapa-coordenadas_baycodec" id="mapa-coordenadas_baycodec">
      <?= ($perfil_baycodec['latitud'] !== null && $perfil_baycodec['longitud'] !== null)
          ? '📍 ' . v_perfil_baycodec($perfil_baycodec['latitud']) . ', ' . v_perfil_baycodec($perfil_baycodec['longitud'])
          : 'Sin ubicación marcada (opcional).' ?>
    </span>
  </div>
  <input type="hidden" id="latitud" name="latitud" value="<?= v_perfil_baycodec($perfil_baycodec['latitud']) ?>">
  <input type="hidden" id="longitud" name="longitud" value="<?= v_perfil_baycodec($perfil_baycodec['longitud']) ?>">

  <?php if ($perfil_baycodec['tipo_cliente'] === 'B2B'): ?>
    <label for="ruc">RUC de la empresa</label>
    <input type="text" id="ruc" name="ruc" value="<?= v_perfil_baycodec($perfil_baycodec['ruc']) ?>">
  <?php elseif ($perfil_baycodec['tipo_cliente'] === 'C2C'): ?>
    <label for="plataforma_reventa">¿Dónde revendes? (opcional)</label>
    <input type="text" id="plataforma_reventa" name="plataforma_reventa" value="<?= v_perfil_baycodec($perfil_baycodec['plataforma_reventa']) ?>">
  <?php endif; ?>

  <button class="btn_baycodec" type="submit">💾 Guardar cambios</button>
  <a class="btn_baycodec secundario_baycodec" href="mis-direcciones.php" style="display:block; text-align:center; text-decoration:none; box-sizing:border-box;">📍 Mis direcciones</a>
  <a class="btn_baycodec secundario_baycodec" href="mis-favoritos.php" style="display:block; text-align:center; text-decoration:none; box-sizing:border-box;">❤️ Mis favoritos</a>
  <a class="btn_baycodec secundario_baycodec" href="mis-notificaciones.php" style="display:block; text-align:center; text-decoration:none; box-sizing:border-box;">📨 Notificaciones</a>
  <a class="btn_baycodec secundario_baycodec" href="carrito.php" style="display:block; text-align:center; text-decoration:none; box-sizing:border-box;">← Volver a Mi Pedido</a>
</form>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
  let perfilMapaLeaflet_baycodec;
  let perfilMarcadorLeaflet_baycodec;

  function perfilInicializarMapa_baycodec() {
    const CENTRO_AREQUIPA_BAYCODEC = [-16.3988, -71.5369]; // sede de Grafiluz (Cercado, Arequipa)
    const latGuardada = parseFloat(document.getElementById('latitud').value);
    const lngGuardada = parseFloat(document.getElementById('longitud').value);
    const hayCoordenadaGuardada = !isNaN(latGuardada) && !isNaN(lngGuardada);
    const centro = hayCoordenadaGuardada ? [latGuardada, lngGuardada] : CENTRO_AREQUIPA_BAYCODEC;

    perfilMapaLeaflet_baycodec = L.map('mapa-envio_baycodec').setView(centro, hayCoordenadaGuardada ? 16 : 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(perfilMapaLeaflet_baycodec);

    if (hayCoordenadaGuardada) {
      perfilColocarMarcador_baycodec(latGuardada, lngGuardada);
    }

    perfilMapaLeaflet_baycodec.on('click', function (e) {
      perfilColocarMarcador_baycodec(e.latlng.lat, e.latlng.lng);
    });
  }

  function perfilColocarMarcador_baycodec(lat, lng) {
    if (perfilMarcadorLeaflet_baycodec) {
      perfilMarcadorLeaflet_baycodec.setLatLng([lat, lng]);
    } else {
      perfilMarcadorLeaflet_baycodec = L.marker([lat, lng], { draggable: true }).addTo(perfilMapaLeaflet_baycodec);
      perfilMarcadorLeaflet_baycodec.on('dragend', function () {
        const posicion = perfilMarcadorLeaflet_baycodec.getLatLng();
        perfilActualizarCoordenadas_baycodec(posicion.lat, posicion.lng);
      });
    }
    perfilActualizarCoordenadas_baycodec(lat, lng);
  }

  function perfilActualizarCoordenadas_baycodec(lat, lng) {
    document.getElementById('latitud').value = lat.toFixed(7);
    document.getElementById('longitud').value = lng.toFixed(7);
    document.getElementById('mapa-coordenadas_baycodec').textContent = `📍 ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  }

  function perfilUsarUbicacionActual_baycodec(boton) {
    if (!navigator.geolocation) {
      alert('Tu navegador no soporta geolocalización. Puedes marcar el punto directamente en el mapa.');
      return;
    }
    const textoOriginal = boton.textContent;
    boton.textContent = '⏳ Obteniendo ubicación...';
    boton.disabled = true;

    navigator.geolocation.getCurrentPosition(
      function (posicion) {
        const { latitude, longitude } = posicion.coords;
        perfilMapaLeaflet_baycodec.setView([latitude, longitude], 16);
        perfilColocarMarcador_baycodec(latitude, longitude);
        boton.textContent = textoOriginal;
        boton.disabled = false;
      },
      function () {
        alert('No se pudo obtener tu ubicación (revisa los permisos del navegador). Puedes marcarla manualmente haciendo clic en el mapa.');
        boton.textContent = textoOriginal;
        boton.disabled = false;
      }
    );
  }

  perfilInicializarMapa_baycodec();
</script>

</body>
</html>
