<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// VISOR DE NOTIFICACIONES — mejora post-Sesión 8
// ------------------------------------------------------------
// Cola/bitácora de lo que se le "avisaría" a cada cliente (ver
// notificaciones en auth-cliente.php) — "enviado" queda en 0 porque
// este entorno no tiene servidor de correo real; esto es lo más
// cercano a verlo funcionar sin fingir un envío que no ocurre.
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

const FILAS_POR_PAGINA_NOTIF_BAYCODEC = 25;
$paginaNotif_baycodec = max(1, (int) ($_GET['pagina'] ?? 1));

$totalNotif_baycodec = (int) $pdo_baycodec->query('SELECT COUNT(*) FROM notificaciones_tb_baycodec')->fetchColumn();
$totalPaginasNotif_baycodec = max(1, (int) ceil($totalNotif_baycodec / FILAS_POR_PAGINA_NOTIF_BAYCODEC));
$paginaNotif_baycodec = min($paginaNotif_baycodec, $totalPaginasNotif_baycodec);

$consultaNotif_baycodec = $pdo_baycodec->prepare(
    'SELECT n.*, c.nombre AS cliente_nombre, c.usuario AS cliente_usuario
     FROM notificaciones_tb_baycodec n
     LEFT JOIN clientes_tb_baycodec c ON c.id = n.cliente_id
     ORDER BY n.id DESC
     LIMIT :limite OFFSET :offset'
);
$consultaNotif_baycodec->bindValue(':limite', FILAS_POR_PAGINA_NOTIF_BAYCODEC, PDO::PARAM_INT);
$consultaNotif_baycodec->bindValue(':offset', ($paginaNotif_baycodec - 1) * FILAS_POR_PAGINA_NOTIF_BAYCODEC, PDO::PARAM_INT);
$consultaNotif_baycodec->execute();
$notificaciones_baycodec = $consultaNotif_baycodec->fetchAll();

function v_notif_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notificaciones — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 900px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .nota_baycodec { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; }
  th { background: #f3f4f6; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .paginador_baycodec { display: flex; align-items: center; justify-content: center; gap: 12px; margin: 12px 0 4px; }
  .paginador-info_baycodec { font-size: 0.82rem; color: #6b7280; }
  .paginador-deshabilitado_baycodec { opacity: .4; pointer-events: none; }
</style>
</head>
<body>

<h1>📨 Notificaciones — Grafiluz</h1>
<p class="subtitulo_baycodec">Cola de mensajes que se le avisarían a cada cliente (<?= $totalNotif_baycodec ?> en total).</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="admin-productos.php" style="background:#C41F25;">🛠️ Panel de Productos</a>
</div>

<div class="nota_baycodec">
  ⚠️ Este entorno de práctica no tiene un servidor de correo real — estas notificaciones quedan registradas
  aquí (columna "Enviado" siempre en No) en vez de salir por email de verdad. Ver la nota completa junto a
  <code>registrarNotificacion_baycodec()</code> en <code>auth-cliente.php</code>.
</div>

<table>
  <thead><tr><th>Fecha</th><th>Cliente</th><th>Tipo</th><th>Asunto</th><th>Cuerpo</th><th>Enviado</th></tr></thead>
  <tbody>
    <?php if (empty($notificaciones_baycodec)): ?>
      <tr><td colspan="6" class="vacio_baycodec">(sin notificaciones todavía)</td></tr>
    <?php else: foreach ($notificaciones_baycodec as $n_baycodec): ?>
      <tr>
        <td><?= v_notif_baycodec(date('d/m/Y H:i', strtotime($n_baycodec['creado_en']))) ?></td>
        <td><?= $n_baycodec['cliente_nombre'] ? v_notif_baycodec($n_baycodec['cliente_nombre']) . '<br><span class="vacio_baycodec">' . v_notif_baycodec($n_baycodec['cliente_usuario']) . '</span>' : '—' ?></td>
        <td><?= v_notif_baycodec($n_baycodec['tipo']) ?></td>
        <td><?= v_notif_baycodec($n_baycodec['asunto']) ?></td>
        <td style="max-width:280px;"><?= v_notif_baycodec($n_baycodec['cuerpo']) ?></td>
        <td><?= $n_baycodec['enviado'] ? 'Sí' : 'No' ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

<?php if ($totalPaginasNotif_baycodec > 1): ?>
  <div class="paginador_baycodec">
    <?php if ($paginaNotif_baycodec > 1): ?>
      <a class="btn_baycodec secundario_baycodec" href="?pagina=<?= $paginaNotif_baycodec - 1 ?>">‹ Anterior</a>
    <?php else: ?>
      <span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">‹ Anterior</span>
    <?php endif; ?>
    <span class="paginador-info_baycodec">Página <?= $paginaNotif_baycodec ?> de <?= $totalPaginasNotif_baycodec ?></span>
    <?php if ($paginaNotif_baycodec < $totalPaginasNotif_baycodec): ?>
      <a class="btn_baycodec secundario_baycodec" href="?pagina=<?= $paginaNotif_baycodec + 1 ?>">Siguiente ›</a>
    <?php else: ?>
      <span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">Siguiente ›</span>
    <?php endif; ?>
  </div>
<?php endif; ?>

</body>
</html>
