<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// LOGIN DE CLIENTE (COMPRADOR) — Sesión 8
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

$errorLogin_baycodec = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuarioIngresado_baycodec = trim($_POST['usuario'] ?? '');
    $claveIngresada_baycodec = $_POST['clave'] ?? '';

    $consulta_baycodec = $pdo_baycodec->prepare('SELECT * FROM clientes_tb_baycodec WHERE usuario = ?');
    $consulta_baycodec->execute([$usuarioIngresado_baycodec]);
    $clienteFila_baycodec = $consulta_baycodec->fetch();

    if ($clienteFila_baycodec && password_verify($claveIngresada_baycodec, $clienteFila_baycodec['password_hash'])) {
        iniciarSesionCliente_baycodec($clienteFila_baycodec);
        header('Location: carrito.php');
        exit;
    }

    $errorLogin_baycodec = 'Usuario o contraseña incorrectos.';
}

if (clienteActual_baycodec()) {
    header('Location: carrito.php');
    exit;
}

function v_loginc_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ingresar — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; background: #fafafa; color: #1f2937; }
  .caja-login_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 10px; padding: 30px 32px; width: 100%; max-width: 340px; box-shadow: 0 4px 14px rgba(0,0,0,0.05); }
  h1 { font-size: 1.2rem; margin: 0 0 4px; }
  .subtitulo_baycodec { color: #6b7280; margin: 0 0 18px; font-size: 0.85rem; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"], input[type="password"] { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 600; width: 100%; margin-top: 18px; }
  .btn_baycodec:hover { background: #1e40af; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0 0; }
  .enlace-registro_baycodec { text-align: center; font-size: 0.85rem; margin-top: 14px; }
</style>
</head>
<body>

<form method="post" action="login-cliente.php" class="caja-login_baycodec">
  <h1>🧾 Ingresar — Grafiluz</h1>
  <p class="subtitulo_baycodec">Ingresa con tu cuenta para generar y pagar tus pedidos.</p>

  <?php if ($errorLogin_baycodec): ?>
    <p class="error_baycodec">⚠️ <?= v_loginc_baycodec($errorLogin_baycodec) ?></p>
  <?php endif; ?>

  <label for="usuario">Usuario</label>
  <input type="text" id="usuario" name="usuario" autofocus required>

  <label for="clave">Contraseña</label>
  <input type="password" id="clave" name="clave" required>

  <button class="btn_baycodec" type="submit">Ingresar</button>
  <p class="enlace-registro_baycodec">¿No tienes cuenta? <a href="registro-cliente.php">Regístrate aquí</a></p>
  <p class="enlace-registro_baycodec"><a href="recuperar-clave-cliente.php">¿Olvidaste tu contraseña?</a></p>
</form>

</body>
</html>
