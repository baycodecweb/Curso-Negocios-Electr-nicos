<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// CARRITO / CHECKOUT — Sesión 8
// ------------------------------------------------------------
// Antes "Mi Pedido" vivía como una sección más dentro de tienda.php
// (todo en una sola página larga: catálogo, buscador, pedido, chat).
// Esta página separa el checkout en su propio archivo, como en un
// e-commerce real: aquí se ve lo que se va a comprar, se genera el
// pedido y se pasa a la pasarela de pago — sin mezclarse con el
// catálogo. El carrito en sí sigue siendo del navegador (localStorage,
// clave "grafiluz-carrito-baycodec"), porque agregar productos ocurre
// en tienda.php (botón 🛒 en cada tarjeta) y hace falta que ese
// carrito sobreviva la navegación a esta página. Lo que SÍ es real
// (MySQL, no localStorage) es el pedido ya generado — ver
// crear-pedido.php y pagar-pedido.php.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';
$clienteActual_baycodec = clienteActual_baycodec();

// Direcciones guardadas (mejora post-Sesión 8): si el cliente tiene
// varias, elige cuál usar al generar el pedido — ver mis-direcciones.php.
$misDireccionesCarrito_baycodec = [];
if ($clienteActual_baycodec) {
    $consultaDireccionesCarrito_baycodec = $pdo_baycodec->prepare('SELECT id, etiqueta, direccion, predeterminada FROM direcciones_tb_baycodec WHERE cliente_id = ? ORDER BY predeterminada DESC, creado_en DESC');
    $consultaDireccionesCarrito_baycodec->execute([$clienteActual_baycodec['id']]);
    $misDireccionesCarrito_baycodec = $consultaDireccionesCarrito_baycodec->fetchAll();
}

// Tarifas de envío (mejora post-Sesión 8): solo las zonas activas,
// para elegir al pagar — ver admin-envios.php.
$tarifasEnvioCarrito_baycodec = $pdo_baycodec->query('SELECT zona, costo, dias_estimados FROM tarifas_envio_tb_baycodec WHERE activo = 1 ORDER BY costo ASC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mi Pedido — Grafiluz</title>
  <meta name="description" content="Revisa tu pedido, genera tu cotización y paga en línea (sandbox) en Grafiluz.">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header>
    <img src="https://raw.githubusercontent.com/baycodecweb/logos-clientes/ddf0bd171aeb9345f8a59c3c1556411bfd3fad07/logo-Blanco-grafiluz.svg" alt="Logo Grafiluz" class="logo_baycodec">
    <p>Calle Pizarro 312 int 38  galerías unión y progreso cercado | 📧  juanaluzarenas8@gmail.com | 📞 910169539 / 930910829</p>
  </header>

  <nav>
    <a href="tienda.php#inicio_baycodec">INICIO</a>
    <details class="nav-dropdown_baycodec">
      <summary>PRODUCTOS</summary>
      <div class="nav-dropdown-menu_baycodec">
        <a href="tienda.php#antiestres_baycodec">ARTÍCULOS ANTIESTRÉS</a>
        <a href="tienda.php#escritorio_baycodec">ARTÍCULOS DE ESCRITORIO</a>
        <a href="tienda.php#tomatodos_baycodec">TOMATODOS</a>
        <a href="tienda.php#llaveros_baycodec">LLAVEROS</a>
        <a href="tienda.php#bolsas_baycodec">BOLSAS</a>
      </div>
    </details>
    <a href="carrito.php">MI PEDIDO 🧾</a>
    <a href="tienda.php#buscador-catalogo_baycodec">BUSCADOR 🔎</a>
    <div class="nav-cuenta_baycodec">
      <?php if ($clienteActual_baycodec): ?>
        👤 Hola, <?= htmlspecialchars($clienteActual_baycodec['nombre'], ENT_QUOTES, 'UTF-8') ?>
        <a href="mis-pedidos.php">Mis compras</a>
        <?php if ($clienteActual_baycodec['tipo_cliente'] === 'C2C'): ?>
          <a href="mis-productos.php">Mis ventas</a>
        <?php endif; ?>
        <a href="mis-favoritos.php">Mis favoritos</a>
        <a href="mis-notificaciones.php">Notificaciones</a>
        <a href="mi-perfil.php">Mi perfil</a>
        <a href="mis-direcciones.php">Mis direcciones</a>
        <a href="logout-cliente.php">Salir</a>
      <?php else: ?>
        <a href="login-cliente.php">INGRESAR</a>
        <a href="registro-cliente.php">REGISTRARSE</a>
      <?php endif; ?>
    </div>
  </nav>

  <!-- ============================================================
       SESIÓN 3 — EL PLANO MAESTRO DE LA MEMORIA (DER)
       Esto es lo que cada alumno debe lograr: tomar el catálogo
       (Sesión 1) y el Puente Digital (Sesión 2) y sumarles un
       registro real de clientes y pedidos, siguiendo el modelo
       relacional Cliente -> Pedido -> DetallePedido -> Pago.
       Código fuente original (Sesiones 3-7, simulado en localStorage,
       sin cuenta real): db-modelo.js. Sesión 8: el modelo pasó a
       tablas reales de MySQL ligadas a una cuenta con login —
       ver auth-cliente.php, registro-cliente.php, crear-pedido.php
       y pagar-pedido.php. El carrito (lo que aún NO es pedido) sigue
       viviendo en localStorage porque se arma en tienda.php y debe
       sobrevivir la navegación hasta aquí.
  ============================================================ -->
  <section id="mi-pedido_baycodec" class="pedido-section_baycodec">
    <h2>Mi Pedido</h2>
    <p class="pedido-subtitle_baycodec">
      Revisa los productos que agregaste desde el catálogo, genera tu cotización y,
      si quieres, paga en línea (sandbox). Quedará registrada en tu cuenta y te ayudaremos
      a confirmarla por WhatsApp.
    </p>

    <?php if ($clienteActual_baycodec): ?>
      <div class="pedido-cuenta_baycodec">
        Pedido a nombre de <strong><?= htmlspecialchars($clienteActual_baycodec['nombre'], ENT_QUOTES, 'UTF-8') ?></strong>
        (<?= htmlspecialchars($clienteActual_baycodec['tipo_cliente'], ENT_QUOTES, 'UTF-8') ?>)
        · <a href="logout-cliente.php">No soy yo, salir</a>
      </div>
    <?php else: ?>
      <div class="pedido-cuenta_baycodec pedido-cuenta-anonima_baycodec">
        Para generar y pagar tu pedido necesitas una cuenta (elige si compras como persona individual,
        empresa o revendedor).
        <div style="margin-top:10px;">
          <a class="pd-btn_baycodec" href="login-cliente.php">Ingresar</a>
          <a class="pd-btn_baycodec secundario_baycodec" href="registro-cliente.php">Crear cuenta</a>
        </div>
      </div>
    <?php endif; ?>

    <div id="mp-carrito_baycodec" class="pedido-carrito_baycodec"></div>

    <?php if ($clienteActual_baycodec && !empty($misDireccionesCarrito_baycodec)): ?>
      <div class="pedido-direccion_baycodec">
        <label for="mp-direccion_baycodec">Enviar a:</label>
        <select id="mp-direccion_baycodec">
          <?php foreach ($misDireccionesCarrito_baycodec as $d_baycodec): ?>
            <option value="<?= (int) $d_baycodec['id'] ?>" <?= $d_baycodec['predeterminada'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($d_baycodec['etiqueta'], ENT_QUOTES, 'UTF-8') ?> — <?= htmlspecialchars($d_baycodec['direccion'], ENT_QUOTES, 'UTF-8') ?>
            </option>
          <?php endforeach; ?>
        </select>
        <a href="mis-direcciones.php" class="pedido-direccion-agregar_baycodec">+ Agregar otra dirección</a>
      </div>
    <?php endif; ?>

    <?php if (!empty($tarifasEnvioCarrito_baycodec)): ?>
      <div class="pedido-direccion_baycodec">
        <label for="mp-zona-envio_baycodec">Envío a la zona:</label>
        <select id="mp-zona-envio_baycodec" onchange="mpPintarCarrito_baycodec()">
          <?php foreach ($tarifasEnvioCarrito_baycodec as $t_baycodec): ?>
            <option value="<?= htmlspecialchars($t_baycodec['zona'], ENT_QUOTES, 'UTF-8') ?>" data-costo="<?= (float) $t_baycodec['costo'] ?>">
              <?= htmlspecialchars($t_baycodec['zona'], ENT_QUOTES, 'UTF-8') ?>
              — <?= (float) $t_baycodec['costo'] > 0 ? 'S/ ' . number_format((float) $t_baycodec['costo'], 2) : 'Gratis' ?>
              <?= $t_baycodec['dias_estimados'] ? '(' . htmlspecialchars($t_baycodec['dias_estimados'], ENT_QUOTES, 'UTF-8') . ')' : '' ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
    <?php endif; ?>

    <div class="pedido-cupon_baycodec">
      <input type="text" id="mp-cupon_baycodec" placeholder="¿Tienes un cupón? Escríbelo aquí">
      <button type="button" class="pd-btn_baycodec secundario_baycodec" onclick="mpAplicarCupon_baycodec()">Aplicar cupón</button>
    </div>
    <p id="mp-cupon-resultado_baycodec" class="pedido-cupon-resultado_baycodec"></p>

    <button class="pd-btn_baycodec" onclick="mpGenerarPedido_baycodec()">Generar pedido</button>
    <a class="pd-btn_baycodec secundario_baycodec" href="tienda.php" style="display:inline-block; text-decoration:none;">← Seguir comprando</a>
    <p id="mp-resultado_baycodec" class="pedido-resultado_baycodec"></p>

    <!-- SESIÓN 7: pago sandbox del pedido recién generado -->
    <div id="mp-pago_baycodec" class="pedido-pago_baycodec" style="display:none;">
      <h3>Pagar este pedido (Sandbox)</h3>
      <p class="pedido-pago-tarjetas_baycodec">
        Tarjetas de prueba: <code>4242 4242 4242 4242</code> (éxito) ·
        <code>4000 0000 0000 0002</code> (rechazada)
      </p>

      <!-- Referencia visual: de dónde se saca el número de tarjeta, igual
           que muestran las pasarelas reales (Stripe, MercadoPago, etc.)
           junto a su campo de pago. -->
      <div class="pedido-pago-referencia_baycodec">
        <div class="mini-tarjeta_baycodec">
          <div class="mini-tarjeta-chip_baycodec"></div>
          <div class="mini-tarjeta-numero_baycodec">•••• •••• •••• ••••</div>
          <div class="mini-tarjeta-marca_baycodec">VISA</div>
        </div>
        <p class="pedido-pago-referencia-texto_baycodec">
          👆 Son los <strong>16 dígitos</strong> que están en el <strong>frente</strong> de la tarjeta (física o virtual,
          del banco o de una billetera digital). Cópialos sin espacios ni guiones en el campo de abajo.
        </p>
      </div>

      <div class="pedido-pago-form_baycodec">
        <input type="text" id="mp-tarjeta_baycodec" placeholder="Número de tarjeta" maxlength="19">
        <button class="pd-btn_baycodec" id="mp-btn-pagar_baycodec" onclick="mpPagar_baycodec()">💳 Pagar</button>
      </div>
      <p id="mp-pago-resultado_baycodec" class="pedido-pago-resultado_baycodec"></p>
      <p class="pedido-pago-nota-comprobante_baycodec">⚠️ Sandbox educativo: un pago exitoso aquí no emite boleta ni factura electrónica ante SUNAT
        (ver la nota técnica en <code>pagar-pedido.php</code> sobre qué haría falta para eso).</p>
    </div>
  </section>

  <footer>
    <p>© 2025 Grafiluz - Catálogo de Productos Publicitarios</p>
    <p>Creado por Baycodec - 941233826</p>
    <p class="footer-legal_baycodec">
      <a href="politica-privacidad.html">Política de Privacidad</a> ·
      <a href="terminos-servicio.html">Términos de Servicio</a>
    </p>
  </footer>

  <script src="script.js"></script>
  <script src="motor-analitica.js"></script>
  <script>
    trackVisita_baycodec();

    // ============================================================
    // Carrito compartido con tienda.php via localStorage: ahí se
    // agregan los productos (botón 🛒 en cada tarjeta), aquí se
    // revisan/quitan y se generan como pedido real (crear-pedido.php).
    // ============================================================
    const CARRITO_CLAVE_baycodec = 'grafiluz-carrito-baycodec';
    const CLIENTE_CONECTADO_baycodec = <?= $clienteActual_baycodec ? 'true' : 'false' ?>;
    // Configuración del sitio (mejora post-Sesión 8): el número de
    // WhatsApp ya no está escrito a mano aquí — sale de la tabla
    // configuracion (ver admin-configuracion.php).
    const WHATSAPP_NUMERO_baycodec = '<?= addslashes(obtenerConfiguracion_baycodec($pdo_baycodec, 'whatsapp_numero', '51930910829')) ?>';
    let mpPedidoActivoId = null; // pedido pendiente de pago
    let mpCuponCodigoAplicado_baycodec = null; // código ya validado con validar-cupon.php
    let mpDescuentoEstimado_baycodec = 0; // monto de descuento del cupón aplicado, para el resumen

    function carritoLeer_baycodec() {
      try { return JSON.parse(localStorage.getItem(CARRITO_CLAVE_baycodec)) || {}; }
      catch { return {}; }
    }
    function carritoGuardar_baycodec() {
      localStorage.setItem(CARRITO_CLAVE_baycodec, JSON.stringify(carrito));

      // Carrito persistente en servidor (mejora post-Sesión 8): misma
      // sincronización "en segundo plano" que en tienda.php.
      if (CLIENTE_CONECTADO_baycodec) {
        fetch('guardar-carrito.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ items: carrito }),
        }).catch(() => {});
      }
    }

    /**
     * Si el carrito local (localStorage de ESTE navegador) está vacío
     * pero el cliente tiene sesión iniciada, intenta recuperar el
     * carrito guardado en el servidor (ver obtener-carrito.php) — por
     * ejemplo, si agregó productos desde el celular y ahora entra
     * desde la laptop. Si el carrito local YA tiene algo, se respeta
     * tal cual (no se sobrescribe lo que el visitante está viendo).
     */
    async function carritoRestaurarDesdeServidor_baycodec() {
      if (!CLIENTE_CONECTADO_baycodec || Object.keys(carrito).length > 0) return;

      try {
        const respuesta = await fetch('obtener-carrito.php');
        const resultado = await respuesta.json();
        if (resultado.ok && Object.keys(resultado.items).length > 0) {
          carrito = resultado.items;
          carritoGuardar_baycodec();
          mpPintarCarrito_baycodec();
        }
      } catch (e) {
        // Sin conexión o el endpoint no respondió: el carrito sigue
        // vacío, sin romper nada — el visitante puede seguir comprando.
      }
    }

    let carrito = carritoLeer_baycodec(); // { [productoId]: { nombre, precio, cantidad } }

    function carritoQuitar_baycodec(id) {
      if (!carrito[id]) return;
      carrito[id].cantidad--;
      if (carrito[id].cantidad <= 0) delete carrito[id];
      carritoGuardar_baycodec();
      mpPintarCarrito_baycodec();
    }

    function mpPintarCarrito_baycodec() {
      const contenedor = document.getElementById('mp-carrito_baycodec');
      const ids = Object.keys(carrito);

      if (ids.length === 0) {
        contenedor.innerHTML = '<p class="pedido-carrito-vacio_baycodec">Tu carrito está vacío. <a href="tienda.php">Vuelve al catálogo</a> y agrega productos con el botón 🛒 Agregar de cada tarjeta.</p>';
        return;
      }

      const filas = ids.map((id) => {
        const item = carrito[id];
        const subtotal = (item.precio * item.cantidad).toFixed(2);
        return `
          <div class="pedido-item_baycodec">
            <span>${item.cantidad} x ${item.nombre} <span class="pedido-item-precio_baycodec">S/ ${subtotal}</span></span>
            <button type="button" class="pedido-item-quitar_baycodec" onclick="carritoQuitar_baycodec('${id}')" title="Quitar una unidad">−</button>
          </div>
        `;
      }).join('');

      const subtotal = ids.reduce((acc, id) => acc + carrito[id].precio * carrito[id].cantidad, 0);
      const selectZona = document.getElementById('mp-zona-envio_baycodec');
      const costoEnvio = selectZona ? parseFloat(selectZona.selectedOptions[0].dataset.costo) || 0 : 0;
      const totalConEnvio = Math.max(0, subtotal - mpDescuentoEstimado_baycodec + costoEnvio);

      let lineasResumen = `<div class="pedido-carrito-resumen-linea_baycodec"><span>Subtotal</span><span>S/ ${subtotal.toFixed(2)}</span></div>`;
      if (mpDescuentoEstimado_baycodec > 0) {
        lineasResumen += `<div class="pedido-carrito-resumen-linea_baycodec"><span>Descuento (${mpCuponCodigoAplicado_baycodec})</span><span>− S/ ${mpDescuentoEstimado_baycodec.toFixed(2)}</span></div>`;
      }
      if (selectZona) {
        lineasResumen += `<div class="pedido-carrito-resumen-linea_baycodec"><span>Envío</span><span>${costoEnvio > 0 ? 'S/ ' + costoEnvio.toFixed(2) : 'Gratis'}</span></div>`;
      }

      contenedor.innerHTML = filas + `<div class="pedido-carrito-total_baycodec">${lineasResumen}<div class="pedido-carrito-resumen-linea_baycodec pedido-carrito-resumen-total_baycodec"><span>Total estimado</span><span>S/ ${totalConEnvio.toFixed(2)}</span></div></div>`;
    }

    async function mpAplicarCupon_baycodec() {
      const codigo = document.getElementById('mp-cupon_baycodec').value.trim();
      const resultadoEl = document.getElementById('mp-cupon-resultado_baycodec');
      if (!codigo) { resultadoEl.textContent = 'Escribe un código de cupón.'; resultadoEl.style.color = '#dc2626'; return; }

      const subtotal = Object.values(carrito).reduce((acc, item) => acc + item.precio * item.cantidad, 0);

      const respuesta = await fetch('validar-cupon.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ codigo_cupon: codigo, subtotal }),
      });
      const resultado = await respuesta.json();

      if (!resultado.ok) {
        mpCuponCodigoAplicado_baycodec = null;
        mpDescuentoEstimado_baycodec = 0;
        resultadoEl.textContent = `⚠️ ${resultado.mensaje}`;
        resultadoEl.style.color = '#dc2626';
        mpPintarCarrito_baycodec();
        return;
      }

      mpCuponCodigoAplicado_baycodec = codigo;
      mpDescuentoEstimado_baycodec = resultado.descuento;
      resultadoEl.textContent = `✅ Cupón aplicado: ${resultado.descripcion}`;
      resultadoEl.style.color = '#16a34a';
      mpPintarCarrito_baycodec();
    }

    async function mpGenerarPedido_baycodec() {
      if (!CLIENTE_CONECTADO_baycodec) {
        alert('Inicia sesión o crea una cuenta para generar tu pedido.');
        window.location.href = 'login-cliente.php';
        return;
      }

      const ids = Object.keys(carrito);
      if (ids.length === 0) { alert('Tu carrito está vacío. Agrega productos desde el catálogo.'); return; }

      const items = ids.map((id) => ({ id, cantidad: carrito[id].cantidad }));
      const selectDireccion = document.getElementById('mp-direccion_baycodec');
      const selectZona = document.getElementById('mp-zona-envio_baycodec');

      const respuesta = await fetch('crear-pedido.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items,
          direccion_id: selectDireccion ? parseInt(selectDireccion.value, 10) : 0,
          codigo_cupon: mpCuponCodigoAplicado_baycodec || '',
          zona_envio: selectZona ? selectZona.value : '',
        }),
      });
      const resultado = await respuesta.json();

      if (!resultado.ok) {
        alert(resultado.mensaje || 'No se pudo generar el pedido.');
        return;
      }

      registrarEvento_baycodec('pedido_generado', { total: resultado.total });

      mpPedidoActivoId = resultado.pedido_id;

      const lineaDescuento = resultado.descuento_aplicado > 0
        ? `<br>🏷️ Descuento aplicado: S/ ${resultado.descuento_aplicado.toFixed(2)}`
        : '';
      const lineaEnvio = resultado.envio_costo > 0
        ? `<br>🚚 Envío (${resultado.envio_zona}): S/ ${resultado.envio_costo.toFixed(2)}`
        : (resultado.envio_zona ? `<br>🚚 Envío (${resultado.envio_zona}): Gratis` : '');
      const lineaDireccion = resultado.direccion_envio
        ? `<br>📍 Se enviará a: ${resultado.direccion_envio}`
        : '';

      document.getElementById('mp-resultado_baycodec').innerHTML = `
        ✅ Pedido #${resultado.pedido_id} registrado — Total S/ ${resultado.total.toFixed(2)} (Pago #${resultado.pago_id}: <em id="mp-estado-pago_baycodec">Pendiente</em>).
        ${lineaDescuento}${lineaEnvio}${lineaDireccion}
        <br><a class="pd-btn_baycodec" style="display:inline-block;margin-top:10px;text-decoration:none;"
           href="https://wa.me/${WHATSAPP_NUMERO_baycodec}?text=${encodeURIComponent(`Hola, quiero confirmar mi Pedido #${resultado.pedido_id} (${resultado.resumen}). Total referencial: S/ ${resultado.total.toFixed(2)}.`)}"
           target="_blank">Confirmar por WhatsApp</a>
      `;

      // El pedido ya quedó registrado: vaciamos el carrito para el siguiente.
      carrito = {};
      mpCuponCodigoAplicado_baycodec = null;
      mpDescuentoEstimado_baycodec = 0;
      carritoGuardar_baycodec();
      mpPintarCarrito_baycodec();
      mpCuponCodigoAplicado_baycodec = null;
      document.getElementById('mp-cupon_baycodec').value = '';
      document.getElementById('mp-cupon-resultado_baycodec').textContent = '';

      // Sesión 7: habilita el pago en línea de este pedido
      document.getElementById('mp-pago_baycodec').style.display = 'block';
      document.getElementById('mp-pago-resultado_baycodec').textContent = '';
      document.getElementById('mp-tarjeta_baycodec').value = '';
    }

    async function mpPagar_baycodec() {
      if (!mpPedidoActivoId) { alert('Primero genera un pedido.'); return; }

      const boton = document.getElementById('mp-btn-pagar_baycodec');
      boton.disabled = true;
      boton.textContent = '⏳ Procesando...';

      const respuesta = await fetch('pagar-pedido.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pedido_id: mpPedidoActivoId,
          numero_tarjeta: document.getElementById('mp-tarjeta_baycodec').value,
        }),
      });
      const resultado = await respuesta.json();

      const divResultado = document.getElementById('mp-pago-resultado_baycodec');
      if (resultado.exito) {
        divResultado.className = 'pedido-pago-resultado_baycodec exito_baycodec';
        divResultado.textContent = `✅ Pago exitoso — transacción ${resultado.transaccion_id}. El webhook actualizó tu pedido a "Pagado".`;
        const estadoPago = document.getElementById('mp-estado-pago_baycodec');
        if (estadoPago) estadoPago.textContent = 'Pagado';
        registrarEvento_baycodec('pago_exitoso', { pedidoId: mpPedidoActivoId });
      } else {
        divResultado.className = 'pedido-pago-resultado_baycodec error_baycodec';
        divResultado.textContent = `❌ ${resultado.mensaje}`;
        registrarEvento_baycodec('pago_rechazado', { pedidoId: mpPedidoActivoId, motivo: resultado.motivo });
      }

      boton.disabled = false;
      boton.textContent = '💳 Pagar';
    }

    mpPintarCarrito_baycodec();
    carritoRestaurarDesdeServidor_baycodec();
  </script>
</body>
</html>
