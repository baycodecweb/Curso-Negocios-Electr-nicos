<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// LISTAR PEDIDOS REALES (endpoint JSON) — Sesión 8
// ------------------------------------------------------------
// Lo que panel-control.html leía como "Pedidos y pagos" (Sesión 7)
// venía de la base de datos simulada en localStorage (db-modelo.js) —
// solo existía en el navegador de quien navegaba. Ahora que los
// pedidos se guardan de verdad en MySQL (crear-pedido.php,
// pagar-pedido.php), este endpoint los expone para el panel.
//
// Nota de ética/seguridad: esto son datos de clientes (nombre, total
// de su compra) — por eso exige la MISMA sesión de administrador que
// admin-productos.php, no queda abierto para cualquiera.
// ============================================================

require_once __DIR__ . '/auth-admin.php';

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['admin_usuario_baycodec'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión en el panel de administración.']);
    exit;
}

$filas_baycodec = $pdo_baycodec->query(
    'SELECT p.id, c.nombre AS cliente_nombre, p.total, p.estado,
            pg.estado AS pago_estado, pg.transaccion_id
     FROM pedidos_tb_baycodec p
     JOIN clientes_tb_baycodec c ON c.id = p.cliente_id
     LEFT JOIN pagos_tb_baycodec pg ON pg.pedido_id = p.id
     ORDER BY p.id DESC'
)->fetchAll();

echo json_encode(['ok' => true, 'pedidos' => $filas_baycodec]);
