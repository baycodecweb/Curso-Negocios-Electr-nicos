<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// PAGAR PEDIDO (endpoint JSON) — Sesión 8
// ------------------------------------------------------------
// Misma sandbox de pasarela-pago.js (Sesión 7: algoritmo de Luhn +
// las mismas tarjetas de prueba de Stripe), pero corriendo en el
// servidor y actualizando el pedido REAL de la base de datos, en vez
// de simular el "webhook" contra localStorage.
//
// Verifica que el pedido pertenezca al cliente que tiene la sesión
// iniciada — nunca se confía en el pedido_id que mande el navegador
// sin comprobar de quién es.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

$cliente_baycodec = clienteActual_baycodec();
if (!$cliente_baycodec) {
    http_response_code(401);
    echo json_encode(['exito' => false, 'mensaje' => 'Debes iniciar sesión para pagar un pedido.']);
    exit;
}

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$pedidoId_baycodec = (int) ($cuerpo_baycodec['pedido_id'] ?? 0);
$numeroTarjeta_baycodec = preg_replace('/\s+/', '', (string) ($cuerpo_baycodec['numero_tarjeta'] ?? ''));

$consultaPedido_baycodec = $pdo_baycodec->prepare('SELECT * FROM pedidos_tb_baycodec WHERE id = ? AND cliente_id = ?');
$consultaPedido_baycodec->execute([$pedidoId_baycodec, $cliente_baycodec['id']]);
$pedido_baycodec = $consultaPedido_baycodec->fetch();

if (!$pedido_baycodec) {
    http_response_code(404);
    echo json_encode(['exito' => false, 'mensaje' => 'Ese pedido no existe o no te pertenece.']);
    exit;
}

/** Algoritmo de Luhn real, el mismo que usan las tarjetas de crédito reales. */
function validarLuhn_baycodec($numero) {
    if (!preg_match('/^\d{13,19}$/', $numero)) {
        return false;
    }
    $suma = 0;
    $alternar = false;
    for ($i = strlen($numero) - 1; $i >= 0; $i--) {
        $digito = (int) $numero[$i];
        if ($alternar) {
            $digito *= 2;
            if ($digito > 9) {
                $digito -= 9;
            }
        }
        $suma += $digito;
        $alternar = !$alternar;
    }
    return $suma % 10 === 0;
}

const TARJETAS_DE_PRUEBA_BAYCODEC = [
    '4242424242424242' => 'exito',
    '4000000000000002' => 'rechazada',
    '4000000000009995' => 'fondos_insuficientes',
];

const MENSAJES_RECHAZO_BAYCODEC = [
    'numero_invalido' => 'El número de tarjeta no es válido (no pasa la verificación de Luhn).',
    'rechazada' => 'Tu banco rechazó la operación (tarjeta de prueba de rechazo).',
    'fondos_insuficientes' => 'Fondos insuficientes (tarjeta de prueba).',
];

if (!validarLuhn_baycodec($numeroTarjeta_baycodec)) {
    echo json_encode(['exito' => false, 'motivo' => 'numero_invalido', 'mensaje' => MENSAJES_RECHAZO_BAYCODEC['numero_invalido']]);
    exit;
}

$escenario_baycodec = TARJETAS_DE_PRUEBA_BAYCODEC[$numeroTarjeta_baycodec] ?? 'exito';

if ($escenario_baycodec !== 'exito') {
    $pdo_baycodec->prepare('UPDATE pagos_tb_baycodec SET estado = ? WHERE pedido_id = ?')->execute(['Rechazado', $pedidoId_baycodec]);
    registrarNotificacion_baycodec(
        $pdo_baycodec,
        $cliente_baycodec['id'],
        'pago_rechazado',
        "Tu pago del Pedido #{$pedidoId_baycodec} fue rechazado — Grafiluz",
        MENSAJES_RECHAZO_BAYCODEC[$escenario_baycodec]
    );
    echo json_encode(['exito' => false, 'motivo' => $escenario_baycodec, 'mensaje' => MENSAJES_RECHAZO_BAYCODEC[$escenario_baycodec]]);
    exit;
}

// ------------------------------------------------------------
// Stock (mejora post-Sesión 8): se descuenta recién AQUÍ, al
// confirmarse el pago — no al generar el pedido (crear-pedido.php),
// porque un pedido "Pendiente" puede quedar abandonado para siempre y
// no debería bloquear stock de otros compradores mientras tanto. Solo
// se valida/descuenta en los productos que SÍ tienen control de stock
// (stock no es NULL); los demás siguen vendiéndose siempre, igual que
// antes de esta mejora.
// ------------------------------------------------------------
$itemsPedido_baycodec = $pdo_baycodec->prepare('SELECT producto_codigo, producto_nombre, cantidad, precio_unitario, vendedor_id, variante_id, variante_nombre FROM detalle_pedido_tb_baycodec WHERE pedido_id = ?');
$itemsPedido_baycodec->execute([$pedidoId_baycodec]);
$detallePedido_baycodec = $itemsPedido_baycodec->fetchAll();

// Variantes de producto (mejora post-Sesión 8): si la línea tiene
// variante, el stock que manda es el de LA VARIANTE (producto_
// variantes.stock), no el del producto — el stock a nivel de producto
// queda reservado para productos SIN variantes.
$consultaStockActual_baycodec = $pdo_baycodec->prepare('SELECT stock FROM productos_tb_baycodec WHERE codigo = ?');
$consultaStockVarianteActual_baycodec = $pdo_baycodec->prepare('SELECT stock FROM producto_variantes_tb_baycodec WHERE id = ?');
foreach ($detallePedido_baycodec as $itemDetalle_baycodec) {
    if ($itemDetalle_baycodec['variante_id']) {
        $consultaStockVarianteActual_baycodec->execute([$itemDetalle_baycodec['variante_id']]);
        $stockActual_baycodec = $consultaStockVarianteActual_baycodec->fetchColumn();
    } else {
        $consultaStockActual_baycodec->execute([$itemDetalle_baycodec['producto_codigo']]);
        $stockActual_baycodec = $consultaStockActual_baycodec->fetchColumn();
    }

    if ($stockActual_baycodec !== false && $stockActual_baycodec !== null && (int) $stockActual_baycodec < (int) $itemDetalle_baycodec['cantidad']) {
        $nombreParaMensaje_baycodec = $itemDetalle_baycodec['producto_nombre'] . ($itemDetalle_baycodec['variante_nombre'] ? " ({$itemDetalle_baycodec['variante_nombre']})" : '');
        echo json_encode([
            'exito' => false,
            'motivo' => 'sin_stock',
            'mensaje' => "Ya no hay stock suficiente de \"{$nombreParaMensaje_baycodec}\" (quedan {$stockActual_baycodec}). El pago no se procesó.",
        ]);
        exit;
    }
}

$transaccionId_baycodec = 'sim_' . base_convert((string) time(), 10, 36) . substr(bin2hex(random_bytes(3)), 0, 4);

$pdo_baycodec->beginTransaction();

$pdo_baycodec->prepare('UPDATE pedidos_tb_baycodec SET estado = "Pagado" WHERE id = ?')->execute([$pedidoId_baycodec]);
$pdo_baycodec->prepare(
    'UPDATE pagos_tb_baycodec SET estado = "Pagado", metodo = "Tarjeta (sandbox)", transaccion_id = ? WHERE pedido_id = ?'
)->execute([$transaccionId_baycodec, $pedidoId_baycodec]);

$descontarStock_baycodec = $pdo_baycodec->prepare('UPDATE productos_tb_baycodec SET stock = stock - ? WHERE codigo = ? AND stock IS NOT NULL');
$descontarStockVariante_baycodec = $pdo_baycodec->prepare('UPDATE producto_variantes_tb_baycodec SET stock = stock - ? WHERE id = ?');
$registrarSalida_baycodec = $pdo_baycodec->prepare('INSERT INTO movimientos_inventario_tb_baycodec (producto_codigo, tipo, cantidad, motivo) VALUES (?, "salida", ?, ?)');
foreach ($detallePedido_baycodec as $itemDetalle_baycodec) {
    if ($itemDetalle_baycodec['variante_id']) {
        $descontarStockVariante_baycodec->execute([$itemDetalle_baycodec['cantidad'], $itemDetalle_baycodec['variante_id']]);
        $registrarSalida_baycodec->execute([
            $itemDetalle_baycodec['producto_codigo'],
            $itemDetalle_baycodec['cantidad'],
            "Venta variante \"{$itemDetalle_baycodec['variante_nombre']}\" — Pedido #{$pedidoId_baycodec}",
        ]);
        continue;
    }
    $descontarStock_baycodec->execute([$itemDetalle_baycodec['cantidad'], $itemDetalle_baycodec['producto_codigo']]);
    if ($descontarStock_baycodec->rowCount() > 0) {
        $registrarSalida_baycodec->execute([$itemDetalle_baycodec['producto_codigo'], $itemDetalle_baycodec['cantidad'], "Venta — Pedido #{$pedidoId_baycodec}"]);
    }
}

// ------------------------------------------------------------
// Comisión del marketplace (mejora post-Sesión 8): Grafiluz es un
// marketplace con vendedores C2C — cada línea vendida por un
// vendedor (vendedor_id no nulo) genera una fila en "comisiones" con
// el porcentaje VIGENTE ahora (configuracion.comision_marketplace_
// porcentaje), agrupada por vendedor (un vendedor puede tener varias
// líneas en el mismo pedido). Sin esto, "marketplace" era solo un
// catálogo compartido, no un negocio con reparto de ingresos real —
// ver admin-comisiones.php y "Mis ganancias" en mis-productos.php.
// ------------------------------------------------------------
$ventasPorVendedor_baycodec = [];
foreach ($detallePedido_baycodec as $itemDetalle_baycodec) {
    if (!$itemDetalle_baycodec['vendedor_id']) {
        continue; // catálogo oficial de Grafiluz: no hay comisión que calcular
    }
    $vendedorId_pp_baycodec = (int) $itemDetalle_baycodec['vendedor_id'];
    $montoLinea_baycodec = (float) $itemDetalle_baycodec['precio_unitario'] * (int) $itemDetalle_baycodec['cantidad'];
    $ventasPorVendedor_baycodec[$vendedorId_pp_baycodec] = ($ventasPorVendedor_baycodec[$vendedorId_pp_baycodec] ?? 0) + $montoLinea_baycodec;
}

if (!empty($ventasPorVendedor_baycodec)) {
    $porcentajeComision_baycodec = (float) obtenerConfiguracion_baycodec($pdo_baycodec, 'comision_marketplace_porcentaje', '10');
    $insertarComision_baycodec = $pdo_baycodec->prepare(
        'INSERT INTO comisiones_tb_baycodec (pedido_id, vendedor_id, monto_venta, porcentaje_comision, monto_comision, monto_vendedor)
         VALUES (?, ?, ?, ?, ?, ?)'
    );
    foreach ($ventasPorVendedor_baycodec as $vendedorId_pp_baycodec => $montoVenta_baycodec) {
        $montoComision_baycodec = round($montoVenta_baycodec * ($porcentajeComision_baycodec / 100), 2);
        $montoNetoVendedor_baycodec = round($montoVenta_baycodec - $montoComision_baycodec, 2);
        $insertarComision_baycodec->execute([
            $pedidoId_baycodec,
            $vendedorId_pp_baycodec,
            round($montoVenta_baycodec, 2),
            $porcentajeComision_baycodec,
            $montoComision_baycodec,
            $montoNetoVendedor_baycodec,
        ]);

        // El vendedor también se entera de que le vendieron algo — no
        // solo el comprador. Sin esto, "Quién me compró" en
        // mis-productos.php era la única forma de enterarse, y solo si
        // el vendedor entraba a revisar por su cuenta.
        registrarNotificacion_baycodec(
            $pdo_baycodec,
            $vendedorId_pp_baycodec,
            'venta_recibida',
            "¡Te hicieron una venta! Pedido #{$pedidoId_baycodec} — Grafiluz",
            "Vendiste S/ " . number_format($montoVenta_baycodec, 2) . " en el Pedido #{$pedidoId_baycodec}. Te corresponden S/ {$montoNetoVendedor_baycodec} (ya descontada la comisión de Grafiluz). Revisa el detalle en 'Mis ventas'."
        );
    }
}

$pdo_baycodec->commit();

registrarNotificacion_baycodec(
    $pdo_baycodec,
    $cliente_baycodec['id'],
    'pago_exitoso',
    "¡Pago confirmado! Pedido #{$pedidoId_baycodec} — Grafiluz",
    "Tu pago del Pedido #{$pedidoId_baycodec} se confirmó (transacción {$transaccionId_baycodec}). Tu pedido ya está en preparación."
);

// ============================================================
// NOTA (no implementado a propósito): COMPROBANTE ELECTRÓNICO (SUNAT)
// ------------------------------------------------------------
// Un pago exitoso aquí NO emite boleta ni factura electrónica — el
// pedido queda "Pagado" en la base de datos, pero no existe ningún
// documento tributario real asociado.
//
// Por qué importa en un e-commerce peruano real:
//   - Por ley, toda venta debe emitir un comprobante válido ante
//     SUNAT (boleta para B2C, factura con RUC para B2B) dentro de un
//     plazo corto tras el pago.
//   - Sin esto, Grafiluz no podría operar de forma legal más allá de
//     una prueba de concepto/demo educativa.
//
// Cómo se implementaría (sin tocar el flujo de arriba):
//   1. Agregar una tabla "comprobantes" (pedido_id, tipo boleta/
//      factura, serie, numero_correlativo, xml, pdf_url, estado_sunat,
//      creado_en).
//   2. Contratar un Proveedor de Servicios Electrónicos (PSE) o usar
//      el sistema gratuito de SUNAT (SEE) — ninguno de los dos es
//      gratis de integrar ni instantáneo de aprobar como alumno.
//   3. Aquí mismo, tras el commit exitoso, llamar a la API de ese PSE
//      con los datos del pedido (cliente, items, total) para generar
//      el XML firmado digitalmente y obtener el CDR (Constancia de
//      Recepción) de SUNAT.
//   4. Guardar el PDF/XML resultante en "comprobantes" y ofrecer su
//      descarga desde mis-pedidos.php.
//
// No se implementó porque requiere credenciales reales de un PSE (o
// certificado digital + homologación con SUNAT) que este entorno de
// práctica local no tiene — y facturar "de mentira" sería enseñar un
// mal hábito, no un atajo razonable. Se documenta la brecha para que
// quede claro qué falta antes de operar Grafiluz como negocio real.
// ============================================================

echo json_encode(['exito' => true, 'transaccion_id' => $transaccionId_baycodec]);
