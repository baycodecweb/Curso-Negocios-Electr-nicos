var __marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Codigo del proyecto Grafiluz - adaptado y mantenido por baycodec

    let currentSlide = 0;
    const slides = document.querySelectorAll('.carousel-item_baycodec');
    const indicators = document.querySelectorAll('.indicator_baycodec');
    const totalSlides = slides.length;
    let autoSlideInterval;

    function showSlide_baycodec(index) {
      if (index >= totalSlides) currentSlide = 0;
      else if (index < 0) currentSlide = totalSlides - 1;
      else currentSlide = index;

      const offset = -currentSlide * 100;
      document.querySelector('.carousel-inner_baycodec').style.transform = `translateX(${offset}%)`;

      indicators.forEach((ind, i) => {
        ind.classList.toggle('active_baycodec', i === currentSlide);
      });
    }

    function nextSlide_baycodec() {
      showSlide_baycodec(currentSlide + 1);
      resetAutoSlide_baycodec();
    }

    function previousSlide_baycodec() {
      showSlide_baycodec(currentSlide - 1);
      resetAutoSlide_baycodec();
    }

    function goToSlide_baycodec(index) {
      showSlide_baycodec(index);
      resetAutoSlide_baycodec();
    }

    function startAutoSlide_baycodec() {
      autoSlideInterval = setInterval(() => {
        nextSlide_baycodec();
      }, 5000);
    }

    function resetAutoSlide_baycodec() {
      clearInterval(autoSlideInterval);
      startAutoSlide_baycodec();
    }

    startAutoSlide_baycodec();

    // ========== BOTÓN FLOTANTE PARA IR AL INICIO ==========
    const btnInicio = document.getElementById('btnInicio_baycodec');

    // Mostrar/ocultar botón según scroll
    window.addEventListener('scroll', () => {
      if (window.pageYOffset > 300) {
        btnInicio.classList.add('visible_baycodec');
      } else {
        btnInicio.classList.remove('visible_baycodec');
      }
    });

    // Función para ir al inicio con smooth scroll
    function irAlInicio_baycodec() {
      const target = document.querySelector('#inicio_baycodec');
      if (target) {
        const navHeight = document.querySelector('nav').offsetHeight;
        const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navHeight;
        
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    }

    // Smooth scroll para navegación (solo enlaces internos "#seccion";
    // los enlaces reales como login-cliente.php/registro-cliente.php
    // deben navegar normalmente, no interceptarse aquí).
    document.querySelectorAll('nav a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        const target = document.querySelector(targetId);
        
        if (target) {
          const navHeight = document.querySelector('nav').offsetHeight;
          const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navHeight;
          
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      });
    });

    // ========== MENÚ DESPLEGABLE "PRODUCTOS" EN EL NAV ==========
    // Cierra el <details> al elegir una categoría (el scroll ya la muestra,
    // no hace falta dejar el menú abierto) o al hacer clic fuera de él.
    document.querySelectorAll('.nav-dropdown_baycodec').forEach((menuDesplegable) => {
      menuDesplegable.querySelectorAll('a').forEach((enlace) => {
        enlace.addEventListener('click', () => menuDesplegable.removeAttribute('open'));
      });
    });

    document.addEventListener('click', (e) => {
      document.querySelectorAll('.nav-dropdown_baycodec[open]').forEach((menuDesplegable) => {
        if (!menuDesplegable.contains(e.target)) menuDesplegable.removeAttribute('open');
      });
    });

    // ========== AUTO-PLAY PARA CARRUSELES DE CARDS ==========
    const cardCarousels = new Map(); // Almacenar intervalos de cada card

    // Función para cambiar slide de card (manual o automático)
    function changeCardSlide_baycodec(button, direction) {
      const card = button.closest('.card_baycodec');
      changeCardSlideLogic_baycodec(card, direction);
      
      // Reiniciar auto-play después de interacción manual
      resetCardAutoPlay_baycodec(card);
    }

    // Lógica principal del cambio de slide
    function changeCardSlideLogic_baycodec(card, direction) {
      const carousel = card.querySelector('.card-carousel_baycodec');
      const inner = carousel.querySelector('.card-carousel-inner_baycodec');
      const items = carousel.querySelectorAll('.card-carousel-item_baycodec');
      const dots = carousel.querySelectorAll('.card-carousel-dot_baycodec');
      const infoItems = card.querySelectorAll('.card-info-item_baycodec');
      const totalItems = items.length;
      
      // Obtener el índice actual
      let currentIndex = 0;
      dots.forEach((dot, index) => {
        if (dot.classList.contains('active_baycodec')) {
          currentIndex = index;
        }
      });
      
      // Calcular nuevo índice
      let newIndex = currentIndex + direction;
      if (newIndex >= totalItems) newIndex = 0;
      if (newIndex < 0) newIndex = totalItems - 1;
      
      // Actualizar posición de imágenes
      const offset = -newIndex * 100;
      inner.style.transform = `translateX(${offset}%)`;
      
      // Actualizar dots
      dots.forEach((dot, index) => {
        dot.classList.toggle('active_baycodec', index === newIndex);
      });
      
      // Actualizar información del producto (solo si cada imagen del
      // carrusel tiene su propia info, como en el catálogo de ejemplo
      // de tienda.html). En tienda.php cada tarjeta es UN producto con
      // varias fotos y un solo bloque de info, así que no se toca.
      if (infoItems.length === totalItems) {
        infoItems.forEach((info, index) => {
          info.classList.toggle('active_baycodec', index === newIndex);
        });
      }
    }

    // Iniciar auto-play para una card específica
    function startCardAutoPlay_baycodec(card) {
      const items = card.querySelectorAll('.card-carousel-item_baycodec');
      
      // Solo iniciar si tiene más de 1 imagen
      if (items.length > 1) {
        const interval = setInterval(() => {
          changeCardSlideLogic_baycodec(card, 1); // Avanzar automáticamente
        }, 4000); // Cambia cada 4 segundos
        
        cardCarousels.set(card, interval);
      }
    }

    // Detener auto-play de una card
    function stopCardAutoPlay_baycodec(card) {
      if (cardCarousels.has(card)) {
        clearInterval(cardCarousels.get(card));
        cardCarousels.delete(card);
      }
    }

    // Reiniciar auto-play después de interacción manual
    function resetCardAutoPlay_baycodec(card) {
      stopCardAutoPlay_baycodec(card);
      startCardAutoPlay_baycodec(card);
    }

    // Inicializar auto-play para todas las cards al cargar la página
    document.addEventListener('DOMContentLoaded', () => {
      const allCards = document.querySelectorAll('.card_baycodec');
      
      allCards.forEach(card => {
        startCardAutoPlay_baycodec(card);
        
        // Pausar auto-play cuando el mouse está sobre la card
        card.addEventListener('mouseenter', () => {
          stopCardAutoPlay_baycodec(card);
        });
        
        // Reanudar auto-play cuando el mouse sale de la card
        card.addEventListener('mouseleave', () => {
          startCardAutoPlay_baycodec(card);
        });
      });
    });

    // También hacer que los dots sean clicables
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('card-carousel-dot_baycodec')) {
        const card = e.target.closest('.card_baycodec');
        const dots = card.querySelectorAll('.card-carousel-dot_baycodec');
        const clickedIndex = Array.from(dots).indexOf(e.target);
        const currentIndex = Array.from(dots).findIndex(dot => dot.classList.contains('active_baycodec'));
        const direction = clickedIndex - currentIndex;
        
        changeCardSlideLogic_baycodec(card, direction);
        resetCardAutoPlay_baycodec(card);
      }
    });
    // ========== FUNCIÓN PARA ENVIAR A WHATSAPP ==========
    function enviarWhatsApp_baycodec(event, nombreProducto) {
      event.preventDefault();

      // Sesión 5: registra el clic de interés (analítica en vivo), sin
      // cambiar en nada el comportamiento original de esta función.
      if (typeof registrarEvento_baycodec === 'function') {
        registrarEvento_baycodec('clic_whatsapp', { producto: nombreProducto });
      }

      // Número de WhatsApp de Grafiluz (formato internacional, sin + ni espacios).
      // Mejora post-Sesión 8: tienda.php define window.WHATSAPP_NUMERO_BAYCODEC
      // ANTES de cargar este script, leyéndolo de la tabla configuracion
      // (ver admin-configuracion.php) — este valor de aquí solo queda
      // como respaldo para tienda.html (la copia estática sin backend PHP).
      const numeroWhatsApp = window.WHATSAPP_NUMERO_BAYCODEC || '51930910829';

      // Mensaje personalizado
      const mensaje = `Hola, estoy interesado en: *${nombreProducto}*. ¿Podrías darme más información?`;

      // Codificar el mensaje para URL
      const mensajeCodificado = encodeURIComponent(mensaje);

      // Crear URL de WhatsApp
      const urlWhatsApp = `https://wa.me/${numeroWhatsApp}?text=${mensajeCodificado}`;

      // Abrir en nueva ventana
      window.open(urlWhatsApp, '_blank');
    }
