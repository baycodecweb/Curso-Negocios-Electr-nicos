<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// COMISIONES Y PAGOS A VENDEDORES — mejora post-Sesión 8
// ------------------------------------------------------------
// Por vendedor C2C: cuánto generó en ventas, cuánto le corresponde
// (monto_vendedor, ya con la comisión de Grafiluz descontada, ver
// pagar-pedido.php), cuánto ya se le pagó (pagos_vendedor) y el saldo
// pendiente. El admin registra aquí cada pago que realmente hace
// (transferencia, Yape, efectivo...) — esto NO envía dinero de
// verdad, solo lleva la cuenta.
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

$errorFormulario_baycodec = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'registrar_pago') {
    $vendedorId_baycodec = (int) ($_POST['vendedor_id'] ?? 0);
    $monto_baycodec = str_replace(',', '.', trim($_POST['monto'] ?? ''));
    $metodo_baycodec = trim($_POST['metodo'] ?? '');
    $referencia_baycodec = trim($_POST['referencia'] ?? '');

    if ($vendedorId_baycodec <= 0) {
        $errorFormulario_baycodec = 'Elige un vendedor.';
    } elseif (!is_numeric($monto_baycodec) || (float) $monto_baycodec <= 0) {
        $errorFormulario_baycodec = 'El monto debe ser un número mayor a 0.';
    } else {
        $pdo_baycodec->prepare('INSERT INTO pagos_vendedor_tb_baycodec (vendedor_id, monto, metodo, referencia) VALUES (?, ?, ?, ?)')
            ->execute([$vendedorId_baycodec, $monto_baycodec, $metodo_baycodec, $referencia_baycodec]);
        registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'registrar_pago_vendedor', $vendedorId_baycodec, 'S/ ' . $monto_baycodec);
        header('Location: admin-comisiones.php?guardado=1');
        exit;
    }
}

// Un vendedor por fila: total generado (monto_vendedor de comisiones),
// total ya pagado (pagos_vendedor) y el saldo = generado - pagado.
$vendedoresConComision_baycodec = $pdo_baycodec->query(
    "SELECT c.id, c.nombre,
            COALESCE((SELECT SUM(co.monto_vendedor) FROM comisiones_tb_baycodec co WHERE co.vendedor_id = c.id), 0) AS total_generado,
            COALESCE((SELECT SUM(pv.monto) FROM pagos_vendedor_tb_baycodec pv WHERE pv.vendedor_id = c.id), 0) AS total_pagado
     FROM clientes_tb_baycodec c
     WHERE c.tipo_cliente = 'C2C'
       AND EXISTS (SELECT 1 FROM comisiones_tb_baycodec co WHERE co.vendedor_id = c.id)
     ORDER BY c.nombre"
)->fetchAll();

$vendedoresDisponibles_baycodec = $pdo_baycodec->query("SELECT id, nombre FROM clientes_tb_baycodec WHERE tipo_cliente = 'C2C' ORDER BY nombre")->fetchAll();

$historialPagos_baycodec = $pdo_baycodec->query(
    'SELECT pv.*, c.nombre AS vendedor_nombre FROM pagos_vendedor_tb_baycodec pv JOIN clientes_tb_baycodec c ON c.id = pv.vendedor_id ORDER BY pv.id DESC LIMIT 25'
)->fetchAll();

function v_com_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Comisiones y Pagos a Vendedores — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 900px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"], input[type="number"], select { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .campos-en-fila_baycodec { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0 16px; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; }
  th { background: #f3f4f6; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .saldo-pendiente_baycodec { color: #92400e; font-weight: 600; }
  .saldo-al-dia_baycodec { color: #166534; font-weight: 600; }
</style>
</head>
<body>

<h1>💸 Comisiones y Pagos a Vendedores — Grafiluz</h1>
<p class="subtitulo_baycodec">Cuánto le corresponde a cada vendedor C2C (ya descontada la comisión de Grafiluz) y cuánto ya se le pagó.</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="admin-productos.php" style="background:#C41F25;">🛠️ Panel de Productos</a>
  <a class="btn_baycodec secundario_baycodec" href="admin-configuracion.php" style="margin-left:8px;">⚙️ Cambiar % de comisión</a>
</div>

<?php if (isset($_GET['guardado'])): ?><p class="exito_baycodec">✅ Pago registrado.</p><?php endif; ?>
<?php if ($errorFormulario_baycodec): ?><p class="error_baycodec">⚠️ <?= v_com_baycodec($errorFormulario_baycodec) ?></p><?php endif; ?>

<h2 style="font-size:1.1rem;">Saldo por vendedor</h2>
<table>
  <thead><tr><th>Vendedor</th><th>Generado (neto)</th><th>Ya pagado</th><th>Saldo pendiente</th></tr></thead>
  <tbody>
    <?php if (empty($vendedoresConComision_baycodec)): ?>
      <tr><td colspan="4" class="vacio_baycodec">(todavía no hay ventas C2C pagadas)</td></tr>
    <?php else: foreach ($vendedoresConComision_baycodec as $v_baycodec): ?>
      <?php $saldo_baycodec = (float) $v_baycodec['total_generado'] - (float) $v_baycodec['total_pagado']; ?>
      <tr>
        <td><?= v_com_baycodec($v_baycodec['nombre']) ?></td>
        <td>S/ <?= number_format((float) $v_baycodec['total_generado'], 2) ?></td>
        <td>S/ <?= number_format((float) $v_baycodec['total_pagado'], 2) ?></td>
        <td class="<?= $saldo_baycodec > 0.009 ? 'saldo-pendiente_baycodec' : 'saldo-al-dia_baycodec' ?>">S/ <?= number_format($saldo_baycodec, 2) ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

<h2 style="font-size:1.1rem;">➕ Registrar un pago a un vendedor</h2>
<div class="caja_baycodec">
  <form method="post" action="admin-comisiones.php">
    <input type="hidden" name="accion" value="registrar_pago">
    <div class="campos-en-fila_baycodec">
      <div>
        <label for="vendedor_id">Vendedor</label>
        <select id="vendedor_id" name="vendedor_id" required>
          <option value="">Elige...</option>
          <?php foreach ($vendedoresDisponibles_baycodec as $vd_baycodec): ?>
            <option value="<?= (int) $vd_baycodec['id'] ?>"><?= v_com_baycodec($vd_baycodec['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label for="monto">Monto (S/)</label>
        <input type="number" id="monto" name="monto" step="0.01" min="0.01" required>
      </div>
      <div>
        <label for="metodo">Método</label>
        <input type="text" id="metodo" name="metodo" placeholder="Ej: Yape, transferencia">
      </div>
    </div>
    <label for="referencia">Referencia (opcional)</label>
    <input type="text" id="referencia" name="referencia" placeholder="Ej: N° de operación">
    <button class="btn_baycodec" type="submit" style="margin-top:14px;">💾 Registrar pago</button>
  </form>
</div>

<h2 style="font-size:1.1rem;">Últimos pagos registrados</h2>
<table>
  <thead><tr><th>Fecha</th><th>Vendedor</th><th>Monto</th><th>Método</th><th>Referencia</th></tr></thead>
  <tbody>
    <?php if (empty($historialPagos_baycodec)): ?>
      <tr><td colspan="5" class="vacio_baycodec">(sin pagos registrados)</td></tr>
    <?php else: foreach ($historialPagos_baycodec as $p_baycodec): ?>
      <tr>
        <td><?= v_com_baycodec(date('d/m/Y', strtotime($p_baycodec['creado_en']))) ?></td>
        <td><?= v_com_baycodec($p_baycodec['vendedor_nombre']) ?></td>
        <td>S/ <?= number_format((float) $p_baycodec['monto'], 2) ?></td>
        <td><?= v_com_baycodec($p_baycodec['metodo']) ?: '—' ?></td>
        <td><?= v_com_baycodec($p_baycodec['referencia']) ?: '—' ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

</body>
</html>
