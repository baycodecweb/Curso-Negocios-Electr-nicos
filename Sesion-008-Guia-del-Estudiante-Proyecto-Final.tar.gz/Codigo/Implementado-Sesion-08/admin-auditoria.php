<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// PANEL DE AUDITORÍA DEL ADMIN — mejora post-Sesión 8
// ------------------------------------------------------------
// Visor de auditoria_admin (ver db-conexion.php / registrarAuditoriaAdmin_baycodec()):
// qué acción destructiva/sensible hizo el panel de admin, cuándo y
// sobre qué. Solo lectura — no se puede editar ni borrar el historial
// desde aquí, para que siga sirviendo como registro confiable.
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

const FILAS_POR_PAGINA_AUDITORIA_BAYCODEC = 25;
$paginaAuditoria_baycodec = max(1, (int) ($_GET['pagina'] ?? 1));

$totalRegistros_baycodec = (int) $pdo_baycodec->query('SELECT COUNT(*) FROM auditoria_admin_tb_baycodec')->fetchColumn();
$totalPaginasAuditoria_baycodec = max(1, (int) ceil($totalRegistros_baycodec / FILAS_POR_PAGINA_AUDITORIA_BAYCODEC));
$paginaAuditoria_baycodec = min($paginaAuditoria_baycodec, $totalPaginasAuditoria_baycodec);

$consultaAuditoria_baycodec = $pdo_baycodec->prepare('SELECT * FROM auditoria_admin_tb_baycodec ORDER BY id DESC LIMIT :limite OFFSET :offset');
$consultaAuditoria_baycodec->bindValue(':limite', FILAS_POR_PAGINA_AUDITORIA_BAYCODEC, PDO::PARAM_INT);
$consultaAuditoria_baycodec->bindValue(':offset', ($paginaAuditoria_baycodec - 1) * FILAS_POR_PAGINA_AUDITORIA_BAYCODEC, PDO::PARAM_INT);
$consultaAuditoria_baycodec->execute();
$registrosAuditoria_baycodec = $consultaAuditoria_baycodec->fetchAll();

$ETIQUETAS_ACCION_BAYCODEC = [
    'crear_producto'     => '➕ Creó un producto',
    'editar_producto'    => '✏️ Editó un producto',
    'eliminar_producto'  => '🗑️ Eliminó un producto',
    'cancelar_pedido'    => '✖ Canceló un pedido',
    'reembolsar_pedido'  => '↩ Reembolsó un pedido',
    'crear_cupon'        => '🏷️ Creó un cupón',
    'alternar_cupon'     => '⏯ Activó/pausó un cupón',
    'eliminar_cupon'     => '🗑️ Eliminó un cupón',
    'reiniciar_analitica' => '🔄 Reinició los datos de analítica',
    'editar_configuracion' => '⚙️ Editó la configuración del sitio',
    'crear_tarifa_envio' => '🚚 Creó una tarifa de envío',
    'eliminar_tarifa_envio' => '🗑️ Eliminó una tarifa de envío',
    'registrar_pago_vendedor' => '💸 Registró un pago a un vendedor',
];

function v_aud_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Auditoría — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 900px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; }
  th { background: #f3f4f6; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .paginador_baycodec { display: flex; align-items: center; justify-content: center; gap: 12px; margin: 12px 0 4px; }
  .paginador-info_baycodec { font-size: 0.82rem; color: #6b7280; }
  .paginador-deshabilitado_baycodec { opacity: .4; pointer-events: none; }
</style>
</head>
<body>

<h1>📜 Auditoría del Panel de Admin — Grafiluz</h1>
<p class="subtitulo_baycodec">Registro de solo lectura: qué acción sensible se hizo, cuándo y sobre qué (<?= $totalRegistros_baycodec ?> en total).</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="admin-productos.php" style="background:#C41F25;">🛠️ Panel de Productos</a>
</div>

<table>
  <thead>
    <tr><th>Fecha</th><th>Admin</th><th>Acción</th><th>Referencia</th><th>Detalle</th></tr>
  </thead>
  <tbody>
    <?php if (empty($registrosAuditoria_baycodec)): ?>
      <tr><td colspan="5" class="vacio_baycodec">(todavía no hay acciones registradas)</td></tr>
    <?php else: foreach ($registrosAuditoria_baycodec as $r_baycodec): ?>
      <tr>
        <td><?= v_aud_baycodec(date('d/m/Y H:i', strtotime($r_baycodec['creado_en']))) ?></td>
        <td><?= v_aud_baycodec($r_baycodec['admin_usuario']) ?></td>
        <td><?= v_aud_baycodec($ETIQUETAS_ACCION_BAYCODEC[$r_baycodec['accion']] ?? $r_baycodec['accion']) ?></td>
        <td><?= $r_baycodec['referencia_id'] !== null ? '#' . (int) $r_baycodec['referencia_id'] : '—' ?></td>
        <td><?= v_aud_baycodec($r_baycodec['detalle']) ?: '—' ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

<?php if ($totalPaginasAuditoria_baycodec > 1): ?>
  <div class="paginador_baycodec">
    <?php if ($paginaAuditoria_baycodec > 1): ?>
      <a class="btn_baycodec secundario_baycodec" href="?pagina=<?= $paginaAuditoria_baycodec - 1 ?>">‹ Anterior</a>
    <?php else: ?>
      <span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">‹ Anterior</span>
    <?php endif; ?>
    <span class="paginador-info_baycodec">Página <?= $paginaAuditoria_baycodec ?> de <?= $totalPaginasAuditoria_baycodec ?></span>
    <?php if ($paginaAuditoria_baycodec < $totalPaginasAuditoria_baycodec): ?>
      <a class="btn_baycodec secundario_baycodec" href="?pagina=<?= $paginaAuditoria_baycodec + 1 ?>">Siguiente ›</a>
    <?php else: ?>
      <span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">Siguiente ›</span>
    <?php endif; ?>
  </div>
<?php endif; ?>

</body>
</html>
