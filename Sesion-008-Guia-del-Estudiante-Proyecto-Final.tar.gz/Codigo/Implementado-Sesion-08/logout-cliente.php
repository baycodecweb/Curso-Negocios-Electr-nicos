<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// Cierra la sesión del CLIENTE (comprador). Solo borra las claves de
// sesión del cliente — no toca la sesión del panel de admin
// (auth-admin.php), por si ambas coincidieran en el mismo navegador.

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

unset(
    $_SESSION['cliente_id_baycodec'],
    $_SESSION['cliente_usuario_baycodec'],
    $_SESSION['cliente_nombre_baycodec'],
    $_SESSION['cliente_tipo_baycodec']
);

header('Location: tienda.php');
exit;
