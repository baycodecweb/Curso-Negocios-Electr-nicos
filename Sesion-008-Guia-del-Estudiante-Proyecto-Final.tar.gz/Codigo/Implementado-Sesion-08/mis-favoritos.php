<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// MIS FAVORITOS (wishlist) — mejora post-Sesión 8
// ------------------------------------------------------------
// Lista de productos guardados con el ❤ de cada tarjeta en tienda.php
// (ver alternar-favorito.php). WHERE cliente_id = <su propia cuenta>,
// igual que el resto de páginas "Mis...": nunca ve los favoritos de
// otro cliente.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

$clienteActual_baycodec = clienteActual_baycodec();
if (!$clienteActual_baycodec) {
    header('Location: login-cliente.php');
    exit;
}

if (isset($_GET['quitar'])) {
    $pdo_baycodec->prepare('DELETE FROM favoritos_tb_baycodec WHERE cliente_id = ? AND producto_codigo = ?')
        ->execute([$clienteActual_baycodec['id'], trim($_GET['quitar'])]);
    header('Location: mis-favoritos.php');
    exit;
}

// JOIN con productos para traer nombre/precio/imagen actuales — si el
// producto se desactivó o se borró después de guardarlo como
// favorito, simplemente no aparece aquí (no queda un favorito roto).
$consultaFavoritos_baycodec = $pdo_baycodec->prepare(
    'SELECT f.producto_codigo, p.nombre, p.precio_referencial_pen, p.imagen_url, p.activo, p.stock
     FROM favoritos_tb_baycodec f
     JOIN productos_tb_baycodec p ON p.codigo = f.producto_codigo
     WHERE f.cliente_id = ?
     ORDER BY f.creado_en DESC'
);
$consultaFavoritos_baycodec->execute([$clienteActual_baycodec['id']]);
$misFavoritos_baycodec = $consultaFavoritos_baycodec->fetchAll();

function v_fav_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Favoritos — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .btn_baycodec.peligro_baycodec { background: #fee2e2; color: #991b1b; }
  .favoritos-grid_baycodec { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 14px; }
  .favorito-tarjeta_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px; text-align: center; }
  .favorito-tarjeta_baycodec img { width: 100%; height: 120px; object-fit: cover; border-radius: 6px; margin-bottom: 8px; background: #f3f4f6; }
  .favorito-nombre_baycodec { font-weight: 600; font-size: 0.9rem; margin: 4px 0; }
  .favorito-precio_baycodec { color: #C41F25; font-weight: 700; font-size: 0.9rem; margin: 2px 0 8px; }
  .etiqueta-inactivo_baycodec { display: inline-block; background: #f3f4f6; color: #6b7280; border-radius: 10px; padding: 1px 8px; font-size: 0.72rem; margin-bottom: 6px; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.9rem; }
</style>
</head>
<body>

<h1>❤️ Mis Favoritos — Grafiluz</h1>
<p class="subtitulo_baycodec">Productos que guardaste desde el catálogo para verlos después.</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="tienda.php" style="background:#C41F25;">🌐 Ir al sitio</a>
  <a class="btn_baycodec secundario_baycodec" href="carrito.php" style="margin-left:8px;">🧾 Mi pedido</a>
  <a class="btn_baycodec secundario_baycodec" href="mi-perfil.php" style="margin-left:8px;">👤 Mi perfil</a>
</div>

<?php if (empty($misFavoritos_baycodec)): ?>
  <p class="vacio_baycodec">Todavía no guardaste ningún favorito. Haz clic en el ❤ de cualquier tarjeta del catálogo.</p>
<?php else: ?>
  <div class="favoritos-grid_baycodec">
    <?php foreach ($misFavoritos_baycodec as $f_baycodec): ?>
      <div class="favorito-tarjeta_baycodec">
        <?php if (!$f_baycodec['activo']): ?><span class="etiqueta-inactivo_baycodec">Ya no disponible</span><?php endif; ?>
        <img src="<?= v_fav_baycodec(trim(explode(',', $f_baycodec['imagen_url'] ?? '')[0])) ?>" alt="<?= v_fav_baycodec($f_baycodec['nombre']) ?>" onerror="this.style.visibility='hidden';">
        <p class="favorito-nombre_baycodec"><?= v_fav_baycodec($f_baycodec['nombre']) ?></p>
        <p class="favorito-precio_baycodec">S/ <?= number_format((float) $f_baycodec['precio_referencial_pen'], 2) ?></p>
        <a class="btn_baycodec peligro_baycodec" style="font-size:0.75rem; padding:5px 10px;"
           href="mis-favoritos.php?quitar=<?= urlencode($f_baycodec['producto_codigo']) ?>">🗑️ Quitar</a>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

</body>
</html>
