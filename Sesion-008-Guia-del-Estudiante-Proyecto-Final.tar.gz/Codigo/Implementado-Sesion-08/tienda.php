<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// Cuenta de cliente (comprador) — Sesión 8: ver auth-cliente.php.
// Cargar la sesión del cliente aquí (antes de cualquier salida HTML)
// es lo que permite mostrar "Ingresar/Registrarse" o "Hola, {nombre}"
// en el <nav> y saltarse el formulario manual de "Mi Pedido" cuando
// ya hay una cuenta con sesión iniciada.
require_once __DIR__ . '/auth-cliente.php';
$clienteActual_baycodec = clienteActual_baycodec();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- SESIÓN 5: metadatos SEO reales (antes solo decía "Baycodec") -->
  <title>Grafiluz — Artículos Publicitarios Personalizados en Arequipa</title>
  <meta name="description" content="Grafiluz: muñecos antiestrés, artículos de escritorio, tomatodos, llaveros y bolsas personalizadas con tu logo. Cotización rápida por WhatsApp para empresas en Arequipa.">
  <meta property="og:title" content="Grafiluz — Artículos Publicitarios Personalizados">
  <meta property="og:description" content="Merchandising corporativo personalizado con tu logo, cotización rápida por WhatsApp.">
  <meta property="og:type" content="website">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <!-- Recorrido interactivo por sesiones (material didáctico, no toca la lógica real del sitio): ver recorrido.js -->
  <link rel="stylesheet" href="recorrido.css">
</head>
<body>
  <header>
    <img src="https://raw.githubusercontent.com/baycodecweb/logos-clientes/ddf0bd171aeb9345f8a59c3c1556411bfd3fad07/logo-Blanco-grafiluz.svg" alt="Logo Grafiluz" class="logo_baycodec">
    <p>Calle Pizarro 312 int 38  galerías unión y progreso cercado | 📧  juanaluzarenas8@gmail.com | 📞 910169539 / 930910829</p>
  </header>

  <nav>
    <a href="#inicio_baycodec">INICIO</a>
    <details class="nav-dropdown_baycodec">
      <summary>PRODUCTOS</summary>
      <div class="nav-dropdown-menu_baycodec">
        <a href="#antiestres_baycodec">ARTÍCULOS ANTIESTRÉS</a>
        <a href="#escritorio_baycodec">ARTÍCULOS DE ESCRITORIO</a>
        <a href="#tomatodos_baycodec">TOMATODOS</a>
        <a href="#llaveros_baycodec">LLAVEROS</a>
        <a href="#bolsas_baycodec">BOLSAS</a>
      </div>
    </details>
    <div class="nav-moneda_baycodec" data-sesion="2">
      <label for="nav-select-pais" class="nav-moneda-label_baycodec">💱 PRECIOS INT.</label>
      <select id="nav-select-pais_baycodec" onchange="cambiarMonedaDesdeNav_baycodec(this.value)">
        <option value="PEN" selected>🇵🇪 Perú (S/)</option>
        <option value="USD">🇺🇸 Estados Unidos ($)</option>
        <option value="EUR">🇪🇺 Zona Euro (€)</option>
        <option value="MXN">🇲🇽 México (MX$)</option>
        <option value="CLP">🇨🇱 Chile (CL$)</option>
        <option value="COP">🇨🇴 Colombia (CO$)</option>
      </select>
    </div>
    <a href="carrito.php" data-sesion="3">MI PEDIDO 🧾<span id="nav-carrito-total_baycodec"></span></a>
    <a href="#buscador-catalogo_baycodec" data-sesion="4">BUSCADOR 🔎</a>
    <div class="nav-cuenta_baycodec">
      <?php if ($clienteActual_baycodec): ?>
        👤 Hola, <?= htmlspecialchars($clienteActual_baycodec['nombre'], ENT_QUOTES, 'UTF-8') ?>
        <a href="mis-pedidos.php">Mis compras</a>
        <?php if ($clienteActual_baycodec['tipo_cliente'] === 'C2C'): ?>
          <a href="mis-productos.php">Mis ventas</a>
        <?php endif; ?>
        <a href="mis-favoritos.php">Mis favoritos</a>
        <a href="mis-notificaciones.php">Notificaciones</a>
        <a href="mi-perfil.php">Mi perfil</a>
        <a href="mis-direcciones.php">Mis direcciones</a>
        <a href="logout-cliente.php">Salir</a>
      <?php else: ?>
        <a href="login-cliente.php">INGRESAR</a>
        <a href="registro-cliente.php">REGISTRARSE</a>
      <?php endif; ?>
    </div>
  </nav>

  <!-- BOTÓN FLOTANTE PARA IR AL INICIO -->
  <button class="btn-inicio-flotante_baycodec" id="btnInicio_baycodec" onclick="irAlInicio_baycodec()">
    <!-- La flecha se genera con CSS ::before -->
  </button>

  <section id="inicio_baycodec" data-sesion="1">
    <div class="carousel_baycodec">
      <div class="carousel-inner_baycodec">
        <div class="carousel-item_baycodec">
          <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgU12W-XrArRRckndRgMrrH7zbjr3pG5O_yBj3_UDiS40r2ttug8dldLaTwZ02ocm8-BvRE6iPcUIQETf6f9YRvHyHyuU1TBnErcBmbhAWyp5H40knw6i2c69c1vZnFXykqERDXVfk4dFvZU0NhqSY5tskQTr-n2kfcfa6IWpIR2HUghyphenhyphendxlyKTuHCNClS-/s1920/1.png" alt="Productos Publicitarios">
          <div class="carousel-overlay_baycodec">
            <h2>Bienvenidos a Grafiluz</h2>
            <p>
              Somos una empresa especializada en <strong>artículos publicitarios personalizados</strong>. 
              Ofrecemos una amplia gama de productos promocionales de alta calidad para potenciar la imagen de tu marca.
            </p>
          </div>
        </div>
        <div class="carousel-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg6pL_r86__ll-S7Jxn4r0QieXWsU4TIPh2szlX1-cc4diaJt_xZdNz9jeQY7NASuAJw4bb9gWEupJr-whyDrQmyPMP_ynqaaXVGiWE-0A1o7V11eZ7sAAEyX0po0Y-LkeXkwoO131DGnjyHshJlBHxegMVhSIHGrCFhUa6GkpZ1Kxy_t0YqH-wl3r8a6U8/s1920/2.png" alt="Artículos Personalizados">
          <div class="carousel-overlay_baycodec">
            <h2>Personalización de Calidad</h2>
            <p>
              Transformamos tus ideas en productos únicos que representan la identidad de tu empresa con excelencia y profesionalismo.
            </p>
          </div>
        </div>
        <div class="carousel-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhJ4pSM9Y7k118jr23NzMJ-vn12Z_omFEK9iLgZMh56lsZe3QTRmTAMftmd1ZQv24uhaokigquC-RiM7rVr9sAHINzJOjFOOB4VlQKBZzm0LZA6Sdu2yj0F9lYZjkNs2YIyfGi4vfWoPGQWazc5ZbB_bgcME-pBwAEa_w7zMK5Ld64tDDduu0eBuoU-fkbR/s1920/3.png" alt="Promocionales">
          <div class="carousel-overlay_baycodec">
            <h2>Impulsa tu Marca</h2>
            <p>
              Contamos con la mejor tecnología en impresión y grabado para garantizar productos de alto impacto visual.
            </p>
          </div>
        </div>
      </div>

      <div class="carousel-controls_baycodec">
        <button class="carousel-btn_baycodec" onclick="previousSlide_baycodec()">‹</button>
        <button class="carousel-btn_baycodec" onclick="nextSlide_baycodec()">›</button>
      </div>
      
      <div class="carousel-indicators_baycodec">
        <span class="indicator_baycodec active_baycodec" onclick="goToSlide_baycodec(0)"></span>
        <span class="indicator_baycodec" onclick="goToSlide_baycodec(1)"></span>
        <span class="indicator_baycodec" onclick="goToSlide_baycodec(2)"></span>
      </div>
    </div>
  </section>

  <!-- ============================================================
       SESIÓN 4 — LA ARQUITECTURA DEL GIGANTE (buscador escalable)
       Esto es lo que cada alumno debe lograr: en vez de seguir
       agregando categorías escritas a mano en el HTML (como el
       resto del sitio), este buscador trata el catálogo como DATOS
       para poder filtrarlo — el índice de motor-catalogo.js sigue
       siendo el patrón correcto para un catálogo 100% data-driven.
       Como el catálogo real (Sesión 1) sigue escrito a mano en HTML,
       el buscador resalta/oculta directamente esas mismas tarjetas
       en vez de dibujar una lista de resultados aparte que las
       duplicaría. Va justo debajo del carrusel de bienvenida y antes
       del catálogo: lo primero que se usa en cualquier tienda en
       línea real, sin tapar la bienvenida del sitio.
       Código fuente: motor-catalogo.js
  ============================================================ -->
  <section id="buscador-catalogo_baycodec" class="buscador-section_baycodec buscador-arriba" data-sesion="4">
    <h2>Buscador de Catálogo</h2>
    <p class="buscador-subtitle_baycodec">
      Escribe un producto o elige una categoría: se resalta directamente en el
      catálogo real de más abajo (Sesión 4), sin duplicar tarjetas en una lista aparte.
    </p>

    <div class="buscador-form_baycodec">
      <input type="text" id="bc-texto_baycodec" placeholder="Buscar por nombre..." oninput="bcBuscar_baycodec()">
      <select id="bc-categoria_baycodec" onchange="bcBuscar_baycodec()"></select>
    </div>

    <p id="bc-info-pagina_baycodec" class="bc-estado_baycodec"></p>
  </section>

<?php
// Codigo del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// CATALOGO CONECTADO A LA BASE DE DATOS REAL — Sesion 8
// ------------------------------------------------------------
// Hasta la Sesion 7 estas 266 tarjetas de producto estaban
// escritas a mano en este HTML (ver el historial en
// tienda.html, que se conserva sin tocar como referencia de las
// Sesiones 1-7). Aqui se generan dinamicamente desde la tabla
// "productos" de grafiluz_db (administrada en admin-productos.php),
// para que agregar/editar/eliminar un producto en el panel se
// refleje aqui sin tocar codigo.
//
// Reconstruccion del carrusel de tarjeta (igual que en tienda.html):
// tienda.html agrupaba manualmente varias fotos/variantes bajo UNA
// tarjeta (ej. "Muñeco Antiestrés" + "...Minero" + "...Deportista"
// comparten un mismo carrusel, aunque sean 3 nombres distintos — por
// eso NO se puede reconstruir agrupando por nombre). Esa agrupacion
// real se extrajo una sola vez leyendo tienda.html (95 tarjetas, 266
// codigos, sin mezclar categorias) y quedo guardada en
// grupos-carrusel.php como la lista ordenada de "codigo" que
// comparte cada tarjeta original. Aqui se usa esa referencia para
// reagrupar las filas reales de la base de datos: una imagen y un
// bloque de info por fila, en el mismo orden que tenian a mano. Un
// producto nuevo (agregado en admin-productos.php sin existir en
// tienda.html) simplemente sale en su propia tarjeta. El resto del
// comportamiento (buscador, carrito, WhatsApp) sigue funcionando
// igual porque motor-catalogo.js, script.js y puente-digital.js leen
// estos mismos selectores (.card_baycodec, .card-info-item_baycodec,
// .card-precio_baycodec[data-id]) sin importar cuantas
// imagenes/variantes tenga cada tarjeta.
// ============================================================
require_once __DIR__ . '/db-conexion.php';

$SECCIONES_CATALOGO_BAYCODEC = [
    'antiestres_baycodec' => 'Artículos Antiestrés',
    'escritorio_baycodec' => 'Artículos de Escritorio',
    'tomatodos_baycodec'  => 'Tomatodos y Tazas',
    'llaveros_baycodec'   => 'Llaveros',
    'bolsas_baycodec'     => 'Bolsas Publicitarias',
    'papeleria_baycodec'  => 'ARTICULOS Papeleria',
];

$GRUPOS_CARRUSEL_BAYCODEC = require __DIR__ . '/grupos-carrusel.php';

$COLOR_CLASE_BAYCODEC = [
    'rojo'   => 'color-rojo_baycodec',
    'azul'   => 'color-azul_baycodec',
    'gris'   => 'color-gris_baycodec',
    'blanco' => 'color-blanco_baycodec',
];

// ============================================================
// RESEÑAS / CALIFICACIONES (mejora post-Sesión 8): promedio y total
// de estrellas por producto, para mostrarlas en cada tarjeta. Una
// sola consulta para TODO el catálogo (agrupada por producto_codigo)
// en vez de una consulta por tarjeta — igual de barato sin importar
// cuántos productos tenga la tienda. Las reseñas se dejan/editan
// desde mis-pedidos.php (ver guardar-resena.php).
// ============================================================
$RESENAS_POR_CODIGO_BAYCODEC = [];
foreach ($pdo_baycodec->query('SELECT producto_codigo, AVG(calificacion) AS promedio, COUNT(*) AS total FROM resenas_tb_baycodec GROUP BY producto_codigo')->fetchAll() as $filaResena_baycodec) {
    $RESENAS_POR_CODIGO_BAYCODEC[$filaResena_baycodec['producto_codigo']] = [
        'promedio' => (float) $filaResena_baycodec['promedio'],
        'total'    => (int) $filaResena_baycodec['total'],
    ];
}

function renderEstrellas_baycodec($promedio) {
    $llenas = max(0, min(5, (int) round($promedio)));
    return str_repeat('★', $llenas) . str_repeat('☆', 5 - $llenas);
}

// ============================================================
// FAVORITOS / WISHLIST (mejora post-Sesión 8): qué productos ya
// guardó ESTE cliente, para pintar el corazón ❤ lleno desde el primer
// dibujo de la tarjeta (sin esperar una consulta aparte por cada
// corazón). Vacío si nadie inició sesión — cualquiera puede navegar
// el catálogo, pero solo con cuenta se puede guardar un favorito
// (igual que "Mi Pedido").
// ============================================================
$MIS_FAVORITOS_BAYCODEC = [];
if ($clienteActual_baycodec) {
    $consultaFavoritosTienda_baycodec = $pdo_baycodec->prepare('SELECT producto_codigo FROM favoritos_tb_baycodec WHERE cliente_id = ?');
    $consultaFavoritosTienda_baycodec->execute([$clienteActual_baycodec['id']]);
    $MIS_FAVORITOS_BAYCODEC = $consultaFavoritosTienda_baycodec->fetchAll(PDO::FETCH_COLUMN);
}

// ============================================================
// VARIANTES DE PRODUCTO (mejora post-Sesión 8): agrupadas por
// producto_codigo, para mostrar un <select> de variante justo antes
// del botón "Agregar" SOLO en los productos que de verdad tienen
// (la mayoría del catálogo sigue sin variantes, sin cambiar en nada
// su tarjeta). Solo variantes activas.
// ============================================================
$VARIANTES_POR_CODIGO_BAYCODEC = [];
foreach ($pdo_baycodec->query('SELECT * FROM producto_variantes_tb_baycodec WHERE activo = 1 ORDER BY nombre_variante')->fetchAll() as $filaVariante_baycodec) {
    $VARIANTES_POR_CODIGO_BAYCODEC[$filaVariante_baycodec['producto_codigo']][] = $filaVariante_baycodec;
}

function v_tienda_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

function js_attr_baycodec($valor) {
    $valor = str_replace("'", "\\'", $valor ?? '');
    return htmlspecialchars($valor, ENT_COMPAT, 'UTF-8');
}
?>
  <div class="productos_baycodec">
<?php foreach ($SECCIONES_CATALOGO_BAYCODEC as $seccionId_baycodec => $categoriaNombre_baycodec): ?>
    <section id="<?= $seccionId_baycodec ?>" data-sesion="1">
      <h2><?= v_tienda_baycodec($categoriaNombre_baycodec) ?></h2>
      <div class="grid_baycodec">
<?php
        $stmt_baycodec = $pdo_baycodec->prepare('SELECT * FROM productos_tb_baycodec WHERE categoria = ? AND activo = 1 ORDER BY id');
        $stmt_baycodec->execute([$categoriaNombre_baycodec]);

        // Filas de esta categoria, indexadas por codigo para poder
        // reordenarlas segun la tarjeta original a la que pertenecian.
        $filasPorCodigo_baycodec = [];
        foreach ($stmt_baycodec->fetchAll() as $fila_baycodec) {
            $filasPorCodigo_baycodec[$fila_baycodec['codigo']] = $fila_baycodec;
        }

        // Reconstruye cada tarjeta original: recorre los 95 grupos de
        // referencia y, de cada uno, toma solo los codigos que existen
        // (activos) en ESTA categoria, en su mismo orden. Los codigos
        // que no aparecen en ningun grupo (productos nuevos del panel)
        // quedan sueltos y se agregan al final, cada uno en su propia
        // tarjeta.
        $gruposParaRenderizar_baycodec = [];
        foreach ($GRUPOS_CARRUSEL_BAYCODEC as $codigosGrupo_baycodec) {
            $filasDelGrupo_baycodec = [];
            foreach ($codigosGrupo_baycodec as $codigo_baycodec) {
                if (isset($filasPorCodigo_baycodec[$codigo_baycodec])) {
                    $filasDelGrupo_baycodec[] = $filasPorCodigo_baycodec[$codigo_baycodec];
                    unset($filasPorCodigo_baycodec[$codigo_baycodec]);
                }
            }
            if ($filasDelGrupo_baycodec) {
                $gruposParaRenderizar_baycodec[] = $filasDelGrupo_baycodec;
            }
        }
        foreach ($filasPorCodigo_baycodec as $filaSuelta_baycodec) {
            $gruposParaRenderizar_baycodec[] = [$filaSuelta_baycodec];
        }

        foreach ($gruposParaRenderizar_baycodec as $variantes_baycodec):
            // Cada variante puede ademas traer varias URLs propias
            // separadas por coma (misma convencion que colores) — se
            // aplanan aqui para que el carrusel muestre TODAS las fotos
            // del grupo, sin importar si vienen de una fila o de varias.
            $imagenesPlano_baycodec = [];
            foreach ($variantes_baycodec as $v_baycodec) {
                foreach (array_filter(array_map('trim', explode(',', $v_baycodec['imagen_url'] ?? ''))) as $imagenUrl_baycodec) {
                    $imagenesPlano_baycodec[] = ['url' => $imagenUrl_baycodec, 'nombre' => $v_baycodec['nombre']];
                }
            }
?>
        <div class="card_baycodec">
          <div class="card-carousel_baycodec">
            <?php $esFavorito_baycodec = in_array($variantes_baycodec[0]['codigo'], $MIS_FAVORITOS_BAYCODEC, true); ?>
            <button type="button" class="card-favorito-btn_baycodec<?= $esFavorito_baycodec ? ' card-favorito-activo_baycodec' : '' ?>"
                    data-codigo-favorito="<?= v_tienda_baycodec($variantes_baycodec[0]['codigo']) ?>"
                    onclick="favoritoAlternar_baycodec(this)" title="Guardar en favoritos">
              <?= $esFavorito_baycodec ? '❤️' : '🤍' ?>
            </button>
            <div class="card-carousel-inner_baycodec">
<?php       foreach ($imagenesPlano_baycodec as $img_baycodec): ?>
              <div class="card-carousel-item_baycodec">
                <img loading="lazy" src="<?= v_tienda_baycodec($img_baycodec['url']) ?>" alt="<?= v_tienda_baycodec($img_baycodec['nombre']) ?>">
              </div>
<?php       endforeach; ?>
            </div>
<?php       if (count($imagenesPlano_baycodec) > 1): ?>
            <button class="card-carousel-btn_baycodec prev_baycodec" onclick="changeCardSlide_baycodec(this, -1)">‹</button>
            <button class="card-carousel-btn_baycodec next_baycodec" onclick="changeCardSlide_baycodec(this, 1)">›</button>
            <div class="card-carousel-dots_baycodec">
<?php           foreach ($imagenesPlano_baycodec as $indiceImagen_baycodec => $img_baycodec): ?>
              <span class="card-carousel-dot_baycodec<?= $indiceImagen_baycodec === 0 ? ' active_baycodec' : '' ?>"></span>
<?php           endforeach; ?>
            </div>
<?php       endif; ?>
          </div>
          <div class="info_baycodec">
<?php       foreach ($variantes_baycodec as $indiceVariante_baycodec => $v_baycodec):
                $coloresLista_baycodec = array_filter(array_map('trim', explode(',', $v_baycodec['colores'] ?? '')));
?>
            <div class="card-info-item_baycodec<?= $indiceVariante_baycodec === 0 ? ' active_baycodec' : '' ?>">
              <h3><?= v_tienda_baycodec($v_baycodec['nombre']) ?></h3>
              <p>Medidas: <?= v_tienda_baycodec($v_baycodec['medidas']) ?></p>
              <p>Material: <?= v_tienda_baycodec($v_baycodec['material']) ?></p>
              <p class="card-precio_baycodec" data-pen="<?= v_tienda_baycodec($v_baycodec['precio_referencial_pen']) ?>" data-id="<?= v_tienda_baycodec($v_baycodec['codigo']) ?>" data-categoria="<?= v_tienda_baycodec($v_baycodec['categoria']) ?>">S/ <?= number_format((float) $v_baycodec['precio_referencial_pen'], 2) ?><span class="card-precio-convertido_baycodec"></span></p>
              <?php $resenaInfo_baycodec = $RESENAS_POR_CODIGO_BAYCODEC[$v_baycodec['codigo']] ?? null; ?>
              <p class="card-rating_baycodec">
                <span class="card-rating-estrellas_baycodec"><?= renderEstrellas_baycodec($resenaInfo_baycodec['promedio'] ?? 0) ?></span>
                <span class="card-rating-count_baycodec"><?= $resenaInfo_baycodec ? number_format($resenaInfo_baycodec['promedio'], 1) . ' (' . $resenaInfo_baycodec['total'] . ')' : 'Sin reseñas todavía' ?></span>
              </p>
              <?php $variantesProducto_baycodec = $VARIANTES_POR_CODIGO_BAYCODEC[$v_baycodec['codigo']] ?? []; ?>
              <?php if (empty($variantesProducto_baycodec)): ?>
                <?php $agotado_baycodec = $v_baycodec['stock'] !== null && (int) $v_baycodec['stock'] <= 0; ?>
                <?php if ($v_baycodec['stock'] !== null): ?>
                  <p class="card-stock_baycodec<?= $agotado_baycodec ? ' card-stock-agotado_baycodec' : '' ?>">
                    <?= $agotado_baycodec ? 'Agotado' : 'Quedan ' . (int) $v_baycodec['stock'] ?>
                  </p>
                <?php endif; ?>
              <?php else: ?>
                <?php $agotado_baycodec = count(array_filter($variantesProducto_baycodec, fn($vv) => (int) $vv['stock'] > 0)) === 0; ?>
                <select class="card-variante-select_baycodec">
                  <?php foreach ($variantesProducto_baycodec as $variante_baycodec): ?>
                    <?php $agotadaVariante_baycodec = (int) $variante_baycodec['stock'] <= 0; ?>
                    <option value="<?= (int) $variante_baycodec['id'] ?>"
                            data-precio-extra="<?= (float) $variante_baycodec['precio_extra'] ?>"
                            data-nombre="<?= v_tienda_baycodec($variante_baycodec['nombre_variante']) ?>"
                            <?= $agotadaVariante_baycodec ? 'disabled' : '' ?>>
                      <?= v_tienda_baycodec($variante_baycodec['nombre_variante']) ?><?= (float) $variante_baycodec['precio_extra'] > 0 ? ' (+S/ ' . number_format((float) $variante_baycodec['precio_extra'], 2) . ')' : '' ?>
                      — <?= $agotadaVariante_baycodec ? 'Agotado' : 'Quedan ' . (int) $variante_baycodec['stock'] ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              <?php endif; ?>
              <div class="card-carrito_baycodec">
                <button type="button" class="card-carrito-btn_baycodec"
                        data-codigo-base="<?= v_tienda_baycodec($v_baycodec['codigo']) ?>"
                        data-precio-base="<?= v_tienda_baycodec($v_baycodec['precio_referencial_pen']) ?>"
                        data-nombre-base="<?= v_tienda_baycodec($v_baycodec['nombre']) ?>"
                        onclick="cardAgregarClick_baycodec(this)" <?= $agotado_baycodec ? 'disabled' : '' ?>>
                  <?= $agotado_baycodec ? '🚫 Agotado' : '🛒 Agregar' ?>
                </button>
                <span class="card-carrito-badge_baycodec" data-carrito-badge="<?= v_tienda_baycodec($v_baycodec['codigo']) ?>"></span>
              </div>
              <div class="colors_baycodec">
<?php           foreach ($coloresLista_baycodec as $colorNombre_baycodec): $clase_baycodec = $COLOR_CLASE_BAYCODEC[$colorNombre_baycodec] ?? ''; ?>
                <div class="color-dot_baycodec <?= $clase_baycodec ?>"></div>
<?php           endforeach; ?>
              </div>
              <a href="#" class="btn-whatsapp_baycodec" onclick="enviarWhatsApp_baycodec(event, '<?= js_attr_baycodec($v_baycodec['nombre'] . ' - Medidas: ' . $v_baycodec['medidas']) ?>')">
                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
                Consultar
              </a>
            </div>
<?php       endforeach; ?>
          </div>
        </div>
<?php   endforeach; ?>
      </div>
    </section>
<?php endforeach; ?>
  </div>

  <!-- ============================================================
       SESIÓN 2 — EL PUENTE DIGITAL (E-BUSINESS)
       Esto es lo que cada alumno debe lograr: tomar su propio
       catálogo (resultado de la Sesión 1) y sumarle una conexión a
       una API externa que aporte valor de negocio (Sesión 2), sin
       que eso sea en sí una transacción de compra/venta.
       Código fuente: productos-data.js + puente-digital.js
  ============================================================ -->
  <section id="precios-internacionales_baycodec" class="puente-digital-section_baycodec" data-sesion="2">
    <h2>Precios Referenciales Internacionales</h2>
    <p class="pd-subtitle_baycodec">
      Nuestros precios se manejan en Soles (PEN). Si tu empresa opera en el extranjero,
      consulta aquí una referencia automática en Dólares y Euros, actualizada con el tipo
      de cambio del día, antes de coordinar tu pedido por WhatsApp.
    </p>

    <button class="pd-btn_baycodec" onclick="registrarEvento_baycodec('clic_precios_internacionales', {}); iniciarPuenteDigital_baycodec()">
      Consultar tipo de cambio y ver precios referenciales
    </button>

    <p id="pd-estado_baycodec" class="pd-estado_baycodec"></p>
  </section>

  <!-- ============================================================
       SESIÓN 3 — EL PLANO MAESTRO DE LA MEMORIA (DER)
       "Mi Pedido" (registro de clientes y pedidos, modelo relacional
       Cliente -> Pedido -> DetallePedido -> Pago) ya no es una
       sección de esta página: es su propio archivo, carrito.php,
       para que el checkout funcione como en un e-commerce real (ver
       los productos a comprar y pasar a la pasarela de pago sin
       mezclarse con el catálogo). El carrito en sí sigue armándose
       aquí (botón 🛒 en cada tarjeta) y viaja a carrito.php via
       localStorage. Código fuente original (Sesiones 3-7, simulado,
       sin cuenta real): db-modelo.js. Sesión 8: auth-cliente.php,
       registro-cliente.php, carrito.php, crear-pedido.php y
       pagar-pedido.php.
  ============================================================ -->

  <!-- SECCIÓN DE CLIENTES -->
  <section class="clientes-section_baycodec">
    <h2>Nuestros Clientes</h2>
    <p class="clientes-subtitle_baycodec">Empresas que confían en nuestros productos publicitarios</p>
    
    <div class="logos-carousel-container_baycodec">
      <div class="logos-track_baycodec">
        <!-- Primer set de logos -->
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj273ONybuZs9qM4nDggw3kDld4ffETPU8w3PgbmKOvM8zAUFVOt96RqyBmaAcmyHQrKUu-0KZCWVUgjS5h39ZZRTeG9DYtaR35u5z_mpx24adrZR-XI8MW_uNOIcWb3wDKUkY-YjGIxcWI1eMqBVq-CZpiH233iNPnzqMY1XBAuZOqhI_Ua_2qCWUPrXpR/s1792/2.png" alt="Cliente Google">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh5hRg5OZDCQRdHfUXdrC35ah-nWh-nyyYDHpD9eePwDeZpMPet2be7LoamC0a2DVSEbWiK7EyA2IOfus37DA8q9hbxHajUWydZFuwVfRzpGsp43mzVbU5CdGvZAwU9SSSxU2suPu3FaJAnU312Ep8UoLmZ3tg2hzS7rqv_waJV-DH0q4FZj8Oh1ypwskgp/s1792/1.png" alt="Cliente Microsoft">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjjaOXUxvuSffSNyewqysW273Gq87GtxkW6R1O0Dfy-xvnwJhyphenhyphenzuf6X5h4srJobIYNhTVQPSZkWFeFx7AxRKkI03p3RdMHLuDxfHC3B2_0nnv8UE8ULQ_zczlq477exUzua3qkP5WbnteecJEDe8C7GG_tzy_6lVbm6uXPKWX252UOGlRH8bZdiVg8jgdHP/s1792/18.png" alt="Cliente Amazon">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEj6PEakkUyKiOGoebA3wTaD1C-fQuOWOjosPjLUriQjfpccSS-x7lZ6NPR_l1lxEDgwZJUwOd0WNwM2eWRyAkIDjH1jDQUNqygyT_hhmf_OU91vOVcPuK07oRUTfhDwR8ICsi6aQiNqUWDG0_-CMHsdu7dy0IxEM2nCi50TI8SnRKDNwWZ4XCroV3Ur4I7c/s1792/16.png" alt="Cliente Meta">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiJo0w6XwxiUkybCYy8QUO-edUmKyxQLSaPvwtyejHwFmkwh5Ui3tMVeE3oP2ZzkQwmNRy5UN2EAQRNoYi9fuX-3MFvbd50xAh4EdjJIdTSIaDB4oDZRK3jHri4nVxaU6qpI7h-stqJM3ecFWx9otKLL8KukSkciWfnN3dIKxSncofG_2Fmw2WlJxKXUiSS/s1792/12.png" alt="Cliente Netflix">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiEbIHOpKHQsZWAMLzPP__jfUENEQVgNczCNAbnrNzJLgkEcy5sd2NpooAqbLycTI2fmyvEiiup6n1cofbv2gkamqI2wDXiDzPWIKERzqf5aH2FXEYzoqtky67rCKi0Yx-JJGZjKFTxG1FmE-4QFSUGvHFIU-T1oKFs7fVqQ9cXrYbKbUp9F_elOh0HcOcb/s1792/11.png" alt="Cliente Apple">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhgexlxAj02OzGI2WBSJU8W4KzoSSNlF6ctzsnJDj5AqQCgeDL6GHdKmKbiH2cvUE9Q2Ix3jxUK4U0Dyq4BO9wI7yQMH-_JCElGKphhT4TdzSq-tbkMQhgHVy4FFDTohFlzsMhm8PRwlgMb9x9pF8AkVMdvZjpvWvBWhPflx0p5_DzoELz4ATCxkG27f8yA/s1792/10.png" alt="Cliente Coca Cola">
        </div>
        
        <!-- Segundo set (duplicado para loop infinito) -->
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjJlXRsjAGgv1Zb2kCyuisKSPdPkDetIGnMg2geXHUHCRWudIpOcP7z-U2uAgIZCXrfFXMKNdf_vo3toa0wuU8N32pzN6LsFl37no2WoPZxQaZpHmAXaNtH1oy5xzdTThzQ6QTMASlI2dJWR5OUVZcQS_sS-rtMQA2GCYphDdWQHqQbwgh4XhWx2staKXo_/s1792/9.png" alt="Cliente Google">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEghPHCb5pyl-oRa_-rOVpEFqSyLDWUFBbrJOW6vSEL-8b8f0zHJKeyiUnX-Ur1pL8J6fEargtVDi68COUEsc5ZUNAMmDJgK_doHuO-v0QHiHlMRK_R2ruCnaKuCzLjVvyxp4K_mWW7iOOv2ytfRTZfhtM-MYke9eXfamlzV3h9_GuzHxvYn4rCO6ppvgsHZ/s1792/4.png" alt="Cliente Microsoft">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjrEwniaTAOPInSGekTeqxd1eULlwldltZ7-o3TpaH4USz_uSOodD7UgneHpRk-UrvyZhJBKrbe_tv15jhW4bFmafcKAUC_WUa_PcMgGR_IE3w-10gAPgCq3s8Tdy1bESPveeI8N9Guivl5zmpPnvzZrNegFKxDVZrxpusjWHTYRo4Pwu4rxnsTCw-Y31d5/s1792/3.png" alt="Cliente Amazon">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjrMEYMfMG8SVaGy0cuh8k0mfF-g09Xa6FSoNf6punxpMmXFdoDhp9uWzrviD0_meZXpl77tuGsLX2jFQsdh5Sr6DUyIzHcbUDIueq27tGQeGtTmUBI_kYKmVc6CeBQcFhvtPCtBY1cSLDaWGEctfJBZngB2_WIrBGhRYGQq5LpCLi7sU_hvQJGUJGS5vcq/s1792/17.png" alt="Cliente Meta">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgFMBNNVE3GvrE0wt3hlVw1h3WDElRSUPExCQZdMtFwFBd-RMTqZJAe4fS9UZTmcK2N1EMqu3sUkPBnNjzk6bmsmi2rm9v7rSlwoZIQozFDHKoFgS4uGyxAgxSWZjXadcWobYEFGeYzde2drIXnouKvYzemzls-xy0xGr7XTuF20IP5lpBh0r3pDydqisJE/s1792/19.png" alt="Cliente Netflix">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEicFUGtb-HURlM3NJ8n23KKQDEjL-DiI1QOYnQVP8GxetEUowc0WdxmtLNrjV60T-vWy3ZiGrXLIwZVmeYb7Qx8Ce82-FW0K2IfE6yRg7EJa0px17EpLBtAVhGxm_RcKuLoFUwMxxo_6ewWib8OYrBxC7Oarqf89sqtfvMmYFDyLdV8AMKoF45Ti5vzQGYJ/s1792/14.png" alt="Cliente Apple">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiSbh5S8KwiZu_44g_8wpKGB7vD-2ZIBKvCz8Cmed_9N653lK_A0LDwiFEv995hW2_51Gsw-oPHByi3fv7lkRmKEmQtLfvXWLM2JucVTbSlM5ZqlKFoi8j-Rtzv5IZ2cBnUjZ4jvEbe5wnieucM66E57CXw7OlWFik69q7ABAaYHLlJ4jvzN3x1ZYncU0A7/s1792/7.png" alt="Cliente Coca Cola">
        </div>

        <!-- Tercer set (para asegurar transición perfecta) -->
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjleBRMQ2wScZ57LWaeBRX6Hv5CJVoOiVDOW79ztm54hyphenhyphen37MwL9opm0uKsDzW4rAKpN0f7b1-sWqCdgL-4EZ-JS2NpKTcWDQDLwWipS1jxQxoQCSmwDCbZ8UamK8Dma3aiGH-DMsokF8YSRm69KcWDSwAo3RQPESMzgLVmXgBwILUgVAVcyFg0XrHrXM6sa/s1792/6.png" alt="Cliente Google">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjfOEeOwjvHL3JPrUjRdVMyKnPySftZSecwGS-ylr-GOtpTF8T9bp-nMosFC80UESjI14Wiu5BUTEahM-3DzC02N7NKNUhd6IfDVoTuSDYOo1Y1n6U9AiTIYUn5LNrS1SK5ExmwccYpNBMKsjx-wiVT8VeY0BhkR3Visqi1PFWMG_9i2_BQw0vUAYsDVkcD/s1792/5.png" alt="Cliente Microsoft">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjrEwniaTAOPInSGekTeqxd1eULlwldltZ7-o3TpaH4USz_uSOodD7UgneHpRk-UrvyZhJBKrbe_tv15jhW4bFmafcKAUC_WUa_PcMgGR_IE3w-10gAPgCq3s8Tdy1bESPveeI8N9Guivl5zmpPnvzZrNegFKxDVZrxpusjWHTYRo4Pwu4rxnsTCw-Y31d5/s1792/3.png" alt="Cliente Amazon">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjrMEYMfMG8SVaGy0cuh8k0mfF-g09Xa6FSoNf6punxpMmXFdoDhp9uWzrviD0_meZXpl77tuGsLX2jFQsdh5Sr6DUyIzHcbUDIueq27tGQeGtTmUBI_kYKmVc6CeBQcFhvtPCtBY1cSLDaWGEctfJBZngB2_WIrBGhRYGQq5LpCLi7sU_hvQJGUJGS5vcq/s1792/17.png" alt="Cliente Meta">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgFMBNNVE3GvrE0wt3hlVw1h3WDElRSUPExCQZdMtFwFBd-RMTqZJAe4fS9UZTmcK2N1EMqu3sUkPBnNjzk6bmsmi2rm9v7rSlwoZIQozFDHKoFgS4uGyxAgxSWZjXadcWobYEFGeYzde2drIXnouKvYzemzls-xy0xGr7XTuF20IP5lpBh0r3pDydqisJE/s1792/19.png" alt="Cliente Netflix">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEicFUGtb-HURlM3NJ8n23KKQDEjL-DiI1QOYnQVP8GxetEUowc0WdxmtLNrjV60T-vWy3ZiGrXLIwZVmeYb7Qx8Ce82-FW0K2IfE6yRg7EJa0px17EpLBtAVhGxm_RcKuLoFUwMxxo_6ewWib8OYrBxC7Oarqf89sqtfvMmYFDyLdV8AMKoF45Ti5vzQGYJ/s1792/14.png" alt="Cliente Apple">
        </div>
        <div class="logo-item_baycodec">
          <img loading="lazy" src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiSbh5S8KwiZu_44g_8wpKGB7vD-2ZIBKvCz8Cmed_9N653lK_A0LDwiFEv995hW2_51Gsw-oPHByi3fv7lkRmKEmQtLfvXWLM2JucVTbSlM5ZqlKFoi8j-Rtzv5IZ2cBnUjZ4jvEbe5wnieucM66E57CXw7OlWFik69q7ABAaYHLlJ4jvzN3x1ZYncU0A7/s1792/7.png" alt="Cliente Coca Cola">
        </div>
      </div>
    </div>
  </section>

  <footer>
    <p>© 2025 Grafiluz - Catálogo de Productos Publicitarios</p>
    <p>Creado por Baycodec - 941233826</p>
    <!-- SESIÓN 8: enlaces legales requeridos para publicar el sitio -->
    <p class="footer-legal_baycodec" data-sesion="8">
      <a href="politica-privacidad.html">Política de Privacidad</a> ·
      <a href="terminos-servicio.html">Términos de Servicio</a>
    </p>
  </footer>

 <script>
   // Configuración del sitio (mejora post-Sesión 8): script.js lee este
   // valor en vez de tener el número de WhatsApp escrito a mano — sale
   // de la tabla configuracion (ver admin-configuracion.php).
   window.WHATSAPP_NUMERO_BAYCODEC = '<?= addslashes(obtenerConfiguracion_baycodec($pdo_baycodec, 'whatsapp_numero', '51930910829')) ?>';
 </script>
 <script src="script.js"></script>
  <!-- Código de la Sesión 2: modelado de datos + conexión a API externa -->
  <script src="productos-data.js"></script>
  <script src="puente-digital.js"></script>
  <script>
    // ============================================================
    // SESIÓN 8 — el carrito vive en localStorage (clave
    // "grafiluz-carrito-baycodec") para sobrevivir la navegación
    // hasta carrito.php, que es donde ahora se revisa, genera y paga
    // el pedido (antes era una sección más de esta misma página).
    // Aquí solo se arma el carrito: cada tarjeta tiene su propio
    // botón "🛒 Agregar" (ver data-id sobre cada
    // <p class="card-precio_baycodec">).
    // ============================================================
    const CARRITO_CLAVE_baycodec = 'grafiluz-carrito-baycodec';
    const CLIENTE_CONECTADO_TIENDA_baycodec = <?= $clienteActual_baycodec ? 'true' : 'false' ?>;

    function carritoLeer_baycodec() {
      try { return JSON.parse(localStorage.getItem(CARRITO_CLAVE_baycodec)) || {}; }
      catch (e) { return {}; }
    }
    function carritoGuardar_baycodec() {
      localStorage.setItem(CARRITO_CLAVE_baycodec, JSON.stringify(carrito));

      // Carrito persistente en servidor (mejora post-Sesión 8): copia
      // de respaldo en las tablas carritos/carrito_items (ver
      // guardar-carrito.php), solo si hay sesión de cliente iniciada.
      // "En segundo plano" (sin await): nunca debe bloquear ni romper
      // agregar un producto al carrito si falla o tarda.
      if (CLIENTE_CONECTADO_TIENDA_baycodec) {
        fetch('guardar-carrito.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ items: carrito }),
        }).catch(() => {});
      }
    }

    const carrito = carritoLeer_baycodec(); // { [productoId o "productoId::varianteId"]: { nombre, precio, cantidad } }

    // El badge de cada tarjeta se identifica por el código BASE del
    // producto (nunca cambia, tenga o no variantes) — si hay varias
    // variantes del mismo producto en el carrito, el badge suma todas
    // (mejora post-Sesión 8: variantes de producto).
    function carritoActualizarBadge_baycodec(idOBase) {
      const base = idOBase.split('::')[0];
      const cantidad = Object.keys(carrito)
        .filter((clave) => clave === base || clave.startsWith(base + '::'))
        .reduce((acc, clave) => acc + carrito[clave].cantidad, 0);
      document.querySelectorAll(`[data-carrito-badge="${base}"]`).forEach((badge) => {
        badge.textContent = cantidad > 0 ? `×${cantidad}` : '';
      });
    }

    function carritoActualizarContadorNav_baycodec() {
      const total = Object.values(carrito).reduce((acc, item) => acc + item.cantidad, 0);
      const contador = document.getElementById('nav-carrito-total_baycodec');
      if (contador) contador.textContent = total > 0 ? ` (${total})` : '';
    }

    /**
     * Agrega al carrito. "id" puede ser el código de un producto sin
     * variantes, o "codigo::varianteId" (mejora post-Sesión 8) — cada
     * combinación es su propia línea del carrito, con su propio nombre
     * y precio ya calculados (nombre/precio se arman en
     * cardAgregarClick_baycodec a partir de los data-* del botón, no
     * se vuelven a leer del DOM aquí).
     */
    function carritoAgregar_baycodec(id, nombre, precio, idBaseParaBadge) {
      if (!carrito[id]) {
        carrito[id] = { nombre, precio, cantidad: 0 };
      }
      carrito[id].cantidad++;
      carritoGuardar_baycodec();
      carritoActualizarBadge_baycodec(idBaseParaBadge || id);
      carritoActualizarContadorNav_baycodec();
    }

    /**
     * Lee el botón "🛒 Agregar" de una tarjeta y, si esa tarjeta tiene
     * un selector de variante (mejora post-Sesión 8), arma el id
     * compuesto "codigo::varianteId" con el precio_extra ya sumado;
     * si no tiene variantes, agrega el producto tal cual.
     */
    function cardAgregarClick_baycodec(boton) {
      const codigoBase = boton.dataset.codigoBase;
      const precioBase = parseFloat(boton.dataset.precioBase);
      const nombreBase = boton.dataset.nombreBase;

      const contenedor = boton.closest('.card-info-item_baycodec');
      const selectVariante = contenedor ? contenedor.querySelector('.card-variante-select_baycodec') : null;

      if (selectVariante && selectVariante.value) {
        const opcion = selectVariante.selectedOptions[0];
        const precioExtra = parseFloat(opcion.dataset.precioExtra) || 0;
        const idCompuesto = `${codigoBase}::${selectVariante.value}`;
        carritoAgregar_baycodec(idCompuesto, `${nombreBase} (${opcion.dataset.nombre})`, precioBase + precioExtra, codigoBase);
      } else {
        carritoAgregar_baycodec(codigoBase, nombreBase, precioBase, codigoBase);
      }
    }

    // Si el visitante recarga tienda.php con productos ya agregados
    // (o vuelve del carrito sin terminar su pedido), los badges y el
    // contador del nav reflejan lo que ya había.
    Object.keys(carrito).forEach(carritoActualizarBadge_baycodec);
    carritoActualizarContadorNav_baycodec();

    // ============================================================
    // FAVORITOS / WISHLIST (mejora post-Sesión 8): el corazón de cada
    // tarjeta guarda/quita en el servidor (tabla favoritos, ver
    // alternar-favorito.php) — a diferencia del carrito, no vive en
    // localStorage, porque un favorito debe verse igual entres a la
    // tienda desde el navegador que sea. Reutiliza
    // CLIENTE_CONECTADO_TIENDA_baycodec ya declarado junto al carrito.
    // ============================================================
    async function favoritoAlternar_baycodec(boton) {
      if (!CLIENTE_CONECTADO_TIENDA_baycodec) {
        alert('Inicia sesión o crea una cuenta para guardar favoritos.');
        window.location.href = 'login-cliente.php';
        return;
      }

      const codigo = boton.dataset.codigoFavorito;
      boton.disabled = true;

      try {
        const respuesta = await fetch('alternar-favorito.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ producto_codigo: codigo }),
        });
        const resultado = await respuesta.json();

        if (resultado.ok) {
          boton.textContent = resultado.favorito ? '❤️' : '🤍';
          boton.classList.toggle('card-favorito-activo_baycodec', resultado.favorito);
        }
      } finally {
        boton.disabled = false;
      }
    }
  </script>

  <!-- Código de la Sesión 4: catálogo indexado y paginado -->
  <script src="motor-catalogo.js"></script>
  <script>
    // ============================================================
    // SESIÓN 4 — integración del Buscador de Catálogo con
    // motor-catalogo.js (índice + paginación, patrón "marketplace")
    // ============================================================
    function bcConstruirCatalogoReal_baycodec() {
      // La categoría viene de data-categoria (columna real "categoria" de
      // la tabla productos, ver tienda.php) — antes se adivinaba a partir
      // del prefijo del código (p.ej. "antiestres-001"), lo que rompía el
      // filtro para cualquier producto nuevo cuyo código no siguiera esa
      // convención (ver códigos C2C como "prueba-vitrina-002").
      return Array.from(document.querySelectorAll('.card-precio_baycodec[data-id]')).map((el) => {
        const id = el.dataset.id;
        const tarjeta = el.closest('.card-info-item_baycodec');
        const nombre = tarjeta ? tarjeta.querySelector('h3').textContent.trim() : id;
        return {
          id,
          nombre,
          categoria: el.dataset.categoria || id,
          precioReferencialPEN: parseFloat(el.dataset.pen),
        };
      });
    }

    const bcCatalogoReal = bcConstruirCatalogoReal_baycodec();

    function bcPoblarCategorias_baycodec() {
      const categorias = [...new Set(bcCatalogoReal.map(p => p.categoria))];
      document.getElementById('bc-categoria_baycodec').innerHTML =
        '<option value="">Todas las categorías</option>' +
        categorias.map(c => `<option value="${c}">${c}</option>`).join('');
    }

    let bcTemporizadorTrack;
    function bcBuscar_baycodec() {
      bcAplicarFiltro_baycodec();
      // Sesión 5: registra la búsqueda con un pequeño retraso, para no
      // generar un evento por cada tecla presionada.
      clearTimeout(bcTemporizadorTrack);
      bcTemporizadorTrack = setTimeout(() => {
        const texto = document.getElementById('bc-texto_baycodec').value;
        const categoria = document.getElementById('bc-categoria_baycodec').value;
        if (texto || categoria) registrarEvento_baycodec('busqueda_catalogo', { texto, categoria });
      }, 600);
    }

    /**
     * En vez de dibujar una lista de resultados aparte (que
     * duplicaría lo que ya se ve en el catálogo real de más abajo),
     * el buscador resalta directamente las tarjetas que coinciden y
     * oculta el resto. El índice + paginación de motor-catalogo.js
     * (construirIndice_baycodec/buscarProductos_baycodec) sigue siendo el patrón
     * correcto para un catálogo 100% data-driven; mientras el
     * catálogo real siga escrito a mano en HTML (Sesión 1), filtrar
     * sobre esas mismas tarjetas es la forma honesta de buscar sin
     * duplicar información.
     */
    function bcAplicarFiltro_baycodec() {
      const texto = document.getElementById('bc-texto_baycodec').value.trim().toLowerCase();
      const categoriaFiltro = document.getElementById('bc-categoria_baycodec').value;
      const sinFiltro = !texto && !categoriaFiltro;

      // Palabra clave de verificación de autoría (no es un producto real):
      // si el código de este proyecto sigue siendo el original de baycodec
      // (variable __marca_agua_baycodec presente en los .js cargados),
      // buscar "baycodec" lo revela en pantalla en vez de buscar productos.
      if (texto === 'baycodec' && typeof __marca_agua_baycodec !== 'undefined') {
        document.querySelectorAll('.seccion-oculta_baycodec').forEach((s) => s.classList.remove('seccion-oculta_baycodec'));
        document.querySelectorAll('.card-oculta_baycodec').forEach((c) => c.classList.remove('card-oculta_baycodec'));
        document.getElementById('bc-info-pagina_baycodec').textContent =
          '🔎 Marca de autoría detectada: este código corresponde a la copia base del proyecto (baycodec). Recuerda adaptarlo a tu propio negocio antes de entregar.';
        return;
      }

      let totalCoincidencias = 0;
      let primeraCoincidencia = null;

      document.querySelectorAll('.productos_baycodec > section[id]').forEach((seccion) => {
        let seccionTieneCoincidencia = false;

        seccion.querySelectorAll('.grid_baycodec > .card_baycodec').forEach((card) => {
          let cardCoincide = false;
          let primerItemCoincidente = null;

          card.querySelectorAll('.card-info-item_baycodec').forEach((item) => {
            const precioEl = item.querySelector('.card-precio_baycodec[data-id]');
            const h3 = item.querySelector('h3');
            if (!precioEl || !h3) return;

            const categoriaLegible = precioEl.dataset.categoria || precioEl.dataset.id;
            const nombre = h3.textContent.toLowerCase();

            const coincideTexto = !texto || nombre.includes(texto);
            const coincideCategoria = !categoriaFiltro || categoriaLegible === categoriaFiltro;

            if (coincideTexto && coincideCategoria) {
              cardCoincide = true;
              if (!primerItemCoincidente) primerItemCoincidente = item;
            }
          });

          card.classList.toggle('card-oculta_baycodec', !sinFiltro && !cardCoincide);

          // Si la variante que hoy se muestra en el carrusel de esta
          // tarjeta NO es la que coincidió, cambiamos a la que sí
          // coincide — para no mostrar un producto de otra categoría
          // solo porque comparte tarjeta/carrusel con el que sí buscó.
          if (!sinFiltro && cardCoincide && primerItemCoincidente
              && !primerItemCoincidente.classList.contains('active_baycodec')) {
            card.querySelectorAll('.card-info-item_baycodec').forEach((item) => item.classList.remove('active_baycodec'));
            primerItemCoincidente.classList.add('active_baycodec');
          }

          if (cardCoincide) {
            seccionTieneCoincidencia = true;
            totalCoincidencias++;
            if (!primeraCoincidencia) primeraCoincidencia = card;
          }
        });

        seccion.classList.toggle('seccion-oculta_baycodec', !sinFiltro && !seccionTieneCoincidencia);
      });

      const estado = document.getElementById('bc-info-pagina_baycodec');
      if (sinFiltro) {
        estado.textContent = '';
      } else if (totalCoincidencias === 0) {
        estado.textContent = 'Sin resultados para tu búsqueda.';
      } else {
        estado.textContent = `${totalCoincidencias} producto(s) encontrados — resaltados en el catálogo de abajo.`;
        if (primeraCoincidencia) {
          primeraCoincidencia.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    }

    bcPoblarCategorias_baycodec();
    bcAplicarFiltro_baycodec();
  </script>

  <!-- ============================================================
       SESIÓN 5 — LA TIENDA QUE OBSERVA (analítica en vivo)
       Esto es lo que cada alumno debe lograr: instrumentar, de forma
       INVISIBLE para el visitante, los puntos de contacto clave que
       ya existían (WhatsApp, precios internacionales, pedido,
       búsqueda), igual que lo haría un píxel real de Google Analytics
       o de Meta. No agrega ninguna sección nueva a la vista del
       cliente — los resultados se leen aparte, en panel-control.html.
       Código fuente: motor-analitica.js
  ============================================================ -->
  <script src="motor-analitica.js"></script>
  <script>
    trackVisita_baycodec();
  </script>

  <!-- ============================================================
       SESIÓN 6 — EL ASISTENTE VIRTUAL EN ACCIÓN (chatbot)
       Esto es lo que cada alumno debe lograr: incrustar, sobre el
       sitio ya existente, un widget de chat flotante que responda
       preguntas frecuentes y oriente sobre el catálogo, sin romper
       ni tapar el botón flotante de "volver arriba" (Sesión 1).
       Busca productos en bcCatalogoReal (el catálogo real de 266
       productos que ya construye el Buscador, Sesión 4, leyendo el
       DOM) en vez del catálogo de 5 productos de ejemplo — para no
       responder con un producto o un precio que no existen.
       Código fuente: motor-chatbot.js
  ============================================================ -->
  <div id="chatbot-burbuja_baycodec" class="chatbot-burbuja_baycodec" onclick="chatbotAlternar_baycodec()" data-sesion="6">💬</div>
  <div id="chatbot-panel_baycodec" class="chatbot-panel_baycodec" data-sesion="6">
    <div class="chatbot-header_baycodec">
      Asistente Grafiluz
      <button class="chatbot-cerrar_baycodec" onclick="chatbotAlternar_baycodec()">✕</button>
    </div>
    <div id="chatbot-mensajes_baycodec" class="chatbot-mensajes_baycodec">
      <div class="chatbot-msg_baycodec chatbot-msg-bot_baycodec">¡Hola! Soy el asistente de Grafiluz. Pregúntame por horarios, personalización, precios o algún producto del catálogo.</div>
    </div>
    <div class="chatbot-entrada_baycodec">
      <input type="text" id="chatbot-input_baycodec" placeholder="Escribe tu pregunta..." onkeydown="if(event.key==='Enter') chatbotEnviar_baycodec()">
      <button onclick="chatbotEnviar_baycodec()">➤</button>
    </div>
  </div>

  <script src="motor-chatbot.js"></script>
  <script>
    function chatbotAlternar_baycodec() {
      document.getElementById('chatbot-panel_baycodec').classList.toggle('chatbot-panel-abierto_baycodec');
    }

    function chatbotAgregarMensaje_baycodec(texto, clase) {
      const cont = document.getElementById('chatbot-mensajes_baycodec');
      const div = document.createElement('div');
      div.className = `chatbot-msg_baycodec ${clase}`;
      div.textContent = texto;
      cont.appendChild(div);
      cont.scrollTop = cont.scrollHeight;
    }

    function chatbotEnviar_baycodec() {
      const input = document.getElementById('chatbot-input_baycodec');
      const texto = input.value.trim();
      if (!texto) return;
      chatbotAgregarMensaje_baycodec(texto, 'chatbot-msg-usuario_baycodec');
      const resultado = responderPregunta_baycodec(texto, bcCatalogoReal);
      chatbotAgregarMensaje_baycodec(resultado.respuesta, 'chatbot-msg-bot_baycodec');
      input.value = '';
    }
  </script>

  <!-- ============================================================
       SESIÓN 7 — LA TRANSACCIÓN PERFECTA (pasarela sandbox + webhook)
       Código fuente original (simulado, sin servidor): pasarela-pago.js.
       Sesión 8: el pago ya no ocurre en esta página — ver carrito.php
       (mpPagar_baycodec llama a pagar-pedido.php, que corre el mismo
       algoritmo de Luhn y las mismas tarjetas de prueba pero en el
       servidor, actualizando el pedido real de MySQL).
  ============================================================ -->

  <!-- ============================================================
       RECORRIDO INTERACTIVO POR SESIONES (material didáctico)
       Panel flotante puramente aditivo: no toca script.js ni ningún
       motor real del sitio, solo resalta en vivo qué se agregó en
       cada sesión. Ver recorrido.js / recorrido.css. Basado en
       ../Recorrido-Sesiones/, adaptado para vivir dentro del sitio
       real en vez de solo en la copia didáctica separada.
  ============================================================ -->
  <script src="recorrido.js"></script>
</body>
</html>