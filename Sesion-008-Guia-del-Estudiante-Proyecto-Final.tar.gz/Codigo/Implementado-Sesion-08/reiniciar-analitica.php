<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// REINICIAR ANALÍTICA (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// El botón "🗑️ Reiniciar datos" de panel-control.html borraba solo el
// localStorage del propio navegador (Sesión 5). Ahora que también hay
// datos reales en eventos_analitica, este endpoint los vacía a
// petición del admin — protegido igual que el resto del panel, y
// queda registrado en auditoria_admin por si alguien pregunta después
// por qué las estadísticas se resetearon.
// ============================================================

require_once __DIR__ . '/auth-admin.php';

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['admin_usuario_baycodec'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión en el panel de administración.']);
    exit;
}

$pdo_baycodec->exec('DELETE FROM eventos_analitica_tb_baycodec');
registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'reiniciar_analitica', null);

echo json_encode(['ok' => true]);
