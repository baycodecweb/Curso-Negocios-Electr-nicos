<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// PANEL DE CUPONES DE DESCUENTO — mejora post-Sesión 8
// ------------------------------------------------------------
// Herramienta interna, protegida igual que admin-productos.php (ver
// auth-admin.php). El descuento real siempre se recalcula en
// crear-pedido.php a partir del código — este panel solo administra
// qué cupones existen y sus reglas (vigencia, límite de usos).
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

$errorFormulario_baycodec = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar') {
    $codigo_baycodec = strtoupper(trim($_POST['codigo'] ?? ''));
    $tipo_baycodec = ($_POST['tipo'] ?? '') === 'fijo' ? 'fijo' : 'porcentaje';
    $valor_baycodec = str_replace(',', '.', trim($_POST['valor'] ?? ''));
    $fechaInicio_baycodec = trim($_POST['fecha_inicio'] ?? '') ?: null;
    $fechaFin_baycodec = trim($_POST['fecha_fin'] ?? '') ?: null;
    $usosMaximos_baycodec = trim($_POST['usos_maximos'] ?? '');
    $usosMaximos_baycodec = $usosMaximos_baycodec === '' ? null : (int) $usosMaximos_baycodec;
    $activo_baycodec = isset($_POST['activo']) ? 1 : 0;

    if ($codigo_baycodec === '') {
        $errorFormulario_baycodec = 'El código del cupón es obligatorio.';
    } elseif (!is_numeric($valor_baycodec) || (float) $valor_baycodec <= 0) {
        $errorFormulario_baycodec = 'El valor del descuento debe ser un número mayor a 0.';
    } elseif ($tipo_baycodec === 'porcentaje' && (float) $valor_baycodec > 100) {
        $errorFormulario_baycodec = 'Un descuento por porcentaje no puede ser mayor a 100.';
    } else {
        try {
            $pdo_baycodec->prepare(
                'INSERT INTO cupones_tb_baycodec (codigo, tipo, valor, fecha_inicio, fecha_fin, usos_maximos, activo)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            )->execute([$codigo_baycodec, $tipo_baycodec, $valor_baycodec, $fechaInicio_baycodec, $fechaFin_baycodec, $usosMaximos_baycodec, $activo_baycodec]);
            registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'crear_cupon', null, "Cupón {$codigo_baycodec}");
            header('Location: admin-cupones.php?guardado=1');
            exit;
        } catch (PDOException $error) {
            $errorFormulario_baycodec = str_contains($error->getMessage(), 'Duplicate')
                ? 'Ya existe un cupón con ese código.'
                : 'No se pudo guardar el cupón.';
        }
    }
}

if (isset($_GET['alternar_activo'])) {
    $idCupon_baycodec = (int) $_GET['alternar_activo'];
    $pdo_baycodec->prepare('UPDATE cupones_tb_baycodec SET activo = 1 - activo WHERE id = ?')->execute([$idCupon_baycodec]);
    registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'alternar_cupon', $idCupon_baycodec);
    header('Location: admin-cupones.php');
    exit;
}

if (isset($_GET['eliminar'])) {
    $idCupon_baycodec = (int) $_GET['eliminar'];
    $pdo_baycodec->prepare('DELETE FROM cupones_tb_baycodec WHERE id = ?')->execute([$idCupon_baycodec]);
    registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'eliminar_cupon', $idCupon_baycodec);
    header('Location: admin-cupones.php?eliminado=1');
    exit;
}

$cupones_baycodec = $pdo_baycodec->query('SELECT * FROM cupones_tb_baycodec ORDER BY creado_en DESC')->fetchAll();

function v_cup_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cupones — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 900px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .btn_baycodec.peligro_baycodec { background: #fee2e2; color: #991b1b; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"], input[type="number"], input[type="date"], select { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .campos-en-fila_baycodec { display: grid; grid-template-columns: repeat(3, 1fr); gap: 0 16px; }
  .checkbox-linea_baycodec { display: flex; align-items: center; gap: 8px; margin-top: 14px; }
  .checkbox-linea_baycodec input { width: auto; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; }
  th { background: #f3f4f6; }
  .fila-acciones_baycodec { display: flex; gap: 6px; }
  .fila-acciones_baycodec .btn_baycodec { font-size: 0.75rem; padding: 4px 8px; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .etiqueta-inactivo_baycodec { display: inline-block; background: #f3f4f6; color: #6b7280; border-radius: 10px; padding: 1px 8px; font-size: 0.72rem; }
</style>
</head>
<body>

<h1>🏷️ Cupones de Descuento — Grafiluz</h1>
<p class="subtitulo_baycodec">El descuento se recalcula siempre en el servidor al pagar; este panel solo define qué cupones existen.</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="admin-productos.php" style="background:#C41F25;">🛠️ Panel de Productos</a>
</div>

<?php if (isset($_GET['guardado'])): ?><p class="exito_baycodec">✅ Cupón guardado.</p><?php endif; ?>
<?php if (isset($_GET['eliminado'])): ?><p class="exito_baycodec">🗑️ Cupón eliminado.</p><?php endif; ?>
<?php if ($errorFormulario_baycodec): ?><p class="error_baycodec">⚠️ <?= v_cup_baycodec($errorFormulario_baycodec) ?></p><?php endif; ?>

<h2 style="font-size:1.1rem;">➕ Crear cupón</h2>
<div class="caja_baycodec">
  <form method="post" action="admin-cupones.php">
    <input type="hidden" name="accion" value="guardar">

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="codigo">Código</label>
        <input type="text" id="codigo" name="codigo" placeholder="Ej: BIENVENIDA10" required>
      </div>
      <div>
        <label for="tipo">Tipo</label>
        <select id="tipo" name="tipo">
          <option value="porcentaje">Porcentaje (%)</option>
          <option value="fijo">Monto fijo (S/)</option>
        </select>
      </div>
      <div>
        <label for="valor">Valor</label>
        <input type="number" id="valor" name="valor" step="0.01" min="0" placeholder="Ej: 10" required>
      </div>
    </div>

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="fecha_inicio">Vigente desde (opcional)</label>
        <input type="date" id="fecha_inicio" name="fecha_inicio">
      </div>
      <div>
        <label for="fecha_fin">Vigente hasta (opcional)</label>
        <input type="date" id="fecha_fin" name="fecha_fin">
      </div>
      <div>
        <label for="usos_maximos">Usos máximos (vacío = ilimitado)</label>
        <input type="number" id="usos_maximos" name="usos_maximos" min="1">
      </div>
    </div>

    <div class="checkbox-linea_baycodec">
      <input type="checkbox" id="activo" name="activo" checked>
      <label for="activo" style="margin:0;">Cupón activo</label>
    </div>

    <div style="margin-top:14px;">
      <button class="btn_baycodec" type="submit">💾 Crear cupón</button>
    </div>
  </form>
</div>

<h2 style="font-size:1.1rem;">Cupones (<?= count($cupones_baycodec) ?>)</h2>
<table>
  <thead>
    <tr>
      <th>Código</th><th>Descuento</th><th>Vigencia</th><th>Usos</th><th>Estado</th><th style="width:140px">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php if (empty($cupones_baycodec)): ?>
      <tr><td colspan="6" class="vacio_baycodec">(todavía no hay cupones)</td></tr>
    <?php else: foreach ($cupones_baycodec as $c_baycodec): ?>
      <tr>
        <td><code><?= v_cup_baycodec($c_baycodec['codigo']) ?></code></td>
        <td><?= $c_baycodec['tipo'] === 'porcentaje' ? v_cup_baycodec($c_baycodec['valor']) . '%' : 'S/ ' . number_format((float) $c_baycodec['valor'], 2) ?></td>
        <td>
          <?= $c_baycodec['fecha_inicio'] ? v_cup_baycodec($c_baycodec['fecha_inicio']) : '—' ?>
          a
          <?= $c_baycodec['fecha_fin'] ? v_cup_baycodec($c_baycodec['fecha_fin']) : '—' ?>
        </td>
        <td><?= (int) $c_baycodec['usos_actuales'] ?> / <?= $c_baycodec['usos_maximos'] !== null ? (int) $c_baycodec['usos_maximos'] : '∞' ?></td>
        <td><?= $c_baycodec['activo'] ? 'Activo' : '<span class="etiqueta-inactivo_baycodec">Inactivo</span>' ?></td>
        <td class="fila-acciones_baycodec">
          <a class="btn_baycodec secundario_baycodec" href="admin-cupones.php?alternar_activo=<?= (int) $c_baycodec['id'] ?>"><?= $c_baycodec['activo'] ? '⏸ Pausar' : '▶ Activar' ?></a>
          <a class="btn_baycodec peligro_baycodec" href="admin-cupones.php?eliminar=<?= (int) $c_baycodec['id'] ?>"
             onclick="return confirm('¿Eliminar el cupón &quot;<?= v_cup_baycodec($c_baycodec['codigo']) ?>&quot;?');">🗑️</a>
        </td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

</body>
</html>
