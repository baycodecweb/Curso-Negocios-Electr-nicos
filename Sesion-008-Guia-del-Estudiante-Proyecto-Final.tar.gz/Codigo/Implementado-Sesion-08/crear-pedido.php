<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// CREAR PEDIDO (endpoint JSON) — Sesión 8
// ------------------------------------------------------------
// Reemplaza a crearPedido_baycodec() de db-modelo.js (que guardaba
// el pedido en localStorage, sin servidor) por un pedido real
// guardado en MySQL, ligado a la cuenta que inició sesión.
//
// Nota de ética/seguridad: el precio de cada producto se vuelve a
// buscar aquí en la base de datos por su código — nunca se confía
// en el precio que mande el navegador, porque cualquiera podría
// editarlo desde las herramientas de desarrollador antes de enviarlo.
// Lo mismo aplica al cupón (mejora post-Sesión 8): el descuento
// siempre se recalcula aquí a partir del código, nunca del monto que
// mande el navegador.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

$cliente_baycodec = clienteActual_baycodec();
if (!$cliente_baycodec) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión para generar un pedido.']);
    exit;
}

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$items_baycodec = $cuerpo_baycodec['items'] ?? [];

if (!is_array($items_baycodec) || count($items_baycodec) === 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'mensaje' => 'El carrito está vacío.']);
    exit;
}

$consultaProducto_baycodec = $pdo_baycodec->prepare(
    'SELECT codigo, nombre, precio_referencial_pen, vendedor_id FROM productos_tb_baycodec WHERE codigo = ? AND activo = 1'
);
// Variantes de producto (mejora post-Sesión 8): el navegador manda
// "codigo::varianteId" cuando la tarjeta tenía un selector de
// variante (ver tienda.php); se vuelve a validar aquí que esa
// variante exista, esté activa y pertenezca a ESE producto — nunca se
// confía en el precio_extra que el navegador ya sumó.
$consultaVarianteCrear_baycodec = $pdo_baycodec->prepare(
    'SELECT id, nombre_variante, precio_extra FROM producto_variantes_tb_baycodec WHERE id = ? AND producto_codigo = ? AND activo = 1'
);

$detalleValidado_baycodec = [];
foreach ($items_baycodec as $item_baycodec) {
    $idCrudo_baycodec = trim($item_baycodec['id'] ?? '');
    $cantidad_baycodec = (int) ($item_baycodec['cantidad'] ?? 0);
    if ($idCrudo_baycodec === '' || $cantidad_baycodec <= 0) {
        continue;
    }

    $varianteId_baycodec = null;
    $codigo_baycodec = $idCrudo_baycodec;
    if (str_contains($idCrudo_baycodec, '::')) {
        [$codigo_baycodec, $varianteIdTexto_baycodec] = explode('::', $idCrudo_baycodec, 2);
        $varianteId_baycodec = (int) $varianteIdTexto_baycodec;
    }

    $consultaProducto_baycodec->execute([$codigo_baycodec]);
    $producto_baycodec = $consultaProducto_baycodec->fetch();
    if (!$producto_baycodec) {
        continue; // producto inexistente o inactivo: se ignora, no se confía en el carrito del navegador
    }

    $precioUnitarioFinal_baycodec = (float) $producto_baycodec['precio_referencial_pen'];
    $varianteNombre_baycodec = '';

    if ($varianteId_baycodec !== null) {
        $consultaVarianteCrear_baycodec->execute([$varianteId_baycodec, $codigo_baycodec]);
        $variante_baycodec = $consultaVarianteCrear_baycodec->fetch();
        if (!$variante_baycodec) {
            continue; // variante inexistente, inactiva o de otro producto: se ignora esta línea
        }
        $precioUnitarioFinal_baycodec += (float) $variante_baycodec['precio_extra'];
        $varianteNombre_baycodec = $variante_baycodec['nombre_variante'];
    }

    $detalleValidado_baycodec[] = [
        'codigo' => $producto_baycodec['codigo'],
        'nombre' => $producto_baycodec['nombre'],
        'cantidad' => $cantidad_baycodec,
        'precio_unitario' => $precioUnitarioFinal_baycodec,
        // Se guarda fijo en el detalle (no se vuelve a consultar
        // productos después): así el vendedor sigue viendo "quién le
        // compró" en mis-productos.php aunque luego edite o borre
        // ese producto.
        'vendedor_id' => $producto_baycodec['vendedor_id'],
        'variante_id' => $varianteId_baycodec,
        'variante_nombre' => $varianteNombre_baycodec,
    ];
}

if (count($detalleValidado_baycodec) === 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'mensaje' => 'Ninguno de los productos del carrito es válido.']);
    exit;
}

$totalSinDescuento_baycodec = array_reduce($detalleValidado_baycodec, function ($acumulado, $fila) {
    return $acumulado + $fila['precio_unitario'] * $fila['cantidad'];
}, 0.0);

// ------------------------------------------------------------
// Dirección de envío (mejora post-Sesión 8): el cliente puede elegir
// una de sus direcciones guardadas (ver mis-direcciones.php); si no
// eligió ninguna, o eligió una que no le pertenece, se usa la
// dirección de siempre del perfil para no bloquear el pedido.
// direccion_envio_texto guarda el texto tal cual quedó al momento del
// pedido — si luego edita o borra esa dirección, el pedido no pierde
// el dato de a dónde se envió.
// ------------------------------------------------------------
$direccionId_baycodec = (int) ($cuerpo_baycodec['direccion_id'] ?? 0);
$direccionTexto_baycodec = '';

if ($direccionId_baycodec > 0) {
    $consultaDireccion_baycodec = $pdo_baycodec->prepare('SELECT direccion FROM direcciones_tb_baycodec WHERE id = ? AND cliente_id = ?');
    $consultaDireccion_baycodec->execute([$direccionId_baycodec, $cliente_baycodec['id']]);
    $direccionFila_baycodec = $consultaDireccion_baycodec->fetch();
    if ($direccionFila_baycodec) {
        $direccionTexto_baycodec = $direccionFila_baycodec['direccion'];
    } else {
        $direccionId_baycodec = 0; // no le pertenece: se ignora
    }
}

if ($direccionTexto_baycodec === '') {
    $consultaDireccionDefecto_baycodec = $pdo_baycodec->prepare('SELECT direccion FROM clientes_tb_baycodec WHERE id = ?');
    $consultaDireccionDefecto_baycodec->execute([$cliente_baycodec['id']]);
    $direccionTexto_baycodec = (string) $consultaDireccionDefecto_baycodec->fetchColumn();
    $direccionId_baycodec = 0;
}

// ------------------------------------------------------------
// Cupón de descuento (mejora post-Sesión 8): se vuelve a validar y
// calcular aquí, nunca se confía en un "total con descuento" que
// mande el navegador.
// ------------------------------------------------------------
$codigoCupon_baycodec = trim($cuerpo_baycodec['codigo_cupon'] ?? '');
$cuponId_baycodec = null;
$descuentoAplicado_baycodec = 0.0;

if ($codigoCupon_baycodec !== '') {
    $consultaCupon_baycodec = $pdo_baycodec->prepare('SELECT * FROM cupones_tb_baycodec WHERE codigo = ?');
    $consultaCupon_baycodec->execute([$codigoCupon_baycodec]);
    $cupon_baycodec = $consultaCupon_baycodec->fetch();

    $hoy_baycodec = date('Y-m-d');
    $cuponValido_baycodec = $cupon_baycodec
        && (int) $cupon_baycodec['activo'] === 1
        && ($cupon_baycodec['fecha_inicio'] === null || $cupon_baycodec['fecha_inicio'] <= $hoy_baycodec)
        && ($cupon_baycodec['fecha_fin'] === null || $cupon_baycodec['fecha_fin'] >= $hoy_baycodec)
        && ($cupon_baycodec['usos_maximos'] === null || (int) $cupon_baycodec['usos_actuales'] < (int) $cupon_baycodec['usos_maximos']);

    if (!$cuponValido_baycodec) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'mensaje' => 'Ese cupón no es válido, ya expiró o alcanzó su límite de usos.']);
        exit;
    }

    $cuponId_baycodec = (int) $cupon_baycodec['id'];
    $descuentoAplicado_baycodec = $cupon_baycodec['tipo'] === 'porcentaje'
        ? round($totalSinDescuento_baycodec * ((float) $cupon_baycodec['valor'] / 100), 2)
        : min((float) $cupon_baycodec['valor'], $totalSinDescuento_baycodec); // nunca deja el total en negativo
}

// ------------------------------------------------------------
// Envío por zona (mejora post-Sesión 8): igual que con el cupón, el
// costo se vuelve a buscar aquí por el NOMBRE de la zona — nunca se
// confía en un costo de envío que mande el navegador. Una zona
// inválida o inactiva simplemente se ignora (envío gratis), no
// bloquea el pedido.
// ------------------------------------------------------------
$zonaEnvio_baycodec = trim($cuerpo_baycodec['zona_envio'] ?? '');
$envioCosto_baycodec = 0.0;

if ($zonaEnvio_baycodec !== '') {
    $consultaTarifa_baycodec = $pdo_baycodec->prepare('SELECT costo FROM tarifas_envio_tb_baycodec WHERE zona = ? AND activo = 1');
    $consultaTarifa_baycodec->execute([$zonaEnvio_baycodec]);
    $costoTarifa_baycodec = $consultaTarifa_baycodec->fetchColumn();
    if ($costoTarifa_baycodec !== false) {
        $envioCosto_baycodec = (float) $costoTarifa_baycodec;
    } else {
        $zonaEnvio_baycodec = '';
    }
}

// ------------------------------------------------------------
// IGV (mejora post-Sesión 8): el precio del catálogo YA incluye IGV
// (como cualquier vitrina peruana orientada a consumidor final) — acá
// solo se DESGLOSA cuánto de ese subtotal corresponde al impuesto,
// no se suma aparte. Lo único que sí se suma al total es el envío.
// ------------------------------------------------------------
$igvPorcentaje_baycodec = (float) obtenerConfiguracion_baycodec($pdo_baycodec, 'igv_porcentaje', '18');
$igvMonto_baycodec = round($totalSinDescuento_baycodec - ($totalSinDescuento_baycodec / (1 + $igvPorcentaje_baycodec / 100)), 2);

$totalFinal_baycodec = round($totalSinDescuento_baycodec - $descuentoAplicado_baycodec + $envioCosto_baycodec, 2);

$pdo_baycodec->beginTransaction();

$insertarPedido_baycodec = $pdo_baycodec->prepare(
    'INSERT INTO pedidos_tb_baycodec (cliente_id, total, estado, direccion_id, direccion_envio_texto, cupon_id, descuento_aplicado, subtotal, igv_monto, envio_costo, envio_zona)
     VALUES (?, ?, "Pendiente", ?, ?, ?, ?, ?, ?, ?, ?)'
);
$insertarPedido_baycodec->execute([
    $cliente_baycodec['id'],
    $totalFinal_baycodec,
    $direccionId_baycodec ?: null,
    $direccionTexto_baycodec,
    $cuponId_baycodec,
    $descuentoAplicado_baycodec,
    $totalSinDescuento_baycodec,
    $igvMonto_baycodec,
    $envioCosto_baycodec,
    $zonaEnvio_baycodec,
]);
$pedidoId_baycodec = (int) $pdo_baycodec->lastInsertId();

$insertarDetalle_baycodec = $pdo_baycodec->prepare(
    'INSERT INTO detalle_pedido_tb_baycodec (pedido_id, producto_codigo, producto_nombre, cantidad, precio_unitario, vendedor_id, variante_id, variante_nombre)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
);
foreach ($detalleValidado_baycodec as $fila_baycodec) {
    $insertarDetalle_baycodec->execute([
        $pedidoId_baycodec,
        $fila_baycodec['codigo'],
        $fila_baycodec['nombre'],
        $fila_baycodec['cantidad'],
        $fila_baycodec['precio_unitario'],
        $fila_baycodec['vendedor_id'],
        $fila_baycodec['variante_id'],
        $fila_baycodec['variante_nombre'],
    ]);
}

if ($cuponId_baycodec !== null) {
    $pdo_baycodec->prepare('UPDATE cupones_tb_baycodec SET usos_actuales = usos_actuales + 1 WHERE id = ?')->execute([$cuponId_baycodec]);
}

$insertarPago_baycodec = $pdo_baycodec->prepare(
    'INSERT INTO pagos_tb_baycodec (pedido_id, estado) VALUES (?, "Pendiente")'
);
$insertarPago_baycodec->execute([$pedidoId_baycodec]);
$pagoId_baycodec = (int) $pdo_baycodec->lastInsertId();

$pdo_baycodec->commit();

$resumen_baycodec = implode(', ', array_map(
    fn($f) => "{$f['cantidad']} x {$f['nombre']}" . ($f['variante_nombre'] !== '' ? " ({$f['variante_nombre']})" : ''),
    $detalleValidado_baycodec
));

registrarNotificacion_baycodec(
    $pdo_baycodec,
    $cliente_baycodec['id'],
    'pedido_generado',
    "Pedido #{$pedidoId_baycodec} registrado — Grafiluz",
    "Registramos tu pedido #{$pedidoId_baycodec} ({$resumen_baycodec}) por un total de S/ " . number_format($totalFinal_baycodec, 2) . '.'
);

echo json_encode([
    'ok' => true,
    'pedido_id' => $pedidoId_baycodec,
    'pago_id' => $pagoId_baycodec,
    'total' => $totalFinal_baycodec,
    'descuento_aplicado' => $descuentoAplicado_baycodec,
    'envio_costo' => $envioCosto_baycodec,
    'envio_zona' => $zonaEnvio_baycodec,
    'direccion_envio' => $direccionTexto_baycodec,
    'resumen' => $resumen_baycodec,
]);
