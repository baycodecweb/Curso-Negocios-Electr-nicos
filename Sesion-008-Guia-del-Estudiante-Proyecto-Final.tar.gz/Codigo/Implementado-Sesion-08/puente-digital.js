var __marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Codigo del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// EL PUENTE DIGITAL — Sesión 2: E-business & E-commerce
// ------------------------------------------------------------
// Objetivo pedagógico: demostrar, con una prueba de concepto real,
// que una tienda puede CONECTARSE a un servicio externo mediante
// una API para ampliar su alcance de negocio. Aquí no compramos
// nada ni vendemos nada: E-COMMERCE sería la transacción en sí.
// Este script pertenece al mundo del E-BUSINESS: es un proceso de
// integración/soporte que hace más inteligente al negocio.
//
// Caso elegido: Grafiluz vende a empresas que podrían tener
// clientes o proveedores en otros países. Este script consulta el
// tipo de cambio del día (Soles -> Dólares / Euros) usando una API
// pública GRATUITA y SIN NECESIDAD DE API KEY, y muestra los
// precios referenciales del catálogo ya convertidos.
//
// API utilizada: open.er-api.com (Exchange Rate API - Open Access)
// Documentación: https://www.exchangerate-api.com/docs/free
// ============================================================

const API_TIPO_CAMBIO_baycodec = "https://open.er-api.com/v6/latest/PEN";

/**
 * Obtiene las tasas de cambio actuales desde la API externa.
 * @returns {Promise<Object>} objeto con tasas, ej: { USD: 0.27, EUR: 0.25, ... }
 */
async function obtenerTasasDeCambio_baycodec() {
  const respuesta = await fetch(API_TIPO_CAMBIO_baycodec);

  if (!respuesta.ok) {
    throw new Error(`La API respondió con error: ${respuesta.status}`);
  }

  const datos = await respuesta.json();

  if (datos.result !== "success") {
    throw new Error("La API no devolvió tasas de cambio válidas.");
  }

  return datos.rates; // { USD: 0.27, EUR: 0.25, ... }
}

/**
 * Actualiza EN VIVO el precio de cada producto real del catálogo
 * (todas las categorías) usando las tasas de cambio obtenidas de la
 * API. Cada tarjeta de producto ya trae su propio precio de
 * referencia en Soles marcado con data-pen="..." en el HTML.
 * @param {Object} tasas - tasas de cambio devueltas por la API
 */
function actualizarPreciosCatalogoReal_baycodec(tasas) {
  const elementos = document.querySelectorAll(".card-precio_baycodec[data-pen]");

  elementos.forEach((el) => {
    const precioPEN = parseFloat(el.dataset.pen);
    const spanConvertido = el.querySelector(".card-precio-convertido_baycodec");
    if (!spanConvertido || Number.isNaN(precioPEN)) return;

    const partes = [];
    if (tasas.USD) partes.push(`$${(precioPEN * tasas.USD).toFixed(2)} USD`);
    if (tasas.EUR) partes.push(`€${(precioPEN * tasas.EUR).toFixed(2)} EUR`);

    spanConvertido.textContent = partes.length ? ` \u2248 ${partes.join(" \u00b7 ")}` : "";
  });
}

/**
 * Punto de entrada: conecta con la API de tipo de cambio y actualiza
 * en pantalla el precio convertido de todo el catálogo. Si algo falla
 * (sin internet, API caída, etc.) se informa el error sin romper el
 * resto del sitio.
 */
async function iniciarPuenteDigital_baycodec() {
  const estado = document.getElementById("pd-estado");

  try {
    if (estado) estado.textContent = "Consultando tipo de cambio...";

    const tasas = await obtenerTasasCacheadas_baycodec();
    actualizarPreciosCatalogoReal_baycodec(tasas);

    if (estado) {
      estado.textContent = `Tipo de cambio actualizado. 1 PEN = ${tasas.USD} USD | ${tasas.EUR} EUR. Revisa el precio convertido junto a cada producto del catálogo.`;
    }
  } catch (error) {
    console.error("Error en el Puente Digital:", error);
    if (estado) {
      estado.textContent =
        "No se pudo conectar con la API externa. Intenta nuevamente más tarde.";
    }
  }
}

// ============================================================
// SELECTOR DE PAÍS EN EL <nav> — misma API y el mismo dato
// data-pen de cada tarjeta; solo cambia dónde se dispara la
// consulta (desde el menú, visible en todo momento) y que aquí
// se muestra UNA sola moneda a la vez (la del país elegido), en
// vez de USD y EUR juntos como hace el botón de la sección
// "Precios Referenciales Internacionales" más abajo.
// ============================================================

let tasasCacheadas_baycodec = null;

/** Reutiliza las tasas ya consultadas en esta visita para no golpear la API en cada cambio de país. */
async function obtenerTasasCacheadas_baycodec() {
  if (!tasasCacheadas_baycodec) {
    tasasCacheadas_baycodec = await obtenerTasasDeCambio_baycodec();
  }
  return tasasCacheadas_baycodec;
}

const SIMBOLO_POR_MONEDA_baycodec = {
  USD: "$",
  EUR: "€",
  MXN: "MX$",
  CLP: "CL$",
  COP: "CO$",
};

function limpiarPreciosConvertidos_baycodec() {
  document.querySelectorAll(".card-precio-convertido_baycodec").forEach((span) => {
    span.textContent = "";
  });
}

function actualizarPreciosPorMoneda_baycodec(tasas, codigoMoneda) {
  const tasa = tasas[codigoMoneda];
  if (!tasa) return;

  const simbolo = SIMBOLO_POR_MONEDA_baycodec[codigoMoneda] || "";

  document.querySelectorAll(".card-precio_baycodec[data-pen]").forEach((el) => {
    const precioPEN = parseFloat(el.dataset.pen);
    const spanConvertido = el.querySelector(".card-precio-convertido_baycodec");
    if (!spanConvertido || Number.isNaN(precioPEN)) return;

    spanConvertido.textContent = ` ≈ ${simbolo}${(precioPEN * tasa).toFixed(2)} ${codigoMoneda}`;
  });
}

/**
 * Llamado por el <select> del nav al elegir un país. "PEN" (Perú, la
 * moneda base de la tienda) simplemente quita cualquier conversión
 * mostrada; el resto de países consulta/reusa el tipo de cambio y
 * actualiza el precio convertido junto a cada producto del catálogo.
 */
async function cambiarMonedaDesdeNav_baycodec(codigoMoneda) {
  const estado = document.getElementById("pd-estado");

  if (codigoMoneda === "PEN") {
    limpiarPreciosConvertidos_baycodec();
    if (estado) estado.textContent = "Mostrando precios en Soles (PEN), la moneda base de la tienda.";
    return;
  }

  try {
    if (estado) estado.textContent = "Consultando tipo de cambio...";

    const tasas = await obtenerTasasCacheadas_baycodec();
    actualizarPreciosPorMoneda_baycodec(tasas, codigoMoneda);
    registrarEvento_baycodec("clic_precios_internacionales", { pais: codigoMoneda });

    if (estado) {
      estado.textContent = `Tipo de cambio actualizado. 1 PEN = ${tasas[codigoMoneda]} ${codigoMoneda}. Revisa el precio convertido junto a cada producto del catálogo.`;
    }
  } catch (error) {
    console.error("Error al cambiar de moneda:", error);
    if (estado) {
      estado.textContent =
        "No se pudo conectar con la API externa. Intenta nuevamente más tarde.";
    }
  }
}
