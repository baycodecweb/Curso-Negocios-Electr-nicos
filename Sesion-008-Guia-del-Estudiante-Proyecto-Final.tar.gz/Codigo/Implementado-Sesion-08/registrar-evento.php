<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// REGISTRAR EVENTO DE ANALÍTICA (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// Hasta ahora motor-analitica.js solo guardaba los eventos en el
// localStorage del propio navegador — el Panel de Control mostraba
// datos reales solo de quien lo abría, nunca de todos los visitantes
// del sitio. Este endpoint recibe ese mismo evento y lo guarda de
// verdad en la tabla eventos_analitica (ver db-conexion.php), para
// que obtener-analitica.php pueda calcular estadísticas agregadas de
// TODO el sitio.
//
// No requiere sesión de cliente: la mayoría de los eventos (navegar
// el catálogo, un clic a WhatsApp) los genera cualquier visitante sin
// cuenta. cliente_id queda NULL en ese caso.
// ============================================================

require_once __DIR__ . '/db-conexion.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json; charset=utf-8');

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$tipoEvento_baycodec = trim($cuerpo_baycodec['tipo_evento'] ?? '');
$datos_baycodec = $cuerpo_baycodec['datos'] ?? [];
$pagina_baycodec = trim($cuerpo_baycodec['pagina'] ?? '');

if ($tipoEvento_baycodec === '') {
    http_response_code(400);
    echo json_encode(['ok' => false]);
    exit;
}

// mb_substr protege contra un "datos" gigante (o mal intencionado)
// que no quepa en la columna — nunca debe tumbar el registro del
// evento por un detalle de tamaño.
$datosJson_baycodec = mb_substr(json_encode($datos_baycodec, JSON_UNESCAPED_UNICODE) ?: '{}', 0, 1000);

$pdo_baycodec->prepare('INSERT INTO eventos_analitica_tb_baycodec (tipo_evento, datos_json, pagina, cliente_id) VALUES (?, ?, ?, ?)')
    ->execute([mb_substr($tipoEvento_baycodec, 0, 60), $datosJson_baycodec, mb_substr($pagina_baycodec, 0, 80), $_SESSION['cliente_id_baycodec'] ?? null]);

echo json_encode(['ok' => true]);
