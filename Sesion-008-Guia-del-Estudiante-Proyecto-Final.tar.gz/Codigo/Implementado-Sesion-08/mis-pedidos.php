<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// MIS PEDIDOS (historial de compras del cliente) — Sesión 8
// ------------------------------------------------------------
// Complemento de mis-productos.php: así como un vendedor C2C solo ve
// lo que ÉL vende, cualquier cliente (B2C/B2B/C2C) solo ve lo que ÉL
// compró — nunca los pedidos de otros clientes. El admin (baycodec)
// sigue siendo el único que ve TODOS los pedidos de todos los
// clientes, desde panel-control.html (obtener-pedidos.php).
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

$clienteActual_baycodec = clienteActual_baycodec();
if (!$clienteActual_baycodec) {
    header('Location: login-cliente.php');
    exit;
}

// WHERE cliente_id = <su propia cuenta> -> jamás ve el pedido de otro,
// ni cambiando el id en la URL (aquí ni siquiera se recibe un id).
$consulta_baycodec = $pdo_baycodec->prepare(
    'SELECT p.id, p.total, p.estado, p.creado_en, p.subtotal, p.igv_monto, p.envio_costo, p.envio_zona,
            p.descuento_aplicado, p.direccion_envio_texto, pg.estado AS pago_estado, pg.transaccion_id
     FROM pedidos_tb_baycodec p
     LEFT JOIN pagos_tb_baycodec pg ON pg.pedido_id = p.id
     WHERE p.cliente_id = ?
     ORDER BY p.id DESC'
);
$consulta_baycodec->execute([(int) $clienteActual_baycodec['id']]);
$misPedidos_baycodec = $consulta_baycodec->fetchAll();

$consultaDetalle_baycodec = $pdo_baycodec->prepare(
    'SELECT dp.producto_codigo, dp.producto_nombre, dp.cantidad, dp.precio_unitario, dp.vendedor_id, dp.variante_nombre, c.nombre AS vendedor_nombre
     FROM detalle_pedido_tb_baycodec dp
     LEFT JOIN clientes_tb_baycodec c ON c.id = dp.vendedor_id
     WHERE dp.pedido_id = ?'
);

// Calificación al vendedor (mejora post-Sesión 8, distinta de
// "resenas" que califica el PRODUCTO): todas las que este cliente ya
// dejó, indexadas por vendedor_id, para precargar el widget.
$consultaMisCalifVendedor_baycodec = $pdo_baycodec->prepare('SELECT vendedor_id, calificacion, comentario FROM calificaciones_vendedor_tb_baycodec WHERE cliente_id = ?');
$consultaMisCalifVendedor_baycodec->execute([(int) $clienteActual_baycodec['id']]);
$misCalificacionesVendedor_baycodec = [];
foreach ($consultaMisCalifVendedor_baycodec->fetchAll() as $calif_baycodec) {
    $misCalificacionesVendedor_baycodec[$calif_baycodec['vendedor_id']] = $calif_baycodec;
}

// Reseñas / calificaciones (mejora post-Sesión 8): todas las que este
// cliente ya dejó, indexadas por código de producto, para precargar el
// widget de estrellas si ya calificó ese producto antes (y mostrar
// "Actualizar reseña" en vez de "Calificar producto").
$consultaMisResenas_baycodec = $pdo_baycodec->prepare('SELECT producto_codigo, calificacion, comentario FROM resenas_tb_baycodec WHERE cliente_id = ?');
$consultaMisResenas_baycodec->execute([(int) $clienteActual_baycodec['id']]);
$misResenas_baycodec = [];
foreach ($consultaMisResenas_baycodec->fetchAll() as $resena_baycodec) {
    $misResenas_baycodec[$resena_baycodec['producto_codigo']] = $resena_baycodec;
}

function v_mped_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

// Cancelar/reembolsar un pedido (panel de admin, admin-productos.php)
// cambia el estado a algo distinto de "Pendiente"/"Pagado" — aquí se
// les da su propio color para que el cliente entienda de un vistazo
// qué pasó con su pedido, en vez de verlo siempre en ámbar "pendiente".
function claseEstadoPedido_mped_baycodec($estado) {
    if ($estado === 'Pagado') {
        return 'estado-pagado_baycodec';
    }
    if ($estado === 'Cancelado' || $estado === 'Reembolsado') {
        return 'estado-cancelado_baycodec';
    }
    return 'estado-pendiente_baycodec';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Pedidos — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .pedido-tarjeta_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .pedido-encabezado_baycodec { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
  .pedido-encabezado_baycodec h3 { margin: 0; font-size: 1rem; }
  .estado-pendiente_baycodec { color: #92400e; font-weight: 600; }
  .estado-pagado_baycodec { color: #166534; font-weight: 600; }
  .estado-cancelado_baycodec { color: #6b7280; font-weight: 600; }
  .pedido-detalle_baycodec { font-size: 0.85rem; color: #4b5563; margin-top: 10px; padding-top: 10px; border-top: 1px solid #f3f4f6; }
  .pedido-detalle-fila_baycodec { display: flex; justify-content: space-between; padding: 2px 0; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.9rem; }
  .resena-widget_baycodec { margin: 6px 0 4px; padding-top: 6px; border-top: 1px dashed #e5e7eb; }
  .resena-estrellas_baycodec { font-size: 1.15rem; cursor: pointer; color: #d1d5db; line-height: 1; }
  .resena-estrellas_baycodec span { margin-right: 2px; }
  .resena-estrellas_baycodec span.activa_baycodec { color: #f59e0b; }
  .resena-comentario_baycodec { width: 100%; box-sizing: border-box; margin-top: 6px; padding: 6px 8px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.8rem; resize: vertical; min-height: 38px; }
  .resena-btn_baycodec { margin-top: 6px; background: #1d4ed8; color: #fff; border: none; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 0.78rem; font-weight: 600; }
  .resena-btn_baycodec:disabled { opacity: .6; cursor: default; }
  .resena-estado_baycodec { display: block; margin-top: 4px; font-size: 0.78rem; }
  .resena-vendedor_baycodec { border-top-color: #ddd6fe; }
</style>
</head>
<body>

<h1>🧾 Mis Pedidos — Grafiluz</h1>
<p class="subtitulo_baycodec">Historial de tus compras. Solo tú puedes ver estos pedidos.</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="tienda.php" style="background:#C41F25;">🌐 Ir al sitio</a>
  <a class="btn_baycodec secundario_baycodec" href="carrito.php" style="margin-left:8px;">🛒 Mi carrito</a>
  <a class="btn_baycodec secundario_baycodec" href="mi-perfil.php" style="margin-left:8px;">👤 Mi perfil</a>
  <a class="btn_baycodec secundario_baycodec" href="mis-direcciones.php" style="margin-left:8px;">📍 Mis direcciones</a>
  <a class="btn_baycodec secundario_baycodec" href="mis-favoritos.php" style="margin-left:8px;">❤️ Mis favoritos</a>
  <a class="btn_baycodec secundario_baycodec" href="mis-notificaciones.php" style="margin-left:8px;">📨 Notificaciones</a>
  <?php if ($clienteActual_baycodec['tipo_cliente'] === 'C2C'): ?>
    <a class="btn_baycodec secundario_baycodec" href="mis-productos.php" style="margin-left:8px;">🛍️ Mis productos</a>
  <?php endif; ?>
</div>

<?php if (empty($misPedidos_baycodec)): ?>
  <p class="vacio_baycodec">Todavía no generaste ningún pedido. <a href="tienda.php">Ve al catálogo</a> para empezar.</p>
<?php else: foreach ($misPedidos_baycodec as $pedido_baycodec): ?>
  <?php
    $consultaDetalle_baycodec->execute([$pedido_baycodec['id']]);
    $itemsPedido_baycodec = $consultaDetalle_baycodec->fetchAll();
    $claseEstadoPedido_baycodec = claseEstadoPedido_mped_baycodec($pedido_baycodec['estado']);
  ?>
  <div class="pedido-tarjeta_baycodec">
    <div class="pedido-encabezado_baycodec">
      <h3>Pedido #<?= (int) $pedido_baycodec['id'] ?> — <?= v_mped_baycodec(date('d/m/Y H:i', strtotime($pedido_baycodec['creado_en']))) ?></h3>
      <span class="<?= $claseEstadoPedido_baycodec ?>"><?= v_mped_baycodec($pedido_baycodec['estado']) ?></span>
    </div>
    <div class="pedido-detalle_baycodec">
      <?php foreach ($itemsPedido_baycodec as $item_baycodec): ?>
        <div class="pedido-detalle-fila_baycodec">
          <span><?= (int) $item_baycodec['cantidad'] ?> x <?= v_mped_baycodec($item_baycodec['producto_nombre']) ?><?= $item_baycodec['variante_nombre'] ? ' (' . v_mped_baycodec($item_baycodec['variante_nombre']) . ')' : '' ?></span>
          <span>S/ <?= number_format($item_baycodec['cantidad'] * $item_baycodec['precio_unitario'], 2) ?></span>
        </div>
        <?php if ($pedido_baycodec['estado'] === 'Pagado'): ?>
          <?php $miResena_baycodec = $misResenas_baycodec[$item_baycodec['producto_codigo']] ?? null; ?>
          <div class="resena-widget_baycodec" data-codigo="<?= v_mped_baycodec($item_baycodec['producto_codigo']) ?>">
            <div class="resena-estrellas_baycodec" data-seleccion="<?= (int) ($miResena_baycodec['calificacion'] ?? 0) ?>">
              <span data-valor="1">★</span><span data-valor="2">★</span><span data-valor="3">★</span><span data-valor="4">★</span><span data-valor="5">★</span>
            </div>
            <textarea class="resena-comentario_baycodec" placeholder="Cuéntanos qué te pareció (opcional)"><?= v_mped_baycodec($miResena_baycodec['comentario'] ?? '') ?></textarea>
            <button type="button" class="resena-btn_baycodec" onclick="guardarResena_baycodec(this)"><?= $miResena_baycodec ? '✏️ Actualizar reseña' : '⭐ Calificar producto' ?></button>
            <span class="resena-estado_baycodec"></span>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>

      <?php if ($pedido_baycodec['estado'] === 'Pagado'):
        // Calificación al vendedor (mejora post-Sesión 8): una sola
        // vez por vendedor distinto en este pedido, no una por línea
        // (si compraste 3 productos del mismo vendedor C2C, se
        // califica al vendedor una sola vez, no tres).
        $vendedoresEnPedido_baycodec = [];
        foreach ($itemsPedido_baycodec as $item_baycodec) {
            if ($item_baycodec['vendedor_id'] && !isset($vendedoresEnPedido_baycodec[$item_baycodec['vendedor_id']])) {
                $vendedoresEnPedido_baycodec[$item_baycodec['vendedor_id']] = $item_baycodec['vendedor_nombre'];
            }
        }
      ?>
        <?php foreach ($vendedoresEnPedido_baycodec as $vendedorId_mped_baycodec => $vendedorNombre_mped_baycodec): ?>
          <?php $miCalifVendedor_baycodec = $misCalificacionesVendedor_baycodec[$vendedorId_mped_baycodec] ?? null; ?>
          <div class="resena-widget_baycodec resena-vendedor_baycodec" data-vendedor-id="<?= (int) $vendedorId_mped_baycodec ?>">
            <p style="margin:0 0 4px; font-size:0.8rem; color:#6b7280;">Calificar al vendedor <strong><?= v_mped_baycodec($vendedorNombre_mped_baycodec) ?></strong>:</p>
            <div class="resena-estrellas_baycodec" data-seleccion="<?= (int) ($miCalifVendedor_baycodec['calificacion'] ?? 0) ?>">
              <span data-valor="1">★</span><span data-valor="2">★</span><span data-valor="3">★</span><span data-valor="4">★</span><span data-valor="5">★</span>
            </div>
            <textarea class="resena-comentario_baycodec" placeholder="¿Cómo fue tu experiencia con este vendedor? (opcional)"><?= v_mped_baycodec($miCalifVendedor_baycodec['comentario'] ?? '') ?></textarea>
            <button type="button" class="resena-btn_baycodec" onclick="guardarCalificacionVendedor_baycodec(this)"><?= $miCalifVendedor_baycodec ? '✏️ Actualizar calificación' : '⭐ Calificar vendedor' ?></button>
            <span class="resena-estado_baycodec"></span>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>

      <?php if ((float) $pedido_baycodec['subtotal'] > 0): ?>
        <div class="pedido-detalle-fila_baycodec" style="color:#9ca3af; font-size:0.78rem;">
          <span>Subtotal (incluye IGV <?= number_format((float) $pedido_baycodec['igv_monto'], 2) ?>)</span>
          <span>S/ <?= number_format((float) $pedido_baycodec['subtotal'], 2) ?></span>
        </div>
        <?php if ((float) $pedido_baycodec['descuento_aplicado'] > 0): ?>
          <div class="pedido-detalle-fila_baycodec" style="color:#16a34a; font-size:0.78rem;">
            <span>Descuento</span>
            <span>− S/ <?= number_format((float) $pedido_baycodec['descuento_aplicado'], 2) ?></span>
          </div>
        <?php endif; ?>
        <?php if ($pedido_baycodec['envio_zona']): ?>
          <div class="pedido-detalle-fila_baycodec" style="color:#9ca3af; font-size:0.78rem;">
            <span>Envío (<?= v_mped_baycodec($pedido_baycodec['envio_zona']) ?>)</span>
            <span><?= (float) $pedido_baycodec['envio_costo'] > 0 ? 'S/ ' . number_format((float) $pedido_baycodec['envio_costo'], 2) : 'Gratis' ?></span>
          </div>
        <?php endif; ?>
      <?php endif; ?>
      <div class="pedido-detalle-fila_baycodec" style="font-weight:700; margin-top:6px;">
        <span>Total</span>
        <span>S/ <?= number_format((float) $pedido_baycodec['total'], 2) ?></span>
      </div>
      <?php if ($pedido_baycodec['direccion_envio_texto']): ?>
        <p style="margin:8px 0 0; font-size:0.78rem; color:#6b7280;">📍 Envío a: <?= v_mped_baycodec($pedido_baycodec['direccion_envio_texto']) ?></p>
      <?php endif; ?>
      <?php if ($pedido_baycodec['transaccion_id']): ?>
        <p style="margin:4px 0 0; font-size:0.78rem; color:#6b7280;">Transacción: <?= v_mped_baycodec($pedido_baycodec['transaccion_id']) ?></p>
      <?php endif; ?>
    </div>
  </div>
<?php endforeach; endif; ?>

<script>
  // ============================================================
  // RESEÑAS / CALIFICACIONES (mejora post-Sesión 8): widget de
  // estrellas por producto ya pagado. Guarda vía guardar-resena.php,
  // que vuelve a comprobar en el servidor que sí se compró y pagó
  // ese producto — este script solo arma la interfaz.
  // ============================================================
  document.querySelectorAll('.resena-estrellas_baycodec').forEach(function (contenedor) {
    const seleccionInicial = parseInt(contenedor.dataset.seleccion, 10) || 0;
    resenaPintarEstrellas_baycodec(contenedor, seleccionInicial);
    contenedor.querySelectorAll('span').forEach(function (estrella) {
      estrella.addEventListener('click', function () {
        const valor = parseInt(estrella.dataset.valor, 10);
        contenedor.dataset.seleccion = String(valor);
        resenaPintarEstrellas_baycodec(contenedor, valor);
      });
    });
  });

  function resenaPintarEstrellas_baycodec(contenedor, seleccion) {
    contenedor.querySelectorAll('span').forEach(function (estrella) {
      estrella.classList.toggle('activa_baycodec', parseInt(estrella.dataset.valor, 10) <= seleccion);
    });
  }

  async function guardarResena_baycodec(boton) {
    const widget = boton.closest('.resena-widget_baycodec');
    const codigo = widget.dataset.codigo;
    const calificacion = parseInt(widget.querySelector('.resena-estrellas_baycodec').dataset.seleccion, 10) || 0;
    const comentario = widget.querySelector('.resena-comentario_baycodec').value.trim();
    const estado = widget.querySelector('.resena-estado_baycodec');

    if (calificacion < 1) {
      estado.textContent = 'Elige de 1 a 5 estrellas antes de guardar.';
      estado.style.color = '#dc2626';
      return;
    }

    boton.disabled = true;
    try {
      const respuesta = await fetch('guardar-resena.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ producto_codigo: codigo, calificacion, comentario }),
      });
      const resultado = await respuesta.json();

      if (resultado.ok) {
        estado.textContent = '✅ ¡Gracias por tu reseña!';
        estado.style.color = '#16a34a';
        boton.textContent = '✏️ Actualizar reseña';
      } else {
        estado.textContent = '⚠️ ' + (resultado.mensaje || 'No se pudo guardar la reseña.');
        estado.style.color = '#dc2626';
      }
    } finally {
      boton.disabled = false;
    }
  }

  // ============================================================
  // CALIFICACIÓN AL VENDEDOR (mejora post-Sesión 8): mismo widget de
  // estrellas de arriba (ya queda conectado por el querySelectorAll
  // genérico), pero guarda en calificar-vendedor.php, que valida en
  // el servidor que este cliente sí le compró y pagó algo a ese
  // vendedor.
  // ============================================================
  async function guardarCalificacionVendedor_baycodec(boton) {
    const widget = boton.closest('.resena-widget_baycodec');
    const vendedorId = parseInt(widget.dataset.vendedorId, 10);
    const calificacion = parseInt(widget.querySelector('.resena-estrellas_baycodec').dataset.seleccion, 10) || 0;
    const comentario = widget.querySelector('.resena-comentario_baycodec').value.trim();
    const estado = widget.querySelector('.resena-estado_baycodec');

    if (calificacion < 1) {
      estado.textContent = 'Elige de 1 a 5 estrellas antes de guardar.';
      estado.style.color = '#dc2626';
      return;
    }

    boton.disabled = true;
    try {
      const respuesta = await fetch('calificar-vendedor.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vendedor_id: vendedorId, calificacion, comentario }),
      });
      const resultado = await respuesta.json();

      if (resultado.ok) {
        estado.textContent = '✅ ¡Gracias por calificar al vendedor!';
        estado.style.color = '#16a34a';
        boton.textContent = '✏️ Actualizar calificación';
      } else {
        estado.textContent = '⚠️ ' + (resultado.mensaje || 'No se pudo guardar la calificación.');
        estado.style.color = '#dc2626';
      }
    } finally {
      boton.disabled = false;
    }
  }
</script>

</body>
</html>
