<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// REGISTRO DE CLIENTE (COMPRADOR) — Sesión 8
// ------------------------------------------------------------
// Aquí es donde el visitante elige si compra como persona individual
// (B2C), como empresa que compra al por mayor (B2B) o como
// revendedor (C2C) — la misma clasificación que ya explicaba
// db-modelo.js (Sesión 3), pero ahora queda guardada en su cuenta en
// vez de preguntarse de nuevo en cada pedido.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

if (clienteActual_baycodec()) {
    header('Location: carrito.php');
    exit;
}

$errorRegistro_baycodec = '';
$datosFormulario_baycodec = [
    'usuario' => '', 'nombre' => '', 'apellidos' => '', 'dni' => '', 'telefono' => '', 'direccion' => '',
    'latitud' => '', 'longitud' => '', 'tipo_cliente' => 'B2C', 'ruc' => '', 'plataforma_reventa' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $datosFormulario_baycodec['usuario'] = trim($_POST['usuario'] ?? '');
    $datosFormulario_baycodec['nombre'] = trim($_POST['nombre'] ?? '');
    $datosFormulario_baycodec['apellidos'] = trim($_POST['apellidos'] ?? '');
    $datosFormulario_baycodec['dni'] = trim($_POST['dni'] ?? '');
    $datosFormulario_baycodec['telefono'] = trim($_POST['telefono'] ?? '');
    $datosFormulario_baycodec['direccion'] = trim($_POST['direccion'] ?? '');
    $datosFormulario_baycodec['latitud'] = trim($_POST['latitud'] ?? '');
    $datosFormulario_baycodec['longitud'] = trim($_POST['longitud'] ?? '');
    $datosFormulario_baycodec['tipo_cliente'] = $_POST['tipo_cliente'] ?? 'B2C';
    $datosFormulario_baycodec['ruc'] = trim($_POST['ruc'] ?? '');
    $datosFormulario_baycodec['plataforma_reventa'] = trim($_POST['plataforma_reventa'] ?? '');
    $clave_baycodec = $_POST['clave'] ?? '';
    $claveConfirmacion_baycodec = $_POST['clave_confirmacion'] ?? '';

    if ($datosFormulario_baycodec['usuario'] === '' || $datosFormulario_baycodec['nombre'] === '' || $clave_baycodec === ''
        || $datosFormulario_baycodec['dni'] === '' || $datosFormulario_baycodec['telefono'] === '' || $datosFormulario_baycodec['direccion'] === ''
    ) {
        $errorRegistro_baycodec = 'Usuario, nombre, contraseña, DNI, teléfono y dirección son obligatorios (la dirección es donde llegará tu pedido si se envía).';
    } elseif (strlen($clave_baycodec) < 4) {
        $errorRegistro_baycodec = 'La contraseña debe tener al menos 4 caracteres.';
    } elseif ($clave_baycodec !== $claveConfirmacion_baycodec) {
        $errorRegistro_baycodec = 'Las contraseñas no coinciden.';
    } elseif (!in_array($datosFormulario_baycodec['tipo_cliente'], ['B2C', 'B2B', 'C2C'], true)) {
        $errorRegistro_baycodec = 'Tipo de cliente inválido.';
    } else {
        $consultaExiste_baycodec = $pdo_baycodec->prepare('SELECT id FROM clientes_tb_baycodec WHERE usuario = ?');
        $consultaExiste_baycodec->execute([$datosFormulario_baycodec['usuario']]);

        if ($consultaExiste_baycodec->fetch()) {
            $errorRegistro_baycodec = 'Ese usuario ya está registrado. Intenta iniciar sesión.';
        } else {
            // Las coordenadas del mapa son opcionales (no todos los
            // navegadores permiten geolocalización, ni todos hacen clic
            // en el mapa): solo se guardan si de verdad son numéricas.
            $latitud_baycodec = is_numeric($datosFormulario_baycodec['latitud']) ? (float) $datosFormulario_baycodec['latitud'] : null;
            $longitud_baycodec = is_numeric($datosFormulario_baycodec['longitud']) ? (float) $datosFormulario_baycodec['longitud'] : null;

            // ============================================================
            // NOTA (no implementado a propósito): VERIFICACIÓN DE EMAIL
            // ------------------------------------------------------------
            // Este registro NO comprueba que "usuario" (que aquí se pide
            // como correo) exista de verdad ni le pertenezca a quien se
            // está registrando — la cuenta queda activa de inmediato con
            // iniciarSesionCliente_baycodec() unas líneas más abajo.
            //
            // Por qué importa en un e-commerce real:
            //   - Evita cuentas con correos inventados o mal escritos, que
            //     luego nunca reciben la confirmación de su pedido.
            //   - Es la única forma de recuperar una contraseña olvidada:
            //     sin un correo verificado no hay a dónde mandar el enlace
            //     de recuperación (ver también el "olvidé mi contraseña"
            //     pendiente, mencionado en auth-cliente.php).
            //   - Reduce registros falsos/spam hechos con bots.
            //
            // Cómo se implementaría (sin tocar el flujo de arriba):
            //   1. Agregar a la tabla clientes: email_verificado TINYINT(1)
            //      DEFAULT 0, y token_verificacion VARCHAR(64) DEFAULT NULL.
            //   2. Aquí mismo, generar un token aleatorio (bin2hex(random_
            //      bytes(32))), guardarlo en token_verificacion, y EN VEZ DE
            //      iniciar sesión de inmediato, mostrar "revisa tu correo".
            //   3. Enviar un email real con ese token en un enlace (con
            //      PHPMailer + un servidor SMTP, o un servicio como
            //      Resend/SendGrid — un simple mail() de PHP casi siempre
            //      termina en spam o ni sale, no sirve para producción).
            //   4. Crear verificar-email.php?token=... que busque ese
            //      token, ponga email_verificado = 1 y recién ahí llame a
            //      iniciarSesionCliente_baycodec().
            //   5. En login-cliente.php, bloquear el ingreso (con un
            //      mensaje claro) si email_verificado sigue en 0.
            //
            // No se implementó aquí porque requiere un servidor de correo
            // real (SMTP con credenciales) que este entorno de práctica
            // local no tiene — agregar el código sin poder probarlo de
            // verdad dejaría una función a medias, que es peor que no
            // tenerla. Se documenta para que quede clara la brecha y el
            // camino a seguir cuando el sitio se publique con un dominio
            // y correo corporativo real.
            // ============================================================

            $insertar_baycodec = $pdo_baycodec->prepare(
                'INSERT INTO clientes_tb_baycodec (usuario, password_hash, nombre, apellidos, dni, telefono, direccion, latitud, longitud, tipo_cliente, ruc, plataforma_reventa)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $insertar_baycodec->execute([
                $datosFormulario_baycodec['usuario'],
                password_hash($clave_baycodec, PASSWORD_DEFAULT),
                $datosFormulario_baycodec['nombre'],
                $datosFormulario_baycodec['apellidos'],
                $datosFormulario_baycodec['dni'],
                $datosFormulario_baycodec['telefono'],
                $datosFormulario_baycodec['direccion'],
                $latitud_baycodec,
                $longitud_baycodec,
                $datosFormulario_baycodec['tipo_cliente'],
                $datosFormulario_baycodec['tipo_cliente'] === 'B2B' ? $datosFormulario_baycodec['ruc'] : '',
                $datosFormulario_baycodec['tipo_cliente'] === 'C2C' ? $datosFormulario_baycodec['plataforma_reventa'] : '',
            ]);

            $nuevoId_baycodec = (int) $pdo_baycodec->lastInsertId();

            // Direcciones múltiples (mejora post-Sesión 8): la dirección
            // del registro queda guardada como la primera ("Principal" y
            // predeterminada) en la tabla direcciones, para que el
            // cliente ya tenga algo que elegir en mis-direcciones.php y
            // al pagar en carrito.php, sin tener que volver a escribirla.
            $pdo_baycodec->prepare(
                'INSERT INTO direcciones_tb_baycodec (cliente_id, etiqueta, direccion, latitud, longitud, predeterminada)
                 VALUES (?, "Principal", ?, ?, ?, 1)'
            )->execute([$nuevoId_baycodec, $datosFormulario_baycodec['direccion'], $latitud_baycodec, $longitud_baycodec]);

            iniciarSesionCliente_baycodec([
                'id' => $nuevoId_baycodec,
                'usuario' => $datosFormulario_baycodec['usuario'],
                'nombre' => $datosFormulario_baycodec['nombre'],
                'tipo_cliente' => $datosFormulario_baycodec['tipo_cliente'],
            ]);

            header('Location: carrito.php');
            exit;
        }
    }
}

function v_registro_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Crear cuenta — Grafiluz</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
<style>
  body { font-family: system-ui, sans-serif; min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; background: #fafafa; color: #1f2937; padding: 30px 16px; box-sizing: border-box; }
  .caja-registro_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 10px; padding: 30px 32px; width: 100%; max-width: 420px; box-shadow: 0 4px 14px rgba(0,0,0,0.05); }
  h1 { font-size: 1.2rem; margin: 0 0 4px; }
  .subtitulo_baycodec { color: #6b7280; margin: 0 0 18px; font-size: 0.85rem; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"], input[type="password"], select { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .ayuda_baycodec { font-size: 0.78rem; color: #6b7280; margin-top: 3px; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-size: 0.9rem; font-weight: 600; width: 100%; margin-top: 18px; }
  .btn_baycodec:hover { background: #1e40af; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0 0; }
  .enlace-login_baycodec { text-align: center; font-size: 0.85rem; margin-top: 14px; }
  .campo-clave_baycodec { position: relative; }
  .campo-clave_baycodec input[type="password"], .campo-clave_baycodec input[type="text"] { padding-right: 40px; }
  .btn-ver-clave_baycodec {
    position: absolute;
    right: 6px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1rem;
    padding: 4px 6px;
    line-height: 1;
    color: #6b7280;
  }
  .btn-ver-clave_baycodec:hover { color: #1f2937; }
  .mapa-envio_baycodec { height: 220px; border-radius: 6px; margin-top: 8px; border: 1px solid #d1d5db; }
  .mapa-acciones_baycodec { display: flex; align-items: center; gap: 10px; margin-top: 6px; flex-wrap: wrap; }
  .btn-ubicacion_baycodec {
    background: #f3f4f6; color: #1f2937; border: 1px solid #d1d5db; border-radius: 6px;
    padding: 6px 12px; font-size: 0.82rem; cursor: pointer; font-family: inherit;
  }
  .btn-ubicacion_baycodec:hover { background: #e5e7eb; }
  .mapa-coordenadas_baycodec { font-size: 0.78rem; color: #6b7280; }
</style>
</head>
<body>

<form method="post" action="registro-cliente.php" class="caja-registro_baycodec">
  <h1>🧾 Crear cuenta — Grafiluz</h1>
  <p class="subtitulo_baycodec">Regístrate para generar y pagar tus pedidos.</p>

  <?php if ($errorRegistro_baycodec): ?>
    <p class="error_baycodec">⚠️ <?= v_registro_baycodec($errorRegistro_baycodec) ?></p>
  <?php endif; ?>

  <label for="nombre">Nombres / Razón social</label>
  <input type="text" id="nombre" name="nombre" placeholder="Ej: Juan / Minera Sur S.A.C."
         value="<?= v_registro_baycodec($datosFormulario_baycodec['nombre']) ?>" required>

  <label for="apellidos">Apellidos</label>
  <input type="text" id="apellidos" name="apellidos" placeholder="Ej: Pérez Gómez (déjalo vacío si es una empresa)"
         value="<?= v_registro_baycodec($datosFormulario_baycodec['apellidos']) ?>">

  <label for="dni">DNI</label>
  <input type="text" id="dni" name="dni" placeholder="Ej: 45678912" maxlength="15"
         value="<?= v_registro_baycodec($datosFormulario_baycodec['dni']) ?>" required>

  <label for="telefono">Teléfono</label>
  <input type="text" id="telefono" name="telefono" placeholder="Ej: 987654321" maxlength="20"
         value="<?= v_registro_baycodec($datosFormulario_baycodec['telefono']) ?>" required>

  <label for="direccion">Dirección de envío</label>
  <input type="text" id="direccion" name="direccion" placeholder="Ej: Calle Los Álamos 123, Cercado, Arequipa"
         value="<?= v_registro_baycodec($datosFormulario_baycodec['direccion']) ?>" required>
  <p class="ayuda_baycodec">Es donde llegará tu pedido si Grafiluz lo envía. Si quieres, marca el punto exacto en el mapa para mayor precisión.</p>

  <div id="mapa-envio_baycodec" class="mapa-envio_baycodec"></div>
  <div class="mapa-acciones_baycodec">
    <button type="button" class="btn-ubicacion_baycodec" onclick="regUsarUbicacionActual_baycodec(this)">📍 Usar mi ubicación actual</button>
    <span class="mapa-coordenadas_baycodec" id="mapa-coordenadas_baycodec">Sin ubicación marcada (opcional).</span>
  </div>
  <input type="hidden" id="latitud" name="latitud" value="<?= v_registro_baycodec($datosFormulario_baycodec['latitud']) ?>">
  <input type="hidden" id="longitud" name="longitud" value="<?= v_registro_baycodec($datosFormulario_baycodec['longitud']) ?>">

  <label for="usuario">Usuario (correo o nombre de usuario)</label>
  <input type="text" id="usuario" name="usuario" placeholder="tucorreo@ejemplo.com"
         value="<?= v_registro_baycodec($datosFormulario_baycodec['usuario']) ?>" required>
  <p class="ayuda_baycodec">⚠️ Nota del proyecto: por ahora tu cuenta queda activa de inmediato, sin confirmar que este
    correo sea real ni te pertenezca. En un sitio publicado esto se resuelve con verificación de email (enlace de
    confirmación antes de poder ingresar) — ver el comentario junto al INSERT de esta misma página
    (<code>registro-cliente.php</code>) para el detalle de por qué importa y cómo se implementaría.</p>

  <label for="clave">Contraseña</label>
  <div class="campo-clave_baycodec">
    <input type="password" id="clave" name="clave" minlength="4" required>
    <button type="button" class="btn-ver-clave_baycodec" onclick="regAlternarVerClave_baycodec('clave', this)" aria-label="Mostrar contraseña">👁</button>
  </div>

  <label for="clave_confirmacion">Confirmar contraseña</label>
  <div class="campo-clave_baycodec">
    <input type="password" id="clave_confirmacion" name="clave_confirmacion" minlength="4" required>
    <button type="button" class="btn-ver-clave_baycodec" onclick="regAlternarVerClave_baycodec('clave_confirmacion', this)" aria-label="Mostrar contraseña">👁</button>
  </div>
  <p class="ayuda_baycodec" id="clave-coincide_baycodec"></p>

  <label for="tipo_cliente">Tipo de cliente</label>
  <select id="tipo_cliente" name="tipo_cliente" onchange="regAlternarCampos_baycodec()">
    <option value="B2C" <?= $datosFormulario_baycodec['tipo_cliente'] === 'B2C' ? 'selected' : '' ?>>Persona individual (B2C)</option>
    <option value="B2B" <?= $datosFormulario_baycodec['tipo_cliente'] === 'B2B' ? 'selected' : '' ?>>Empresa — compra al por mayor (B2B)</option>
    <option value="C2C" <?= $datosFormulario_baycodec['tipo_cliente'] === 'C2C' ? 'selected' : '' ?>>Revendedor — compra para revender (C2C)</option>
  </select>

  <div id="campo-ruc_baycodec" style="display:none;">
    <label for="ruc">RUC de la empresa</label>
    <input type="text" id="ruc" name="ruc" placeholder="20123456789" value="<?= v_registro_baycodec($datosFormulario_baycodec['ruc']) ?>">
  </div>

  <div id="campo-reventa_baycodec" style="display:none;">
    <label for="plataforma_reventa">¿Dónde revendes? (opcional)</label>
    <input type="text" id="plataforma_reventa" name="plataforma_reventa" placeholder="Ej: Facebook Marketplace, feria de emprendedores"
           value="<?= v_registro_baycodec($datosFormulario_baycodec['plataforma_reventa']) ?>">
    <p class="ayuda_baycodec">Este registro es solo para marcar tu tipo de compra; el catálogo de Grafiluz sigue siendo el único que se vende aquí.</p>
  </div>

  <button class="btn_baycodec" type="submit">Crear cuenta</button>
  <p class="enlace-login_baycodec">¿Ya tienes cuenta? <a href="login-cliente.php">Ingresa aquí</a></p>
</form>

<script>
  function regAlternarCampos_baycodec() {
    const tipo = document.getElementById('tipo_cliente').value;
    document.getElementById('campo-ruc_baycodec').style.display = tipo === 'B2B' ? 'block' : 'none';
    document.getElementById('campo-reventa_baycodec').style.display = tipo === 'C2C' ? 'block' : 'none';
  }
  regAlternarCampos_baycodec();

  function regAlternarVerClave_baycodec(idCampo, boton) {
    const input = document.getElementById(idCampo);
    const mostrando = input.type === 'text';
    input.type = mostrando ? 'password' : 'text';
    boton.textContent = mostrando ? '👁' : '🙈';
    boton.setAttribute('aria-label', mostrando ? 'Mostrar contraseña' : 'Ocultar contraseña');
  }

  function regVerificarClavesCoinciden_baycodec() {
    const clave = document.getElementById('clave').value;
    const confirmacion = document.getElementById('clave_confirmacion').value;
    const aviso = document.getElementById('clave-coincide_baycodec');
    if (confirmacion === '') {
      aviso.textContent = '';
      return;
    }
    if (clave === confirmacion) {
      aviso.textContent = '✅ Las contraseñas coinciden.';
      aviso.style.color = '#16a34a';
    } else {
      aviso.textContent = '⚠️ Las contraseñas no coinciden.';
      aviso.style.color = '#dc2626';
    }
  }
  document.getElementById('clave').addEventListener('input', regVerificarClavesCoinciden_baycodec);
  document.getElementById('clave_confirmacion').addEventListener('input', regVerificarClavesCoinciden_baycodec);

  document.querySelector('.caja-registro_baycodec').addEventListener('submit', function (e) {
    if (document.getElementById('clave').value !== document.getElementById('clave_confirmacion').value) {
      e.preventDefault();
      alert('Las contraseñas no coinciden.');
    }
  });
</script>

<!-- Mapa de precisión de entrega: Leaflet + OpenStreetMap (gratis, sin API key) -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
  let regMapaLeaflet_baycodec;
  let regMarcadorLeaflet_baycodec;

  function regInicializarMapa_baycodec() {
    const CENTRO_AREQUIPA_BAYCODEC = [-16.3988, -71.5369]; // sede de Grafiluz (Cercado, Arequipa)
    const latGuardada = parseFloat(document.getElementById('latitud').value);
    const lngGuardada = parseFloat(document.getElementById('longitud').value);
    const hayCoordenadaGuardada = !isNaN(latGuardada) && !isNaN(lngGuardada);
    const centro = hayCoordenadaGuardada ? [latGuardada, lngGuardada] : CENTRO_AREQUIPA_BAYCODEC;

    regMapaLeaflet_baycodec = L.map('mapa-envio_baycodec').setView(centro, hayCoordenadaGuardada ? 16 : 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(regMapaLeaflet_baycodec);

    if (hayCoordenadaGuardada) {
      regColocarMarcador_baycodec(latGuardada, lngGuardada);
    }

    // Clic en el mapa = marcar (o mover) el punto exacto de entrega.
    regMapaLeaflet_baycodec.on('click', function (e) {
      regColocarMarcador_baycodec(e.latlng.lat, e.latlng.lng);
    });
  }

  function regColocarMarcador_baycodec(lat, lng) {
    if (regMarcadorLeaflet_baycodec) {
      regMarcadorLeaflet_baycodec.setLatLng([lat, lng]);
    } else {
      regMarcadorLeaflet_baycodec = L.marker([lat, lng], { draggable: true }).addTo(regMapaLeaflet_baycodec);
      regMarcadorLeaflet_baycodec.on('dragend', function () {
        const posicion = regMarcadorLeaflet_baycodec.getLatLng();
        regActualizarCoordenadas_baycodec(posicion.lat, posicion.lng);
      });
    }
    regActualizarCoordenadas_baycodec(lat, lng);
  }

  function regActualizarCoordenadas_baycodec(lat, lng) {
    document.getElementById('latitud').value = lat.toFixed(7);
    document.getElementById('longitud').value = lng.toFixed(7);
    document.getElementById('mapa-coordenadas_baycodec').textContent = `📍 ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  }

  function regUsarUbicacionActual_baycodec(boton) {
    if (!navigator.geolocation) {
      alert('Tu navegador no soporta geolocalización. Puedes marcar el punto directamente en el mapa.');
      return;
    }
    const textoOriginal = boton.textContent;
    boton.textContent = '⏳ Obteniendo ubicación...';
    boton.disabled = true;

    navigator.geolocation.getCurrentPosition(
      function (posicion) {
        const { latitude, longitude } = posicion.coords;
        regMapaLeaflet_baycodec.setView([latitude, longitude], 16);
        regColocarMarcador_baycodec(latitude, longitude);
        boton.textContent = textoOriginal;
        boton.disabled = false;
      },
      function () {
        alert('No se pudo obtener tu ubicación (revisa los permisos del navegador). Puedes marcarla manualmente haciendo clic en el mapa.');
        boton.textContent = textoOriginal;
        boton.disabled = false;
      }
    );
  }

  regInicializarMapa_baycodec();
</script>

</body>
</html>
