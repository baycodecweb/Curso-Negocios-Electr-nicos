var __marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Codigo del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// EL PLANO MAESTRO DE LA MEMORIA — Sesión 3: Negocios y Empresas
// Digitales (B2B, B2C, C2C)
// ------------------------------------------------------------
// Objetivo pedagógico: pasar de "datos sueltos en el navegador"
// (Sesión 2: productos-data.js) a un MODELO RELACIONAL explícito:
// tablas con claves primarias y foráneas, tal como se documentaría
// en un Diagrama Entidad-Relación (DER) antes de construir una
// base de datos real.
//
// No hay servidor ni base de datos real todavía (eso se conecta
// recién en la Sesión 7 con la pasarela de pago y el webhook). Aquí
// se simulan las 5 tablas del DER usando localStorage como
// almacenamiento persistente en el navegador, respetando las
// mismas relaciones que tendría una base de datos SQL real:
//
//   Cliente (1) ----< (N) Pedido (1) ----< (N) DetallePedido >---- (N) Producto
//                        Pedido (1) ----< (N) Pago
//
// Entidades y atributos (ver también Codigo/demo-modelo-datos.html
// para el diagrama visual):
//
//   Cliente        { id, nombre, tipo [B2B|B2C|C2C], empresa, ruc, plataformaReventa, email, telefono }
//   Producto       { id, categoria, nombre, ... }  (ya modelado en productos-data.js)
//   Pedido         { id, clienteId (FK->Cliente), fecha, estado [Pendiente|Pagado], total }
//   DetallePedido  { id, pedidoId (FK->Pedido), productoId (FK->Producto), cantidad, precioUnitario, subtotal }
//   Pago           { id, pedidoId (FK->Pedido), metodo, monto, estado [Pendiente|Pagado], fecha }
// ============================================================

const BD_CLAVE_baycodec = "grafiluz-s3-bd-relacional";

const BD_TABLAS_VACIAS_baycodec = {
  clientes: [],
  pedidos: [],
  detallePedido: [],
  pagos: [],
  _correlativos: { cliente: 0, pedido: 0, detalle: 0, pago: 0 },
};

function bdLeer_baycodec() {
  const guardado = localStorage.getItem(BD_CLAVE_baycodec);
  if (!guardado) return structuredClone(BD_TABLAS_VACIAS_baycodec);
  return JSON.parse(guardado);
}

function bdGuardar_baycodec(bd) {
  localStorage.setItem(BD_CLAVE_baycodec, JSON.stringify(bd));
}

function bdReiniciar_baycodec() {
  localStorage.removeItem(BD_CLAVE_baycodec);
}

/**
 * Inserta un nuevo cliente en la tabla "clientes".
 * @param {{nombre:string, tipo:"B2B"|"B2C"|"C2C", empresa?:string, ruc?:string, plataformaReventa?:string, email?:string, telefono?:string}} datos
 * @returns {Object} el registro de cliente creado (con id)
 */
function crearCliente_baycodec(datos) {
  const bd = bdLeer_baycodec();
  const id = ++bd._correlativos.cliente;
  const cliente = {
    id,
    nombre: datos.nombre,
    tipo: datos.tipo, // "B2B" (empresa que compra al por mayor), "B2C" (cliente individual) o "C2C" (revendedor a otros clientes)
    empresa: datos.tipo === "B2B" ? (datos.empresa || "") : "",
    ruc: datos.tipo === "B2B" ? (datos.ruc || "") : "",
    plataformaReventa: datos.tipo === "C2C" ? (datos.plataformaReventa || "") : "",
    email: datos.email || "",
    telefono: datos.telefono || "",
  };
  bd.clientes.push(cliente);
  bdGuardar_baycodec(bd);
  return cliente;
}

/**
 * Crea un pedido a partir de un carrito simple, generando también
 * sus filas de DetallePedido y un Pago en estado "Pendiente"
 * (el cobro real y el webhook se implementan en la Sesión 7).
 * @param {number} clienteId - FK hacia la tabla clientes
 * @param {{productoId:string, cantidad:number}[]} items
 * @param {Array} catalogoProductos - arreglo de productos-data.js
 * @returns {{pedido:Object, detalle:Object[], pago:Object}}
 */
function crearPedido_baycodec(clienteId, items, catalogoProductos) {
  const bd = bdLeer_baycodec();

  const detalle = items.map((item) => {
    const producto = catalogoProductos.find((p) => p.id === item.productoId);
    const precioUnitario = producto ? producto.precioReferencialPEN : 0;
    const subtotal = Number((precioUnitario * item.cantidad).toFixed(2));
    return {
      id: ++bd._correlativos.detalle,
      pedidoId: null, // se completa abajo una vez creado el pedido
      productoId: item.productoId,
      cantidad: item.cantidad,
      precioUnitario,
      subtotal,
    };
  });

  const total = Number(detalle.reduce((acc, d) => acc + d.subtotal, 0).toFixed(2));

  const pedido = {
    id: ++bd._correlativos.pedido,
    clienteId,
    fecha: new Date().toISOString(),
    estado: "Pendiente", // cambia a "Pagado" recién en la Sesión 7 (webhook de la pasarela)
    total,
  };

  detalle.forEach((d) => (d.pedidoId = pedido.id));

  const pago = {
    id: ++bd._correlativos.pago,
    pedidoId: pedido.id,
    metodo: null, // se define en la Sesión 7 (Stripe / PayPal / MercadoPago)
    monto: total,
    estado: "Pendiente",
    fecha: null,
  };

  bd.pedidos.push(pedido);
  bd.detallePedido.push(...detalle);
  bd.pagos.push(pago);
  bdGuardar_baycodec(bd);

  return { pedido, detalle, pago };
}

/** Devuelve las 5 tablas del modelo, ya relacionadas para lectura. */
function obtenerTablas_baycodec(catalogoProductos = []) {
  const bd = bdLeer_baycodec();
  return {
    clientes: bd.clientes,
    productos: catalogoProductos,
    pedidos: bd.pedidos,
    detallePedido: bd.detallePedido,
    pagos: bd.pagos,
  };
}

// ============================================================
// SESIÓN 7 — EL PANEL DE CONTROL INTELIGENTE (webhook de pago)
// ------------------------------------------------------------
// Esta función es, precisamente, lo que el comentario de la Sesión 3
// dejaba pendiente en Pago.metodo ("se define en la Sesión 7") y en
// Pedido.estado ("Pendiente / Pagado"): actualizar ambas filas
// cuando la pasarela de pago (Codigo/pasarela-pago.js) confirma el
// cobro. En un backend real esta función sería el handler del
// webhook HTTP que la pasarela llama; aquí se invoca directamente
// porque no hay servidor propio (ver Codigo/pasarela-pago.js).
// ============================================================

/**
 * Marca un pedido y su pago como completados, tal como lo haría el
 * webhook de una pasarela real al confirmar el cobro.
 * @param {number} pedidoId
 * @param {{metodo?:string, transaccionId?:string}} datosPago
 * @returns {{pedido:Object|undefined, pago:Object|undefined}}
 */
function marcarPedidoComoPagado_baycodec(pedidoId, datosPago = {}) {
  const bd = bdLeer_baycodec();
  const pedido = bd.pedidos.find((p) => p.id === pedidoId);
  const pago = bd.pagos.find((p) => p.pedidoId === pedidoId);

  if (pedido) pedido.estado = "Pagado";
  if (pago) {
    pago.estado = "Pagado";
    pago.metodo = datosPago.metodo || pago.metodo || "Tarjeta (sandbox)";
    pago.transaccionId = datosPago.transaccionId || null;
    pago.fecha = new Date().toISOString();
  }

  bdGuardar_baycodec(bd);
  return { pedido, pago };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { crearCliente_baycodec, crearPedido_baycodec, obtenerTablas_baycodec, marcarPedidoComoPagado_baycodec, bdReiniciar_baycodec };
}
