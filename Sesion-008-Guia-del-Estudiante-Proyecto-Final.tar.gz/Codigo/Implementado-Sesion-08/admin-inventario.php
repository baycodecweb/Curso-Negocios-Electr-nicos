<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// HISTORIAL DE INVENTARIO — mejora post-Sesión 8
// ------------------------------------------------------------
// Visor de movimientos_inventario (ver db-conexion.php): cada ajuste
// manual de stock (admin-productos.php/mis-productos.php), cada venta
// (pagar-pedido.php) y cada reembolso (admin-productos.php) queda
// registrado ahí — esta página es la única forma de VERLO, la tabla
// hasta ahora solo se escribía y nadie la consultaba.
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

$filtroCodigo_baycodec = trim($_GET['codigo'] ?? '');

const FILAS_POR_PAGINA_INV_BAYCODEC = 30;
$paginaInv_baycodec = max(1, (int) ($_GET['pagina'] ?? 1));

// PDO no permite mezclar marcadores posicionales (?) y nombrados
// (:algo) en la misma consulta — por eso el filtro también usa un
// marcador nombrado (:codigo), igual que :limite/:offset.
$whereFiltro_baycodec = $filtroCodigo_baycodec !== '' ? 'WHERE producto_codigo = :codigo' : '';

$consultaTotalInv_baycodec = $pdo_baycodec->prepare("SELECT COUNT(*) FROM movimientos_inventario_tb_baycodec {$whereFiltro_baycodec}");
if ($filtroCodigo_baycodec !== '') {
    $consultaTotalInv_baycodec->bindValue(':codigo', $filtroCodigo_baycodec);
}
$consultaTotalInv_baycodec->execute();
$totalInv_baycodec = (int) $consultaTotalInv_baycodec->fetchColumn();
$totalPaginasInv_baycodec = max(1, (int) ceil($totalInv_baycodec / FILAS_POR_PAGINA_INV_BAYCODEC));
$paginaInv_baycodec = min($paginaInv_baycodec, $totalPaginasInv_baycodec);

$consultaInv_baycodec = $pdo_baycodec->prepare(
    "SELECT * FROM movimientos_inventario_tb_baycodec {$whereFiltro_baycodec} ORDER BY id DESC LIMIT :limite OFFSET :offset"
);
if ($filtroCodigo_baycodec !== '') {
    $consultaInv_baycodec->bindValue(':codigo', $filtroCodigo_baycodec);
}
$consultaInv_baycodec->bindValue(':limite', FILAS_POR_PAGINA_INV_BAYCODEC, PDO::PARAM_INT);
$consultaInv_baycodec->bindValue(':offset', ($paginaInv_baycodec - 1) * FILAS_POR_PAGINA_INV_BAYCODEC, PDO::PARAM_INT);
$consultaInv_baycodec->execute();
$movimientos_baycodec = $consultaInv_baycodec->fetchAll();

function v_inv_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Historial de Inventario — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 900px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  input[type="text"] { padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; }
  th { background: #f3f4f6; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .tipo-entrada_baycodec { color: #166534; font-weight: 600; }
  .tipo-salida_baycodec { color: #991b1b; font-weight: 600; }
  .paginador_baycodec { display: flex; align-items: center; justify-content: center; gap: 12px; margin: 12px 0 4px; }
  .paginador-info_baycodec { font-size: 0.82rem; color: #6b7280; }
  .paginador-deshabilitado_baycodec { opacity: .4; pointer-events: none; }
</style>
</head>
<body>

<h1>📦 Historial de Inventario — Grafiluz</h1>
<p class="subtitulo_baycodec">Cada ajuste manual, venta y reembolso que tocó el stock de un producto o variante (<?= $totalInv_baycodec ?> en total).</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="admin-productos.php" style="background:#C41F25;">🛠️ Panel de Productos</a>
</div>

<div class="caja_baycodec">
  <form method="get" action="admin-inventario.php" style="display:flex; gap:8px; align-items:center;">
    <input type="text" name="codigo" placeholder="Filtrar por código de producto..." value="<?= v_inv_baycodec($filtroCodigo_baycodec) ?>">
    <button class="btn_baycodec" type="submit">Filtrar</button>
    <?php if ($filtroCodigo_baycodec !== ''): ?>
      <a class="btn_baycodec secundario_baycodec" href="admin-inventario.php">✖ Quitar filtro</a>
    <?php endif; ?>
  </form>
</div>

<table>
  <thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th>Cantidad</th><th>Motivo</th></tr></thead>
  <tbody>
    <?php if (empty($movimientos_baycodec)): ?>
      <tr><td colspan="5" class="vacio_baycodec">(sin movimientos todavía)</td></tr>
    <?php else: foreach ($movimientos_baycodec as $m_baycodec): ?>
      <tr>
        <td><?= v_inv_baycodec(date('d/m/Y H:i', strtotime($m_baycodec['creado_en']))) ?></td>
        <td><code><?= v_inv_baycodec($m_baycodec['producto_codigo']) ?></code></td>
        <td class="<?= $m_baycodec['tipo'] === 'entrada' ? 'tipo-entrada_baycodec' : 'tipo-salida_baycodec' ?>">
          <?= $m_baycodec['tipo'] === 'entrada' ? '⬆ Entrada' : '⬇ Salida' ?>
        </td>
        <td><?= (int) $m_baycodec['cantidad'] ?></td>
        <td><?= v_inv_baycodec($m_baycodec['motivo']) ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>

<?php if ($totalPaginasInv_baycodec > 1): ?>
  <div class="paginador_baycodec">
    <?php
      $paramsPagina_baycodec = function ($pagina) use ($filtroCodigo_baycodec) {
          return '?' . http_build_query(array_filter(['codigo' => $filtroCodigo_baycodec, 'pagina' => $pagina]));
      };
    ?>
    <?php if ($paginaInv_baycodec > 1): ?>
      <a class="btn_baycodec secundario_baycodec" href="<?= v_inv_baycodec($paramsPagina_baycodec($paginaInv_baycodec - 1)) ?>">‹ Anterior</a>
    <?php else: ?>
      <span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">‹ Anterior</span>
    <?php endif; ?>
    <span class="paginador-info_baycodec">Página <?= $paginaInv_baycodec ?> de <?= $totalPaginasInv_baycodec ?></span>
    <?php if ($paginaInv_baycodec < $totalPaginasInv_baycodec): ?>
      <a class="btn_baycodec secundario_baycodec" href="<?= v_inv_baycodec($paramsPagina_baycodec($paginaInv_baycodec + 1)) ?>">Siguiente ›</a>
    <?php else: ?>
      <span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">Siguiente ›</span>
    <?php endif; ?>
  </div>
<?php endif; ?>

</body>
</html>
