<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// CONEXIÓN A LA BASE DE DATOS REAL — Sesión 8: publicación
// ------------------------------------------------------------
// Hasta ahora (Sesiones 3 a 7) el "modelo relacional" de Grafiluz
// vivía simulado en localStorage (ver db-modelo.js), porque el
// sitio era 100% estático (HTML/JS servido con un simple
// `python3 -m http.server`, sin backend).
//
// admin-productos.php necesita guardar productos de verdad, para
// varios administradores, en un solo lugar — por eso aquí sí se
// conecta a una base de datos MySQL/MariaDB real (creada con
// phpMyAdmin), y por eso este archivo requiere PHP (no puede
// abrirse con doble clic ni con un servidor solo-estático).
//
// Nota ética/seguridad (tema de esta misma sesión): en un proyecto
// real estas credenciales NUNCA se suben a un repositorio ni se
// dejan en texto plano — se guardan en variables de entorno o en
// un archivo ignorado por git. Aquí están así, visibles, solo
// porque esto es un entorno de práctica local del curso.
// ============================================================

$DB_HOST_BAYCODEC = "localhost";
$DB_NOMBRE_BAYCODEC = "grafiluz_db";
$DB_USUARIO_BAYCODEC = "root";
$DB_CLAVE_BAYCODEC = "ZRJiul+jR+rPUC5RGDeso3v1";

try {
    $pdo_baycodec = new PDO(
        "mysql:host={$DB_HOST_BAYCODEC};dbname={$DB_NOMBRE_BAYCODEC};charset=utf8mb4",
        $DB_USUARIO_BAYCODEC,
        $DB_CLAVE_BAYCODEC,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $error) {
    die(
        "No se pudo conectar a la base de datos '{$DB_NOMBRE_BAYCODEC}'. " .
        "Verifica que MySQL/MariaDB esté encendido y que la base de datos exista " .
        "(créala en phpMyAdmin o con: CREATE DATABASE grafiluz_db;).<br>" .
        "Detalle técnico: " . htmlspecialchars($error->getMessage())
    );
}

// ============================================================
// MARKETPLACE MULTI-VENDEDOR — Sesión 8 (ampliación)
// ------------------------------------------------------------
// Hasta ahora todo "productos_tb_baycodec" era del catálogo oficial de Grafiluz.
// Para que un cliente C2C (revendedor) pueda publicar y vender SUS
// propios productos, cada fila necesita saber de quién es:
// vendedor_id = NULL  -> catálogo oficial de Grafiluz (como hasta hoy)
// vendedor_id = N      -> producto publicado por el cliente con id N
//                         (ver mis-productos.php)
// Se agrega aquí (no en auth-cliente.php) porque "productos_tb_baycodec" ya
// existía desde antes de Sesión 8 (creada a mano en phpMyAdmin) — es
// el único lugar que TODO archivo que use la tabla productos_tb_baycodec carga
// siempre. No lleva FOREIGN KEY formal (por simplicidad de la
// migración idempotente); la relación con clientes_tb_baycodec.id se respeta en
// el código de mis-productos.php y admin-productos.php.
// ============================================================
$pdo_baycodec->exec('ALTER TABLE productos_tb_baycodec ADD COLUMN IF NOT EXISTS vendedor_id INT DEFAULT NULL AFTER activo');

// ============================================================
// STOCK / INVENTARIO (mejora post-Sesión 8)
// ------------------------------------------------------------
// Hasta ahora "activo" (visible/oculto) era el único control de
// disponibilidad: se podía vender infinitas unidades de un producto
// agotado. "stock" es la cantidad disponible ahora mismo (se resta
// sola al pagar un pedido, ver pagar-pedido.php); "movimientos_
// inventario" es el historial de CADA cambio de stock (reposición
// manual del admin/vendedor, o venta), para poder responder "¿quién
// repuso esto y cuándo?" sin depender de la memoria de nadie.
// stock = NULL significa "sin control de stock" (se sigue vendiendo
// siempre, como hasta ahora) — así los productos ya existentes no
// quedan agotados de la nada el día que se agrega esta columna.
// ============================================================
$pdo_baycodec->exec('ALTER TABLE productos_tb_baycodec ADD COLUMN IF NOT EXISTS stock INT DEFAULT NULL AFTER precio_referencial_pen');

$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS movimientos_inventario_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        producto_codigo VARCHAR(60) NOT NULL,
        tipo ENUM("entrada","salida") NOT NULL,
        cantidad INT NOT NULL,
        motivo VARCHAR(180) NOT NULL DEFAULT "",
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// ============================================================
// CATEGORÍAS (mejora post-Sesión 8)
// ------------------------------------------------------------
// "categoria" en productos sigue siendo texto libre (VARCHAR) — no se
// convierte a FOREIGN KEY aquí porque tienda.php agrupa TODO el
// catálogo por ese texto (ver $SECCIONES_CATALOGO_BAYCODEC) y
// convertirlo habría significado reescribir esa lógica entera para
// una mejora que no la necesita. En cambio, esta tabla sirve como
// "vocabulario controlado": admin-productos.php y mis-productos.php
// ahora eligen la categoría de un <select> alimentado por esta tabla
// en vez de escribirla a mano — así ya no se puede crear una
// categoría "fantasma" por un typo (ej. "Llaverros"), y a futuro cada
// categoría puede tener su propia imagen/descripción/slug para SEO.
// Sembrada con las mismas 6 categorías que ya usaba mis-productos.php
// (antes hardcodeadas ahí en un arreglo PHP repetido).
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS categorias_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(80) NOT NULL UNIQUE,
        slug VARCHAR(80) NOT NULL DEFAULT "",
        descripcion VARCHAR(255) NOT NULL DEFAULT "",
        imagen_url VARCHAR(500) NOT NULL DEFAULT "",
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);
foreach ([
    'Artículos Antiestrés',
    'Artículos de Escritorio',
    'Tomatodos y Tazas',
    'Llaveros',
    'Bolsas Publicitarias',
    'ARTICULOS Papeleria',
] as $categoriaSemilla_baycodec) {
    $pdo_baycodec
        ->prepare('INSERT IGNORE INTO categorias_tb_baycodec (nombre, slug) VALUES (?, ?)')
        ->execute([$categoriaSemilla_baycodec, strtolower(preg_replace('/[^a-z0-9]+/i', '-', $categoriaSemilla_baycodec))]);
}

// ============================================================
// AUDITORÍA DEL PANEL DE ADMIN (mejora post-Sesión 8)
// ------------------------------------------------------------
// El admin ya puede borrar productos y cancelar/reembolsar pedidos
// (admin-productos.php) sin dejar ningún rastro de quién lo hizo ni
// cuándo. Esta tabla registra cada acción destructiva/sensible del
// panel — no reemplaza un login por admin individual (sigue habiendo
// un solo usuario "baycodec" por ahora, ver auth-admin.php), pero deja
// la fecha y el detalle de qué pasó, para poder revisar el historial
// si algo se borró o canceló por error.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS auditoria_admin_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        admin_usuario VARCHAR(60) NOT NULL,
        accion VARCHAR(60) NOT NULL,
        referencia_id INT DEFAULT NULL,
        detalle VARCHAR(255) NOT NULL DEFAULT "",
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

/** Registra una acción del admin en auditoria_admin. Nunca lanza error
 *  hacia afuera si algo falla al auditar — la auditoría no debe poder
 *  tumbar la acción real que está registrando. */
function registrarAuditoriaAdmin_baycodec($pdo, $accion, $referenciaId, $detalle = '') {
    try {
        $pdo->prepare('INSERT INTO auditoria_admin_tb_baycodec (admin_usuario, accion, referencia_id, detalle) VALUES (?, ?, ?, ?)')
            ->execute([$_SESSION['admin_usuario_baycodec'] ?? 'desconocido', $accion, $referenciaId, $detalle]);
    } catch (Throwable $error) {
        // No se propaga: perder el registro de auditoría no debe
        // impedir que la acción real (borrar/cancelar/reembolsar) se
        // complete.
    }
}

// ============================================================
// ANALÍTICA EN SERVIDOR (mejora post-Sesión 8)
// ------------------------------------------------------------
// Hasta ahora motor-analitica.js guardaba cada evento (clic a
// WhatsApp, búsqueda, pregunta al chatbot, etc.) en el localStorage
// del propio navegador — el Panel de Control (panel-control.html)
// solo mostraba lo que veía QUIEN LO ABRÍA, nunca datos reales
// agregados de todos los visitantes del sitio. Esta tabla + el
// endpoint registrar-evento.php reciben esos mismos eventos y los
// guardan de verdad en el servidor. cliente_id es NULL para
// visitantes sin sesión iniciada (la mayoría de los eventos: navegar
// el catálogo no requiere cuenta).
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS eventos_analitica_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tipo_evento VARCHAR(60) NOT NULL,
        datos_json VARCHAR(1000) NOT NULL DEFAULT "{}",
        pagina VARCHAR(80) NOT NULL DEFAULT "",
        cliente_id INT DEFAULT NULL,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// ============================================================
// CONFIGURACIÓN DEL SITIO (mejora post-Sesión 8)
// ------------------------------------------------------------
// Valores que antes estaban escritos a mano en varios archivos PHP/JS
// (el número de WhatsApp, la tasa de IGV, la moneda base, el
// porcentaje de comisión del marketplace) — ahora viven en una tabla
// clave/valor editable desde admin-configuracion.php, en vez de tener
// que tocar código para cambiarlos. Sembrada con los mismos valores
// que ya estaban hardcodeados, para que nada cambie el primer día.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS configuracion_tb_baycodec (
        clave VARCHAR(60) PRIMARY KEY,
        valor VARCHAR(255) NOT NULL DEFAULT ""
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);
foreach ([
    'whatsapp_numero' => '51930910829',
    'igv_porcentaje' => '18',
    'moneda_base' => 'PEN',
    'comision_marketplace_porcentaje' => '10',
] as $claveConfig_baycodec => $valorConfig_baycodec) {
    $pdo_baycodec->prepare('INSERT IGNORE INTO configuracion_tb_baycodec (clave, valor) VALUES (?, ?)')
        ->execute([$claveConfig_baycodec, $valorConfig_baycodec]);
}

/** Lee un valor de configuracion; $porDefecto si la clave no existe todavía. */
function obtenerConfiguracion_baycodec($pdo, $clave, $porDefecto = '') {
    $consulta = $pdo->prepare('SELECT valor FROM configuracion_tb_baycodec WHERE clave = ?');
    $consulta->execute([$clave]);
    $valor = $consulta->fetchColumn();
    return $valor !== false ? $valor : $porDefecto;
}

// ============================================================
// TARIFAS DE ENVÍO POR ZONA (mejora post-Sesión 8)
// ------------------------------------------------------------
// Hasta ahora el total del pedido era solo la suma de productos menos
// el cupón — nunca se cobraba el envío. El cliente elige su zona al
// pagar (ver carrito.php); crear-pedido.php vuelve a buscar el costo
// aquí por el nombre de la zona, nunca confía en un costo de envío
// que mande el navegador.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS tarifas_envio_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        zona VARCHAR(120) NOT NULL UNIQUE,
        costo DECIMAL(10,2) NOT NULL DEFAULT 0,
        dias_estimados VARCHAR(60) NOT NULL DEFAULT "",
        activo TINYINT(1) NOT NULL DEFAULT 1,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);
foreach ([
    ['Recojo en tienda (Cercado, Arequipa)', 0, 'El mismo día'],
    ['Arequipa Metropolitana', 8, '1-2 días'],
    ['Arequipa Provincia', 15, '2-4 días'],
    ['Lima', 18, '3-5 días'],
    ['Otras regiones del Perú', 25, '4-7 días'],
] as [$zonaSemilla_baycodec, $costoSemilla_baycodec, $diasSemilla_baycodec]) {
    $pdo_baycodec->prepare('INSERT IGNORE INTO tarifas_envio_tb_baycodec (zona, costo, dias_estimados) VALUES (?, ?, ?)')
        ->execute([$zonaSemilla_baycodec, $costoSemilla_baycodec, $diasSemilla_baycodec]);
}

// ============================================================
// VARIANTES DE PRODUCTO (mejora post-Sesión 8)
// ------------------------------------------------------------
// Hasta ahora "colores" en productos era solo texto para mostrar
// puntitos de color en la tarjeta (tienda.php) — sin stock ni precio
// propio por color/talla. Un producto puede tener CERO variantes
// (sigue funcionando exactamente igual que antes, con el stock a
// nivel de producto) o varias, cada una con su propio stock y un
// precio_extra opcional (ej. "Talla XL" +S/2.00). Sin FOREIGN KEY a
// productos.codigo, siguiendo la misma convención que detalle_pedido
// y resenas (identificador de texto, no relación formal).
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS producto_variantes_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        producto_codigo VARCHAR(60) NOT NULL,
        nombre_variante VARCHAR(120) NOT NULL,
        precio_extra DECIMAL(10,2) NOT NULL DEFAULT 0,
        stock INT NOT NULL DEFAULT 0,
        activo TINYINT(1) NOT NULL DEFAULT 1,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// ============================================================
// RECUPERACIÓN DE CONTRASEÑA (mejora post-Sesión 8)
// ------------------------------------------------------------
// Sirve tanto para clientes (tipo="cliente", usuario_id -> clientes.id)
// como para el panel de admin (tipo="admin", usuario_id ->
// usuarios_admin.id) — de ahí que no lleve FOREIGN KEY (apuntaría a
// una tabla distinta según el tipo). El token vence en 1 hora y se
// marca "usado" apenas se usa una vez, para que no sirva dos veces.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS tokens_recuperacion_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tipo ENUM("admin","cliente") NOT NULL,
        usuario_id INT NOT NULL,
        token VARCHAR(64) NOT NULL UNIQUE,
        expira_en TIMESTAMP NOT NULL,
        usado TINYINT(1) NOT NULL DEFAULT 0,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);
