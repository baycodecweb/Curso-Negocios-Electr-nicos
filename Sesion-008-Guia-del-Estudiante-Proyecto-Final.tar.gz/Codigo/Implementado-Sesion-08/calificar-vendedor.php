<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// CALIFICAR AL VENDEDOR (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// Distinto de guardar-resena.php (que califica el PRODUCTO): esto
// califica al VENDEDOR C2C como tal — su trato, si envió a tiempo,
// etc., igual que en un marketplace real (MercadoLibre, por ejemplo).
// Solo se puede calificar a un vendedor si de verdad se le compró y
// pagó algo — se vuelve a comprobar aquí, nunca se confía en el
// vendedor_id que mande el navegador sin verificarlo.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

$cliente_baycodec = clienteActual_baycodec();
if (!$cliente_baycodec) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión para calificar a un vendedor.']);
    exit;
}

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$vendedorId_baycodec = (int) ($cuerpo_baycodec['vendedor_id'] ?? 0);
$calificacion_baycodec = (int) ($cuerpo_baycodec['calificacion'] ?? 0);
$comentario_baycodec = mb_substr(trim($cuerpo_baycodec['comentario'] ?? ''), 0, 500);

if ($vendedorId_baycodec <= 0 || $calificacion_baycodec < 1 || $calificacion_baycodec > 5) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'mensaje' => 'Elige una calificación de 1 a 5 estrellas.']);
    exit;
}

$verificarCompra_baycodec = $pdo_baycodec->prepare(
    'SELECT COUNT(*) FROM detalle_pedido_tb_baycodec dp
     JOIN pedidos_tb_baycodec p ON p.id = dp.pedido_id
     WHERE p.cliente_id = ? AND p.estado = "Pagado" AND dp.vendedor_id = ?'
);
$verificarCompra_baycodec->execute([$cliente_baycodec['id'], $vendedorId_baycodec]);

if ((int) $verificarCompra_baycodec->fetchColumn() === 0) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'mensaje' => 'Solo puedes calificar a un vendedor si le compraste y pagaste algo.']);
    exit;
}

$guardar_baycodec = $pdo_baycodec->prepare(
    'INSERT INTO calificaciones_vendedor_tb_baycodec (vendedor_id, cliente_id, calificacion, comentario)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE calificacion = VALUES(calificacion), comentario = VALUES(comentario)'
);
$guardar_baycodec->execute([$vendedorId_baycodec, $cliente_baycodec['id'], $calificacion_baycodec, $comentario_baycodec]);

echo json_encode(['ok' => true]);
