<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// PANEL DE ADMINISTRACIÓN DE PRODUCTOS — Sesión 8: publicación
// ------------------------------------------------------------
// Objetivo pedagógico: reemplazar la edición manual de
// productos-data.js (Sesión 2) por un panel real que lee y
// escribe en la base de datos MySQL "grafiluz_db" (tabla
// "productos", creada con phpMyAdmin). Requiere PHP corriendo
// (Apache/XAMPP/etc.), no un simple servidor estático.
//
// Herramienta interna: no está enlazada desde el menú del
// cliente (tienda.html), igual que panel-control.html y
// admin-chatbot.html.
//
// Requiere haber iniciado sesión (ver login.php / auth-admin.php):
// ya no cualquiera con la URL puede agregar/editar/borrar productos.
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

$errorFormulario_baycodec = '';
$idEditando_baycodec = isset($_GET['editar']) ? (int) $_GET['editar'] : null;

function limpiarTexto_baycodec($valor) {
    return trim($valor ?? '');
}

// ------------------------------------------------------------
// Procesa el formulario (agregar o guardar edición) por POST
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar') {
    $codigo = limpiarTexto_baycodec($_POST['codigo'] ?? '');
    // Categorías (mejora post-Sesión 8): el admin elige de la tabla
    // "categorias", pero puede crear una nueva escribiéndola en el
    // campo aparte — así el catálogo oficial sigue pudiendo crecer sin
    // volver a caer en el texto libre sin control de antes.
    $categoriaNueva_baycodec = limpiarTexto_baycodec($_POST['categoria_nueva'] ?? '');
    $categoria = $categoriaNueva_baycodec !== '' ? $categoriaNueva_baycodec : limpiarTexto_baycodec($_POST['categoria_existente'] ?? '');
    if ($categoriaNueva_baycodec !== '') {
        $pdo_baycodec->prepare('INSERT IGNORE INTO categorias_tb_baycodec (nombre, slug) VALUES (?, ?)')
            ->execute([$categoriaNueva_baycodec, strtolower(preg_replace('/[^a-z0-9]+/i', '-', $categoriaNueva_baycodec))]);
    }
    $nombre = limpiarTexto_baycodec($_POST['nombre'] ?? '');
    $medidas = limpiarTexto_baycodec($_POST['medidas'] ?? '');
    $material = limpiarTexto_baycodec($_POST['material'] ?? '');
    $colores = limpiarTexto_baycodec($_POST['colores'] ?? '');
    $imagenUrl = limpiarTexto_baycodec($_POST['imagen_url'] ?? '');
    $precio = str_replace(',', '.', limpiarTexto_baycodec($_POST['precio'] ?? ''));
    $activo = isset($_POST['activo']) ? 1 : 0;
    $idFormulario = (int) ($_POST['id'] ?? 0);
    // Marketplace multi-vendedor: vacío/0 = catálogo oficial de Grafiluz
    // (vendedor_id NULL). El admin es el único que puede reasignar el
    // dueño de cualquier producto, incluidos los de otros vendedores.
    $vendedorIdFormulario_baycodec = (int) ($_POST['vendedor_id'] ?? 0);
    $vendedorId_baycodec = $vendedorIdFormulario_baycodec > 0 ? $vendedorIdFormulario_baycodec : null;
    // Stock (mejora post-Sesión 8): vacío = "sin control de stock" (se
    // sigue vendiendo siempre, como hasta ahora); un número = cantidad
    // disponible real, que pagar-pedido.php descuenta sola al pagar.
    $stockFormulario_baycodec = trim($_POST['stock'] ?? '');
    $stock_baycodec = $stockFormulario_baycodec === '' ? null : (int) $stockFormulario_baycodec;

    if ($codigo === '' || $categoria === '' || $nombre === '') {
        $errorFormulario_baycodec = 'Código, categoría y nombre son obligatorios.';
    } elseif (!is_numeric($precio) || (float) $precio < 0) {
        $errorFormulario_baycodec = 'El precio referencial debe ser un número mayor o igual a 0.';
    } elseif ($stockFormulario_baycodec !== '' && (!is_numeric($stockFormulario_baycodec) || $stock_baycodec < 0)) {
        $errorFormulario_baycodec = 'El stock debe ser un número mayor o igual a 0, o quedar vacío si no controlas stock de este producto.';
    } elseif ($imagenUrl !== '' && !filter_var($imagenUrl, FILTER_VALIDATE_URL)) {
        $errorFormulario_baycodec = 'La URL de la imagen no es válida (debe empezar con http:// o https://).';
    } else {
        if ($idFormulario > 0) {
            // Se compara contra el stock ANTERIOR para registrar el
            // ajuste en movimientos_inventario — sin esto, cambiar el
            // stock a mano no dejaría ningún rastro de quién lo hizo.
            $stockAnterior_baycodec = $pdo_baycodec->prepare('SELECT stock, codigo FROM productos_tb_baycodec WHERE id = ?');
            $stockAnterior_baycodec->execute([$idFormulario]);
            $filaAnterior_baycodec = $stockAnterior_baycodec->fetch();

            $consulta = $pdo_baycodec->prepare(
                'UPDATE productos_tb_baycodec SET codigo = ?, categoria = ?, nombre = ?, medidas = ?, material = ?,
                 colores = ?, imagen_url = ?, precio_referencial_pen = ?, stock = ?, activo = ?, vendedor_id = ? WHERE id = ?'
            );
            $consulta->execute([$codigo, $categoria, $nombre, $medidas, $material, $colores, $imagenUrl, $precio, $stock_baycodec, $activo, $vendedorId_baycodec, $idFormulario]);

            if ($filaAnterior_baycodec && $stock_baycodec !== null && (int) $filaAnterior_baycodec['stock'] !== $stock_baycodec) {
                $diferencia_baycodec = $stock_baycodec - (int) $filaAnterior_baycodec['stock'];
                $pdo_baycodec->prepare('INSERT INTO movimientos_inventario_tb_baycodec (producto_codigo, tipo, cantidad, motivo) VALUES (?, ?, ?, ?)')
                    ->execute([$codigo, $diferencia_baycodec >= 0 ? 'entrada' : 'salida', abs($diferencia_baycodec), 'Ajuste manual desde el panel de admin']);
            }
            registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'editar_producto', $idFormulario, $codigo);
        } else {
            $consulta = $pdo_baycodec->prepare(
                'INSERT INTO productos_tb_baycodec (codigo, categoria, nombre, medidas, material, colores, imagen_url, precio_referencial_pen, stock, activo, vendedor_id)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $consulta->execute([$codigo, $categoria, $nombre, $medidas, $material, $colores, $imagenUrl, $precio, $stock_baycodec, $activo, $vendedorId_baycodec]);

            if ($stock_baycodec !== null && $stock_baycodec > 0) {
                $pdo_baycodec->prepare('INSERT INTO movimientos_inventario_tb_baycodec (producto_codigo, tipo, cantidad, motivo) VALUES (?, "entrada", ?, "Stock inicial al crear el producto")')
                    ->execute([$codigo, $stock_baycodec]);
            }
            registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'crear_producto', (int) $pdo_baycodec->lastInsertId(), $codigo);
        }
        header('Location: admin-productos.php?guardado=1');
        exit;
    }
}

// ------------------------------------------------------------
// Elimina un producto (por GET con confirmación en el navegador)
// ------------------------------------------------------------
if (isset($_GET['eliminar'])) {
    $idEliminar_baycodec = (int) $_GET['eliminar'];
    $consultaCodigoEliminar_baycodec = $pdo_baycodec->prepare('SELECT codigo FROM productos_tb_baycodec WHERE id = ?');
    $consultaCodigoEliminar_baycodec->execute([$idEliminar_baycodec]);
    $codigoEliminado_baycodec = (string) $consultaCodigoEliminar_baycodec->fetchColumn();

    $consulta = $pdo_baycodec->prepare('DELETE FROM productos_tb_baycodec WHERE id = ?');
    $consulta->execute([$idEliminar_baycodec]);
    registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'eliminar_producto', $idEliminar_baycodec, $codigoEliminado_baycodec);
    header('Location: admin-productos.php?eliminado=1');
    exit;
}

// ------------------------------------------------------------
// Cancelar / reembolsar un pedido (mejora post-Sesión 8)
// ------------------------------------------------------------
// Cancelar solo tiene sentido si el pedido TODAVÍA no se pagó (nada
// que devolver); si ya está Pagado, lo correcto es reembolsarlo, para
// no perder el rastro de que sí hubo un cobro real. Cada acción
// vuelve a comprobar el estado actual en la base de datos antes de
// tocar nada — no basta con que el botón exista en la página.
if (isset($_GET['cancelar_pedido'])) {
    $idPedidoAccion_baycodec = (int) $_GET['cancelar_pedido'];
    $filaPedidoAccion_baycodec = $pdo_baycodec->prepare('SELECT estado, cliente_id FROM pedidos_tb_baycodec WHERE id = ?');
    $filaPedidoAccion_baycodec->execute([$idPedidoAccion_baycodec]);
    $pedidoAccion_baycodec = $filaPedidoAccion_baycodec->fetch();
    if ($pedidoAccion_baycodec && $pedidoAccion_baycodec['estado'] === 'Pendiente') {
        $pdo_baycodec->prepare('UPDATE pedidos_tb_baycodec SET estado = "Cancelado" WHERE id = ?')->execute([$idPedidoAccion_baycodec]);
        $pdo_baycodec->prepare('UPDATE pagos_tb_baycodec SET estado = "Cancelado" WHERE pedido_id = ?')->execute([$idPedidoAccion_baycodec]);
        registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'cancelar_pedido', $idPedidoAccion_baycodec);
        registrarNotificacion_baycodec(
            $pdo_baycodec,
            (int) $pedidoAccion_baycodec['cliente_id'],
            'pedido_cancelado',
            "Tu Pedido #{$idPedidoAccion_baycodec} fue cancelado — Grafiluz",
            "El administrador canceló tu Pedido #{$idPedidoAccion_baycodec}. Si tienes dudas, escríbenos por WhatsApp."
        );
    }
    header('Location: admin-productos.php?pedido_actualizado=1');
    exit;
}

if (isset($_GET['reembolsar_pedido'])) {
    $idPedidoAccion_baycodec = (int) $_GET['reembolsar_pedido'];
    $filaPedidoAccion_baycodec = $pdo_baycodec->prepare('SELECT estado, cliente_id FROM pedidos_tb_baycodec WHERE id = ?');
    $filaPedidoAccion_baycodec->execute([$idPedidoAccion_baycodec]);
    $pedidoAccion_baycodec = $filaPedidoAccion_baycodec->fetch();
    if ($pedidoAccion_baycodec && $pedidoAccion_baycodec['estado'] === 'Pagado') {
        $pdo_baycodec->prepare('UPDATE pedidos_tb_baycodec SET estado = "Reembolsado" WHERE id = ?')->execute([$idPedidoAccion_baycodec]);
        $pdo_baycodec->prepare('UPDATE pagos_tb_baycodec SET estado = "Reembolsado" WHERE pedido_id = ?')->execute([$idPedidoAccion_baycodec]);

        // El stock que se descontó al pagar (ver pagar-pedido.php) se
        // devuelve al reembolsar — si no, esas unidades quedarían
        // "perdidas" del inventario para siempre.
        $itemsReembolso_baycodec = $pdo_baycodec->prepare('SELECT producto_codigo, cantidad, variante_id, variante_nombre FROM detalle_pedido_tb_baycodec WHERE pedido_id = ?');
        $itemsReembolso_baycodec->execute([$idPedidoAccion_baycodec]);
        $devolverStock_baycodec = $pdo_baycodec->prepare('UPDATE productos_tb_baycodec SET stock = stock + ? WHERE codigo = ? AND stock IS NOT NULL');
        $devolverStockVariante_baycodec = $pdo_baycodec->prepare('UPDATE producto_variantes_tb_baycodec SET stock = stock + ? WHERE id = ?');
        $registrarEntradaReembolso_baycodec = $pdo_baycodec->prepare('INSERT INTO movimientos_inventario_tb_baycodec (producto_codigo, tipo, cantidad, motivo) VALUES (?, "entrada", ?, ?)');
        foreach ($itemsReembolso_baycodec->fetchAll() as $itemReembolso_baycodec) {
            if ($itemReembolso_baycodec['variante_id']) {
                $devolverStockVariante_baycodec->execute([$itemReembolso_baycodec['cantidad'], $itemReembolso_baycodec['variante_id']]);
                $registrarEntradaReembolso_baycodec->execute([
                    $itemReembolso_baycodec['producto_codigo'],
                    $itemReembolso_baycodec['cantidad'],
                    "Reembolso variante \"{$itemReembolso_baycodec['variante_nombre']}\" — Pedido #{$idPedidoAccion_baycodec}",
                ]);
                continue;
            }
            $devolverStock_baycodec->execute([$itemReembolso_baycodec['cantidad'], $itemReembolso_baycodec['producto_codigo']]);
            if ($devolverStock_baycodec->rowCount() > 0) {
                $registrarEntradaReembolso_baycodec->execute([$itemReembolso_baycodec['producto_codigo'], $itemReembolso_baycodec['cantidad'], "Reembolso — Pedido #{$idPedidoAccion_baycodec}"]);
            }
        }

        // Comisión (mejora post-Sesión 8): si la venta se devolvió, no
        // hay comisión que cobrar sobre ella — se borra la fila que
        // pagar-pedido.php generó al confirmarse el pago.
        $pdo_baycodec->prepare('DELETE FROM comisiones_tb_baycodec WHERE pedido_id = ?')->execute([$idPedidoAccion_baycodec]);

        registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'reembolsar_pedido', $idPedidoAccion_baycodec);
        registrarNotificacion_baycodec(
            $pdo_baycodec,
            (int) $pedidoAccion_baycodec['cliente_id'],
            'pedido_reembolsado',
            "Tu Pedido #{$idPedidoAccion_baycodec} fue reembolsado — Grafiluz",
            "El administrador marcó tu Pedido #{$idPedidoAccion_baycodec} como reembolsado."
        );
    }
    header('Location: admin-productos.php?pedido_actualizado=1');
    exit;
}

// ------------------------------------------------------------
// Variantes de producto (mejora post-Sesión 8): cada producto puede
// tener cero o varias — el formulario de "agregar variante" vive
// dentro de la vista de edición (?editar=ID), ver más abajo.
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'agregar_variante') {
    $productoCodigoVariante_baycodec = trim($_POST['producto_codigo_variante'] ?? '');
    $nombreVariante_baycodec = trim($_POST['nombre_variante'] ?? '');
    $precioExtraVariante_baycodec = str_replace(',', '.', trim($_POST['precio_extra'] ?? '0'));
    $stockVariante_baycodec = (int) ($_POST['stock_variante'] ?? 0);
    $idProductoVariante_baycodec = (int) ($_POST['id_producto_variante'] ?? 0);

    if ($productoCodigoVariante_baycodec !== '' && $nombreVariante_baycodec !== '' && is_numeric($precioExtraVariante_baycodec)) {
        $pdo_baycodec->prepare('INSERT INTO producto_variantes_tb_baycodec (producto_codigo, nombre_variante, precio_extra, stock) VALUES (?, ?, ?, ?)')
            ->execute([$productoCodigoVariante_baycodec, $nombreVariante_baycodec, $precioExtraVariante_baycodec, max(0, $stockVariante_baycodec)]);
    }
    header('Location: admin-productos.php?editar=' . $idProductoVariante_baycodec);
    exit;
}

if (isset($_GET['eliminar_variante'])) {
    $idProductoVolver_baycodec = (int) ($_GET['producto_id'] ?? 0);
    $pdo_baycodec->prepare('DELETE FROM producto_variantes_tb_baycodec WHERE id = ?')->execute([(int) $_GET['eliminar_variante']]);
    header('Location: admin-productos.php?editar=' . $idProductoVolver_baycodec);
    exit;
}

// ------------------------------------------------------------
// Datos para precargar el formulario si se está editando
// ------------------------------------------------------------
$productoEditando_baycodec = null;
$variantesProductoEditando_baycodec = [];
if ($idEditando_baycodec) {
    $consulta = $pdo_baycodec->prepare('SELECT * FROM productos_tb_baycodec WHERE id = ?');
    $consulta->execute([$idEditando_baycodec]);
    $productoEditando_baycodec = $consulta->fetch();

    if ($productoEditando_baycodec) {
        $consultaVariantes_baycodec = $pdo_baycodec->prepare('SELECT * FROM producto_variantes_tb_baycodec WHERE producto_codigo = ? ORDER BY nombre_variante');
        $consultaVariantes_baycodec->execute([$productoEditando_baycodec['codigo']]);
        $variantesProductoEditando_baycodec = $consultaVariantes_baycodec->fetchAll();
    }
}

// ------------------------------------------------------------
// Paginación (mejora post-Sesión 8): con cientos de productos,
// clientes o pedidos, mostrar TODA la tabla de un jalón vuelve la
// página pesada de cargar y de leer. Cada una de las 3 tablas de
// abajo pagina por separado (su propio parámetro en la URL), así que
// navegar una no reinicia las otras dos.
// ------------------------------------------------------------
const FILAS_POR_PAGINA_BAYCODEC = 15;

function paginaActualDesdeUrl_baycodec($parametro) {
    $pagina = isset($_GET[$parametro]) ? (int) $_GET[$parametro] : 1;
    return max(1, $pagina);
}

/**
 * Arma el HTML de "‹ Anterior · Página N de M · Siguiente ›" para una
 * tabla, preservando la página de las OTRAS dos tablas en el enlace
 * (para eso se pasa $paginasActuales_baycodec completo, no solo la de
 * esta tabla) — así paginar productos no resetea clientes/pedidos.
 */
function renderizarPaginador_baycodec($paginaActual, $totalPaginas, $parametro, $paginasActuales) {
    if ($totalPaginas <= 1) {
        return '';
    }
    $construirEnlace = function ($pagina) use ($parametro, $paginasActuales) {
        $parametros = $paginasActuales;
        $parametros[$parametro] = $pagina;
        return '?' . http_build_query($parametros);
    };
    $html = '<div class="paginador_baycodec">';
    $html .= $paginaActual > 1
        ? '<a class="btn_baycodec secundario_baycodec" href="' . htmlspecialchars($construirEnlace($paginaActual - 1), ENT_QUOTES, 'UTF-8') . '">‹ Anterior</a>'
        : '<span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">‹ Anterior</span>';
    $html .= '<span class="paginador-info_baycodec">Página ' . $paginaActual . ' de ' . $totalPaginas . '</span>';
    $html .= $paginaActual < $totalPaginas
        ? '<a class="btn_baycodec secundario_baycodec" href="' . htmlspecialchars($construirEnlace($paginaActual + 1), ENT_QUOTES, 'UTF-8') . '">Siguiente ›</a>'
        : '<span class="btn_baycodec secundario_baycodec paginador-deshabilitado_baycodec">Siguiente ›</span>';
    $html .= '</div>';
    return $html;
}

$paginaProductos_baycodec = paginaActualDesdeUrl_baycodec('pag_productos');
$paginaClientes_baycodec = paginaActualDesdeUrl_baycodec('pag_clientes');
$paginaPedidos_baycodec = paginaActualDesdeUrl_baycodec('pag_pedidos');

$totalProductos_baycodec = (int) $pdo_baycodec->query('SELECT COUNT(*) FROM productos_tb_baycodec')->fetchColumn();
$totalPaginasProductos_baycodec = max(1, (int) ceil($totalProductos_baycodec / FILAS_POR_PAGINA_BAYCODEC));
$paginaProductos_baycodec = min($paginaProductos_baycodec, $totalPaginasProductos_baycodec);

$consultaProductos_baycodec = $pdo_baycodec->prepare(
    'SELECT p.*, c.nombre AS vendedor_nombre
     FROM productos_tb_baycodec p
     LEFT JOIN clientes_tb_baycodec c ON c.id = p.vendedor_id
     ORDER BY p.categoria, p.nombre
     LIMIT :limite OFFSET :offset'
);
$consultaProductos_baycodec->bindValue(':limite', FILAS_POR_PAGINA_BAYCODEC, PDO::PARAM_INT);
$consultaProductos_baycodec->bindValue(':offset', ($paginaProductos_baycodec - 1) * FILAS_POR_PAGINA_BAYCODEC, PDO::PARAM_INT);
$consultaProductos_baycodec->execute();
$productos_baycodec = $consultaProductos_baycodec->fetchAll();

// Vendedores disponibles para el desplegable del formulario: solo
// cuentas C2C (revendedor) — B2C/B2B compran, no publican productos.
$vendedoresDisponibles_baycodec = $pdo_baycodec->query(
    "SELECT id, nombre FROM clientes_tb_baycodec WHERE tipo_cliente = 'C2C' ORDER BY nombre"
)->fetchAll();

// Categorías disponibles para el desplegable (mejora post-Sesión 8):
// mismo vocabulario controlado que usa mis-productos.php.
$categoriasDisponibles_baycodec = $pdo_baycodec->query('SELECT nombre FROM categorias_tb_baycodec ORDER BY nombre')->fetchAll(PDO::FETCH_COLUMN);

// ------------------------------------------------------------
// Clientes registrados + pedidos con detalle — el admin (baycodec)
// es el único que ve TODO esto; cada cliente solo ve lo suyo desde
// mis-pedidos.php (compras) y mis-productos.php (ventas, si es C2C).
// ------------------------------------------------------------
$totalClientes_baycodec = (int) $pdo_baycodec->query('SELECT COUNT(*) FROM clientes_tb_baycodec')->fetchColumn();
$totalPaginasClientes_baycodec = max(1, (int) ceil($totalClientes_baycodec / FILAS_POR_PAGINA_BAYCODEC));
$paginaClientes_baycodec = min($paginaClientes_baycodec, $totalPaginasClientes_baycodec);

$consultaClientes_baycodec = $pdo_baycodec->prepare(
    "SELECT c.*,
            (SELECT COUNT(*) FROM pedidos_tb_baycodec p WHERE p.cliente_id = c.id) AS total_pedidos,
            (SELECT COALESCE(SUM(p.total), 0) FROM pedidos_tb_baycodec p WHERE p.cliente_id = c.id AND p.estado = 'Pagado') AS total_comprado,
            (SELECT COUNT(*) FROM productos_tb_baycodec pr WHERE pr.vendedor_id = c.id) AS total_productos_publicados
     FROM clientes_tb_baycodec c
     ORDER BY c.creado_en DESC
     LIMIT :limite OFFSET :offset"
);
$consultaClientes_baycodec->bindValue(':limite', FILAS_POR_PAGINA_BAYCODEC, PDO::PARAM_INT);
$consultaClientes_baycodec->bindValue(':offset', ($paginaClientes_baycodec - 1) * FILAS_POR_PAGINA_BAYCODEC, PDO::PARAM_INT);
$consultaClientes_baycodec->execute();
$clientesRegistrados_baycodec = $consultaClientes_baycodec->fetchAll();

$totalPedidos_baycodec = (int) $pdo_baycodec->query('SELECT COUNT(*) FROM pedidos_tb_baycodec')->fetchColumn();
$totalPaginasPedidos_baycodec = max(1, (int) ceil($totalPedidos_baycodec / FILAS_POR_PAGINA_BAYCODEC));
$paginaPedidos_baycodec = min($paginaPedidos_baycodec, $totalPaginasPedidos_baycodec);

$consultaPedidos_baycodec = $pdo_baycodec->prepare(
    "SELECT p.id, p.total, p.estado, p.creado_en,
            c.nombre AS cliente_nombre, c.usuario AS cliente_usuario,
            pg.estado AS pago_estado, pg.transaccion_id
     FROM pedidos_tb_baycodec p
     JOIN clientes_tb_baycodec c ON c.id = p.cliente_id
     LEFT JOIN pagos_tb_baycodec pg ON pg.pedido_id = p.id
     ORDER BY p.id DESC
     LIMIT :limite OFFSET :offset"
);
$consultaPedidos_baycodec->bindValue(':limite', FILAS_POR_PAGINA_BAYCODEC, PDO::PARAM_INT);
$consultaPedidos_baycodec->bindValue(':offset', ($paginaPedidos_baycodec - 1) * FILAS_POR_PAGINA_BAYCODEC, PDO::PARAM_INT);
$consultaPedidos_baycodec->execute();
$pedidosConCliente_baycodec = $consultaPedidos_baycodec->fetchAll();

$paginasActuales_baycodec = [
    'pag_productos' => $paginaProductos_baycodec,
    'pag_clientes'  => $paginaClientes_baycodec,
    'pag_pedidos'   => $paginaPedidos_baycodec,
];

$consultaDetallePedido_baycodec = $pdo_baycodec->prepare(
    'SELECT producto_nombre, cantidad, precio_unitario, variante_nombre FROM detalle_pedido_tb_baycodec WHERE pedido_id = ?'
);

function v_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

// Cancelado/Reembolsado necesitan su propio color: si no, se ven
// igual que "Pendiente" (ámbar) y el admin no distingue de un vistazo
// qué pasó con el pedido.
function estiloEstadoPedido_baycodec($estado) {
    return [
        'Pagado'      => 'color:#166534;font-weight:600;',
        'Cancelado'   => 'color:#6b7280;font-weight:600;text-decoration:line-through;',
        'Reembolsado' => 'color:#7c3aed;font-weight:600;',
    ][$estado] ?? 'color:#92400e;font-weight:600;';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel de Productos — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 1000px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  h2 { font-size: 1.1rem; margin-top: 34px; padding-top: 10px; border-top: 1px solid #e5e7eb; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .nota_baycodec { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; }
  .btn_baycodec:hover { background: #1e40af; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .btn_baycodec.secundario_baycodec:hover { background: #d1d5db; }
  .btn_baycodec.peligro_baycodec { background: #fee2e2; color: #991b1b; }
  .btn_baycodec.peligro_baycodec:hover { background: #fecaca; }
  a.btn_baycodec { text-decoration: none; display: inline-block; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"], input[type="number"], select { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; }
  .ayuda_baycodec { font-size: 0.78rem; color: #6b7280; margin-top: 3px; }
  .campos-en-fila_baycodec { display: grid; grid-template-columns: 1fr 1fr; gap: 0 16px; }
  table { width: 100%; border-collapse: collapse; margin: 10px 0; font-size: 0.85rem; background: white; }
  th, td { border: 1px solid #e5e7eb; padding: 8px 10px; text-align: left; vertical-align: top; }
  th { background: #f3f4f6; }
  .fila-acciones_baycodec { display: flex; gap: 6px; }
  .fila-acciones_baycodec .btn_baycodec { font-size: 0.75rem; padding: 4px 8px; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.85rem; }
  .etiqueta-inactivo_baycodec { display: inline-block; background: #f3f4f6; color: #6b7280; border-radius: 10px; padding: 1px 8px; font-size: 0.72rem; }
  .checkbox-linea_baycodec { display: flex; align-items: center; gap: 8px; margin-top: 14px; }
  .checkbox-linea_baycodec input { width: auto; }
  .paginador_baycodec { display: flex; align-items: center; justify-content: center; gap: 12px; margin: 12px 0 4px; }
  .paginador_baycodec .btn_baycodec { font-size: 0.8rem; }
  .paginador-info_baycodec { font-size: 0.82rem; color: #6b7280; }
  .paginador-deshabilitado_baycodec { opacity: .4; pointer-events: none; }
</style>
</head>
<body>

<h1>🛠️ Panel de Productos — Grafiluz</h1>
<p class="subtitulo_baycodec">
  Agrega, edita o elimina productos directamente en la base de datos <code>grafiluz_db</code> (MySQL/MariaDB,
  tabla <code>productos</code>). Herramienta interna: no está enlazada desde el menú del cliente.
</p>

<div class="caja_baycodec" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px;">
  <div>
    <a class="btn_baycodec" href="tienda.php" style="background:#C41F25;">🌐 Ir al sitio</a>
    <a class="btn_baycodec secundario_baycodec" href="panel-control.html" style="margin-left:8px;">📊 Panel de Control</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-chatbot.html" style="margin-left:8px;">🤖 Panel del Asistente</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-cupones.php" style="margin-left:8px;">🏷️ Cupones</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-auditoria.php" style="margin-left:8px;">📜 Auditoría</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-configuracion.php" style="margin-left:8px;">⚙️ Configuración</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-envios.php" style="margin-left:8px;">🚚 Envíos</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-comisiones.php" style="margin-left:8px;">💸 Comisiones</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-notificaciones.php" style="margin-left:8px;">📨 Notificaciones</a>
    <a class="btn_baycodec secundario_baycodec" href="admin-inventario.php" style="margin-left:8px;">📦 Inventario</a>
  </div>
  <div style="font-size:0.85rem; color:#6b7280;">
    Sesión: <strong><?= v_baycodec($_SESSION['admin_usuario_baycodec']) ?></strong>
    · <a href="logout.php">Cerrar sesión</a>
  </div>
</div>

<?php if (isset($_GET['guardado'])): ?>
  <p class="exito_baycodec">✅ Producto guardado correctamente.</p>
<?php endif; ?>
<?php if (isset($_GET['eliminado'])): ?>
  <p class="exito_baycodec">🗑️ Producto eliminado.</p>
<?php endif; ?>
<?php if (isset($_GET['pedido_actualizado'])): ?>
  <p class="exito_baycodec">✅ Estado del pedido actualizado.</p>
<?php endif; ?>
<?php if ($errorFormulario_baycodec): ?>
  <p class="error_baycodec">⚠️ <?= v_baycodec($errorFormulario_baycodec) ?></p>
<?php endif; ?>

<div class="nota_baycodec">
  <strong>Cómo funciona:</strong> esta tabla es la fuente real de productos una vez publicado el sitio con
  backend PHP. El catálogo estático de <code>tienda.html</code> (Sesión 1-2) y <code>productos-data.js</code>
  siguen funcionando igual mientras no se conecten a esta base de datos — conectar el catálogo público a
  <code>grafiluz_db</code> es un paso posterior (agregar un endpoint PHP que devuelva estos productos en JSON).
</div>

<h2><?= $productoEditando_baycodec ? '✏️ Editar producto' : '➕ Agregar producto' ?></h2>
<div class="caja_baycodec">
  <form method="post" action="admin-productos.php">
    <input type="hidden" name="accion" value="guardar">
    <input type="hidden" name="id" value="<?= v_baycodec($productoEditando_baycodec['id'] ?? '') ?>">

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="codigo">Código (único, sin espacios)</label>
        <input type="text" id="codigo" name="codigo" placeholder="Ej: llavero-02"
               value="<?= v_baycodec($productoEditando_baycodec['codigo'] ?? '') ?>" required>
      </div>
      <div>
        <label for="categoria_existente">Categoría</label>
        <select id="categoria_existente" name="categoria_existente">
          <?php foreach ($categoriasDisponibles_baycodec as $categoriaOpcion_baycodec): ?>
            <option value="<?= v_baycodec($categoriaOpcion_baycodec) ?>"
              <?= ($productoEditando_baycodec['categoria'] ?? '') === $categoriaOpcion_baycodec ? 'selected' : '' ?>>
              <?= v_baycodec($categoriaOpcion_baycodec) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <input type="text" id="categoria_nueva" name="categoria_nueva" placeholder="...o escribe una categoría nueva" style="margin-top:6px;">
        <p class="ayuda_baycodec">Si escribes una categoría nueva, se usa esa en vez de la elegida arriba.</p>
      </div>
    </div>

    <label for="nombre">Nombre del producto</label>
    <input type="text" id="nombre" name="nombre" placeholder="Ej: Llavero de Cuero Grabado"
           value="<?= v_baycodec($productoEditando_baycodec['nombre'] ?? '') ?>" required>

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="medidas">Medidas</label>
        <input type="text" id="medidas" name="medidas" placeholder="Ej: 6 x 4 cm"
               value="<?= v_baycodec($productoEditando_baycodec['medidas'] ?? '') ?>">
      </div>
      <div>
        <label for="material">Material</label>
        <input type="text" id="material" name="material" placeholder="Ej: Cuero sintético"
               value="<?= v_baycodec($productoEditando_baycodec['material'] ?? '') ?>">
      </div>
    </div>

    <label for="colores">Colores disponibles</label>
    <input type="text" id="colores" name="colores" placeholder="Ej: marrón,negro,camel"
           value="<?= v_baycodec($productoEditando_baycodec['colores'] ?? '') ?>">
    <p class="ayuda_baycodec">Sepáralos con comas, igual que en productos-data.js.</p>

    <label for="imagen_url">URL(s) de la imagen del producto</label>
    <input type="text" id="imagen_url" name="imagen_url" placeholder="https://... , https://... , https://..."
           value="<?= v_baycodec($productoEditando_baycodec['imagen_url'] ?? '') ?>"
           oninput="document.getElementById('vista-previa-imagen_baycodec').src = this.value.split(',')[0].trim();">
    <p class="ayuda_baycodec">Pega una URL, o varias separadas por comas (igual que en colores) para que la tarjeta muestre un carrusel con las fotos de este producto.</p>
    <img id="vista-previa-imagen_baycodec" alt="Vista previa (primera imagen)"
         src="<?= v_baycodec(trim(explode(',', $productoEditando_baycodec['imagen_url'] ?? '')[0])) ?>"
         style="max-width:160px;max-height:160px;margin-top:8px;border-radius:6px;border:1px solid #e5e7eb;<?= empty($productoEditando_baycodec['imagen_url']) ? 'display:none;' : '' ?>"
         onerror="this.style.display='none';" onload="this.style.display='block';">

    <div class="campos-en-fila_baycodec">
      <div>
        <label for="precio">Precio referencial (S/)</label>
        <input type="number" id="precio" name="precio" step="0.01" min="0" placeholder="Ej: 9.90"
               value="<?= v_baycodec($productoEditando_baycodec['precio_referencial_pen'] ?? '') ?>" required>
      </div>
      <div>
        <label for="stock">Stock disponible</label>
        <input type="number" id="stock" name="stock" step="1" min="0" placeholder="Vacío = sin control de stock"
               value="<?= v_baycodec($productoEditando_baycodec['stock'] ?? '') ?>">
      </div>
    </div>
    <p class="ayuda_baycodec">Déjalo vacío si no quieres controlar stock de este producto (se sigue vendiendo siempre, como hasta ahora). Se descuenta solo al confirmarse el pago.</p>

    <label for="vendedor_id">Vendedor (marketplace)</label>
    <select id="vendedor_id" name="vendedor_id">
      <option value="0">Grafiluz (catálogo oficial)</option>
      <?php foreach ($vendedoresDisponibles_baycodec as $vendedor_baycodec): ?>
        <option value="<?= (int) $vendedor_baycodec['id'] ?>"
          <?= (int) ($productoEditando_baycodec['vendedor_id'] ?? 0) === (int) $vendedor_baycodec['id'] ? 'selected' : '' ?>>
          <?= v_baycodec($vendedor_baycodec['nombre']) ?> (C2C)
        </option>
      <?php endforeach; ?>
    </select>
    <p class="ayuda_baycodec">Los productos de un revendedor (C2C) también los puede administrar él mismo desde <a href="mis-productos.php">mis-productos.php</a>.</p>

    <div class="checkbox-linea_baycodec">
      <input type="checkbox" id="activo" name="activo"
             <?= (!$productoEditando_baycodec || $productoEditando_baycodec['activo']) ? 'checked' : '' ?>>
      <label for="activo" style="margin:0;">Producto activo (visible en el catálogo)</label>
    </div>

    <div style="margin-top:14px;">
      <button class="btn_baycodec" type="submit">💾 <?= $productoEditando_baycodec ? 'Guardar cambios' : 'Agregar producto' ?></button>
      <?php if ($productoEditando_baycodec): ?>
        <a class="btn_baycodec secundario_baycodec" href="admin-productos.php">✖ Cancelar edición</a>
      <?php endif; ?>
    </div>
  </form>
</div>

<?php if ($productoEditando_baycodec): ?>
<h2>🎨 Variantes de "<?= v_baycodec($productoEditando_baycodec['nombre']) ?>"</h2>
<div class="caja_baycodec">
  <p class="ayuda_baycodec">Opcional: si este producto viene en tallas/colores con stock o precio distinto (ej. "Talla XL" +S/2.00),
    agrégalos aquí. Sin variantes, el producto sigue funcionando exactamente igual que antes (con el stock de arriba).</p>

  <?php if (!empty($variantesProductoEditando_baycodec)): ?>
    <table>
      <thead><tr><th>Variante</th><th>Precio extra</th><th>Stock</th><th style="width:80px">Acciones</th></tr></thead>
      <tbody>
        <?php foreach ($variantesProductoEditando_baycodec as $variante_baycodec): ?>
          <tr>
            <td><?= v_baycodec($variante_baycodec['nombre_variante']) ?></td>
            <td><?= (float) $variante_baycodec['precio_extra'] > 0 ? '+ S/ ' . number_format((float) $variante_baycodec['precio_extra'], 2) : '—' ?></td>
            <td><?= (int) $variante_baycodec['stock'] ?></td>
            <td>
              <a class="btn_baycodec peligro_baycodec" style="font-size:0.75rem; padding:4px 8px;"
                 href="admin-productos.php?eliminar_variante=<?= (int) $variante_baycodec['id'] ?>&producto_id=<?= (int) $productoEditando_baycodec['id'] ?>"
                 onclick="return confirm('¿Eliminar esta variante?');">🗑️</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p class="vacio_baycodec">Este producto todavía no tiene variantes.</p>
  <?php endif; ?>

  <form method="post" action="admin-productos.php" style="margin-top:10px;">
    <input type="hidden" name="accion" value="agregar_variante">
    <input type="hidden" name="producto_codigo_variante" value="<?= v_baycodec($productoEditando_baycodec['codigo']) ?>">
    <input type="hidden" name="id_producto_variante" value="<?= (int) $productoEditando_baycodec['id'] ?>">
    <div class="campos-en-fila_baycodec">
      <div>
        <label for="nombre_variante">Nombre de la variante</label>
        <input type="text" id="nombre_variante" name="nombre_variante" placeholder="Ej: Talla M - Azul" required>
      </div>
      <div>
        <label for="precio_extra">Precio extra (S/, puede ser 0)</label>
        <input type="number" id="precio_extra" name="precio_extra" step="0.01" min="0" value="0" required>
      </div>
    </div>
    <label for="stock_variante">Stock de esta variante</label>
    <input type="number" id="stock_variante" name="stock_variante" step="1" min="0" value="0" required>
    <button class="btn_baycodec" type="submit" style="margin-top:10px;">➕ Agregar variante</button>
  </form>
</div>
<?php endif; ?>

<h2>Productos en la base de datos (<?= $totalProductos_baycodec ?>)</h2>
<table>
  <thead>
    <tr>
      <th style="width:64px">Imagen</th><th>Código</th><th>Categoría</th><th>Nombre</th><th>Precio (S/)</th><th>Stock</th><th>Vendedor</th><th>Estado</th><th style="width:140px">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php if (empty($productos_baycodec)): ?>
      <tr><td colspan="9" class="vacio_baycodec">(todavía no hay productos en la base de datos)</td></tr>
    <?php else: foreach ($productos_baycodec as $p): ?>
      <tr>
        <td>
          <?php if (!empty($p['imagen_url'])): ?>
            <img src="<?= v_baycodec(trim(explode(',', $p['imagen_url'])[0])) ?>" alt="<?= v_baycodec($p['nombre']) ?>"
                 style="width:44px;height:44px;object-fit:cover;border-radius:5px;border:1px solid #e5e7eb;"
                 onerror="this.replaceWith(document.createTextNode('—'));">
          <?php else: ?>
            <span class="vacio_baycodec">—</span>
          <?php endif; ?>
        </td>
        <td><?= v_baycodec($p['codigo']) ?></td>
        <td><?= v_baycodec($p['categoria']) ?></td>
        <td><?= v_baycodec($p['nombre']) ?></td>
        <td>S/ <?= number_format((float) $p['precio_referencial_pen'], 2) ?></td>
        <td>
          <?php if ($p['stock'] === null): ?>
            <span class="vacio_baycodec">Sin control</span>
          <?php elseif ((int) $p['stock'] <= 0): ?>
            <span class="etiqueta-inactivo_baycodec">Agotado</span>
          <?php else: ?>
            <?= (int) $p['stock'] ?>
          <?php endif; ?>
        </td>
        <td><?= $p['vendedor_id'] ? v_baycodec($p['vendedor_nombre']) . ' (C2C)' : 'Grafiluz' ?></td>
        <td><?= $p['activo'] ? 'Activo' : '<span class="etiqueta-inactivo_baycodec">Inactivo</span>' ?></td>
        <td class="fila-acciones_baycodec">
          <a class="btn_baycodec secundario_baycodec" href="admin-productos.php?editar=<?= (int) $p['id'] ?>">✏️ Editar</a>
          <a class="btn_baycodec secundario_baycodec" href="admin-inventario.php?codigo=<?= urlencode($p['codigo']) ?>" title="Ver historial de stock">📦</a>
          <a class="btn_baycodec peligro_baycodec" href="admin-productos.php?eliminar=<?= (int) $p['id'] ?>"
             onclick="return confirm('¿Eliminar el producto &quot;<?= v_baycodec($p['nombre']) ?>&quot;? Esta acción no se puede deshacer.');">🗑️</a>
        </td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>
<?= renderizarPaginador_baycodec($paginaProductos_baycodec, $totalPaginasProductos_baycodec, 'pag_productos', $paginasActuales_baycodec) ?>

<h2>Clientes registrados (<?= $totalClientes_baycodec ?>)</h2>
<div class="nota_baycodec">
  Solo el admin ve esta lista completa. Cada cliente, desde su propia cuenta, únicamente ve
  <strong>sus</strong> compras (<code>mis-pedidos.php</code>) y, si es C2C, <strong>sus</strong> productos publicados
  (<code>mis-productos.php</code>) — nunca los de otro cliente.
</div>
<table>
  <thead>
    <tr>
      <th>Nombre</th><th>Usuario</th><th>Tipo</th><th>Teléfono</th><th>Pedidos</th><th>Total comprado (pagado)</th><th>Productos publicados</th>
    </tr>
  </thead>
  <tbody>
    <?php if (empty($clientesRegistrados_baycodec)): ?>
      <tr><td colspan="7" class="vacio_baycodec">(todavía no hay clientes registrados)</td></tr>
    <?php else: foreach ($clientesRegistrados_baycodec as $cl): ?>
      <tr>
        <td><?= v_baycodec($cl['nombre']) ?> <?= v_baycodec($cl['apellidos']) ?></td>
        <td><?= v_baycodec($cl['usuario']) ?></td>
        <td><?= v_baycodec($cl['tipo_cliente']) ?></td>
        <td><?= v_baycodec($cl['telefono']) ?></td>
        <td><?= (int) $cl['total_pedidos'] ?></td>
        <td>S/ <?= number_format((float) $cl['total_comprado'], 2) ?></td>
        <td><?= $cl['tipo_cliente'] === 'C2C' ? (int) $cl['total_productos_publicados'] : '—' ?></td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>
<?= renderizarPaginador_baycodec($paginaClientes_baycodec, $totalPaginasClientes_baycodec, 'pag_clientes', $paginasActuales_baycodec) ?>

<h2>Pedidos — qué compró cada cliente (<?= $totalPedidos_baycodec ?>)</h2>
<div class="nota_baycodec">
  <strong>Cancelar</strong> solo está disponible mientras el pedido sigue <strong>Pendiente</strong> (nada que devolver).
  <strong>Reembolsar</strong> solo aparece si ya está <strong>Pagado</strong> — marca que el dinero se devolvió, sin borrar
  el historial de que la venta ocurrió.
</div>
<table>
  <thead>
    <tr>
      <th>Pedido</th><th>Cliente</th><th>Qué compró</th><th>Total</th><th>Estado pedido</th><th>Estado pago</th><th style="width:130px">Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php if (empty($pedidosConCliente_baycodec)): ?>
      <tr><td colspan="7" class="vacio_baycodec">(todavía no hay pedidos)</td></tr>
    <?php else: foreach ($pedidosConCliente_baycodec as $pedido_baycodec): ?>
      <?php
        $consultaDetallePedido_baycodec->execute([$pedido_baycodec['id']]);
        $itemsPedido_baycodec = $consultaDetallePedido_baycodec->fetchAll();
        $resumenItems_baycodec = implode(', ', array_map(
            fn($item) => (int) $item['cantidad'] . ' x ' . $item['producto_nombre'] . ($item['variante_nombre'] ? " ({$item['variante_nombre']})" : ''),
            $itemsPedido_baycodec
        ));
      ?>
      <tr>
        <td>#<?= (int) $pedido_baycodec['id'] ?></td>
        <td><?= v_baycodec($pedido_baycodec['cliente_nombre']) ?><br><span class="vacio_baycodec"><?= v_baycodec($pedido_baycodec['cliente_usuario']) ?></span></td>
        <td><?= v_baycodec($resumenItems_baycodec) ?></td>
        <td>S/ <?= number_format((float) $pedido_baycodec['total'], 2) ?></td>
        <td><span style="<?= estiloEstadoPedido_baycodec($pedido_baycodec['estado']) ?>"><?= v_baycodec($pedido_baycodec['estado']) ?></span></td>
        <td><?= v_baycodec($pedido_baycodec['pago_estado'] ?? '—') ?></td>
        <td class="fila-acciones_baycodec">
          <?php if ($pedido_baycodec['estado'] === 'Pendiente'): ?>
            <a class="btn_baycodec peligro_baycodec" href="admin-productos.php?cancelar_pedido=<?= (int) $pedido_baycodec['id'] ?>"
               onclick="return confirm('¿Cancelar el pedido #<?= (int) $pedido_baycodec['id'] ?>? El cliente ya no podrá pagarlo.');">✖ Cancelar</a>
          <?php elseif ($pedido_baycodec['estado'] === 'Pagado'): ?>
            <a class="btn_baycodec peligro_baycodec" href="admin-productos.php?reembolsar_pedido=<?= (int) $pedido_baycodec['id'] ?>"
               onclick="return confirm('¿Reembolsar el pedido #<?= (int) $pedido_baycodec['id'] ?>? Esto lo marca como devuelto.');">↩ Reembolsar</a>
          <?php else: ?>
            <span class="vacio_baycodec">—</span>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; endif; ?>
  </tbody>
</table>
<?= renderizarPaginador_baycodec($paginaPedidos_baycodec, $totalPaginasPedidos_baycodec, 'pag_pedidos', $paginasActuales_baycodec) ?>

</body>
</html>
