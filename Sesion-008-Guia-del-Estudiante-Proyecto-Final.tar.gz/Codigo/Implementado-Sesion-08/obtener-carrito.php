<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// OBTENER CARRITO GUARDADO EN SERVIDOR (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// Se llama desde carrito.php cuando el localStorage de ESTE navegador
// está vacío pero el cliente tiene sesión iniciada — típicamente
// porque agregó productos desde otro dispositivo/navegador. Devuelve
// el carrito en el mismo formato que usa localStorage
// ({ [producto_codigo]: { nombre, precio, cantidad } }), tomando
// nombre/precio ACTUALES de productos (no los que tenía guardados
// cuando se agregó, por si cambiaron) — mismo criterio de "nunca
// confiar en un precio viejo" que ya usa crear-pedido.php.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

$cliente_baycodec = clienteActual_baycodec();
if (!$cliente_baycodec) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'items' => []]);
    exit;
}

$consulta_baycodec = $pdo_baycodec->prepare(
    'SELECT ci.producto_codigo, ci.cantidad, p.nombre, p.precio_referencial_pen
     FROM carritos_tb_baycodec c
     JOIN carrito_items_tb_baycodec ci ON ci.carrito_id = c.id
     JOIN productos_tb_baycodec p ON p.codigo = ci.producto_codigo AND p.activo = 1
     WHERE c.cliente_id = ?'
);
$consulta_baycodec->execute([$cliente_baycodec['id']]);

$items_baycodec = [];
foreach ($consulta_baycodec->fetchAll() as $fila_baycodec) {
    $items_baycodec[$fila_baycodec['producto_codigo']] = [
        'nombre' => $fila_baycodec['nombre'],
        'precio' => (float) $fila_baycodec['precio_referencial_pen'],
        'cantidad' => (int) $fila_baycodec['cantidad'],
    ];
}

echo json_encode(['ok' => true, 'items' => $items_baycodec]);
