<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// AUTENTICACIÓN DEL PANEL DE ADMINISTRACIÓN — Sesión 8: ética y ciberseguridad
// ------------------------------------------------------------
// Hasta ahora admin-productos.php no pedía usuario ni contraseña:
// cualquiera que conociera la URL podía agregar, editar o borrar
// productos. Esta misma sesión trata sobre publicar el sitio de
// forma ética y segura, así que el panel ahora exige iniciar sesión
// (ver login.php).
//
// La contraseña NUNCA se guarda en texto plano: se guarda su hash
// (password_hash, bcrypt) en la tabla "usuarios_admin" y se compara
// con password_verify() al iniciar sesión — la misma buena práctica
// que se explica en el Informe de Ética y Ciberseguridad de esta
// sesión.
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db-conexion.php';

// Crea la tabla si todavía no existe (para que el panel funcione
// aunque el alumno recién esté armando su base de datos) y siembra
// el usuario por defecto del curso: baycodec / baycodec.
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS usuarios_admin_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario VARCHAR(60) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

$existeUsuarioPorDefecto_baycodec = (bool) $pdo_baycodec
    ->query("SELECT COUNT(*) FROM usuarios_admin_tb_baycodec WHERE usuario = 'baycodec'")
    ->fetchColumn();

if (!$existeUsuarioPorDefecto_baycodec) {
    $insertarDefecto_baycodec = $pdo_baycodec->prepare(
        'INSERT INTO usuarios_admin_tb_baycodec (usuario, password_hash) VALUES (?, ?)'
    );
    $insertarDefecto_baycodec->execute(['baycodec', password_hash('baycodec', PASSWORD_DEFAULT)]);
}

// Corta la ejecución y manda a login.php si no hay sesión iniciada.
// Se llama al inicio de cada panel interno que requiera autenticación.
function exigirLogin_baycodec() {
    if (empty($_SESSION['admin_usuario_baycodec'])) {
        header('Location: login.php');
        exit;
    }
}
