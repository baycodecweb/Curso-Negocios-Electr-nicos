<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// OBTENER ANALÍTICA REAL (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// Calcula, a partir de eventos_analitica (ver registrar-evento.php),
// exactamente los mismos indicadores que antes calculaba
// calcularResumen_baycodec() en motor-analitica.js sobre el
// localStorage — mismo cálculo, mismos nombres de campo, pero ahora
// agregando los eventos de TODOS los visitantes del sitio, no solo
// los de quien abre el Panel de Control.
//
// Protegido igual que obtener-pedidos.php: son datos del negocio
// (qué productos generan más interés, cuánto se vendió), no algo que
// deba quedar abierto para cualquiera.
// ============================================================

require_once __DIR__ . '/auth-admin.php';

header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['admin_usuario_baycodec'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión en el panel de administración.']);
    exit;
}

$eventos_baycodec = $pdo_baycodec->query('SELECT id, tipo_evento, datos_json, pagina, creado_en FROM eventos_analitica_tb_baycodec ORDER BY id ASC')->fetchAll();

$totalVisitas_baycodec = 0;
$totalClicsWhatsApp_baycodec = 0;
$clicsPrecios_baycodec = 0;
$busquedas_baycodec = 0;
$totalPedidos_baycodec = 0;
$valorTotalPedidos_baycodec = 0.0;
$productosConMasInteres_baycodec = [];
$preguntasChatbot_baycodec = 0;
$resueltasChatbot_baycodec = 0;

foreach ($eventos_baycodec as $evento_baycodec) {
    $datos_baycodec = json_decode($evento_baycodec['datos_json'], true) ?: [];

    switch ($evento_baycodec['tipo_evento']) {
        case 'visita':
            $totalVisitas_baycodec++;
            break;
        case 'clic_whatsapp':
            $totalClicsWhatsApp_baycodec++;
            $nombreProducto_baycodec = $datos_baycodec['producto'] ?? 'Consulta general';
            $productosConMasInteres_baycodec[$nombreProducto_baycodec] = ($productosConMasInteres_baycodec[$nombreProducto_baycodec] ?? 0) + 1;
            break;
        case 'clic_precios_internacionales':
            $clicsPrecios_baycodec++;
            break;
        case 'busqueda_catalogo':
            $busquedas_baycodec++;
            break;
        case 'pedido_generado':
            $totalPedidos_baycodec++;
            $valorTotalPedidos_baycodec += (float) ($datos_baycodec['total'] ?? 0);
            break;
        case 'chatbot_pregunta':
            $preguntasChatbot_baycodec++;
            if (($datos_baycodec['tipoRespuesta'] ?? '') !== 'sin_respuesta') {
                $resueltasChatbot_baycodec++;
            }
            break;
    }
}

$interesTotal_baycodec = $totalClicsWhatsApp_baycodec + $clicsPrecios_baycodec;
$tasaConversion_baycodec = $interesTotal_baycodec > 0 ? ($totalPedidos_baycodec / $interesTotal_baycodec) * 100 : 0;
$tasaResolucionChatbot_baycodec = $preguntasChatbot_baycodec > 0 ? ($resueltasChatbot_baycodec / $preguntasChatbot_baycodec) * 100 : 0;

arsort($productosConMasInteres_baycodec);

$eventosRecientes_baycodec = array_slice(array_reverse($eventos_baycodec), 0, 20);
$eventosRecientes_baycodec = array_map(function ($e) {
    return [
        'id' => (int) $e['id'],
        'tipo' => $e['tipo_evento'],
        'detalle' => json_decode($e['datos_json'], true) ?: [],
        'pagina' => $e['pagina'],
        'fecha' => $e['creado_en'],
    ];
}, $eventosRecientes_baycodec);

echo json_encode([
    'ok' => true,
    'totalVisitas' => $totalVisitas_baycodec,
    'totalClicsWhatsApp' => $totalClicsWhatsApp_baycodec,
    'clicsPrecios' => $clicsPrecios_baycodec,
    'busquedas' => $busquedas_baycodec,
    'totalPedidos' => $totalPedidos_baycodec,
    'valorTotalPedidos' => round($valorTotalPedidos_baycodec, 2),
    'productosConMasInteres' => $productosConMasInteres_baycodec,
    'tasaConversion' => round($tasaConversion_baycodec, 1),
    'preguntasChatbot' => $preguntasChatbot_baycodec,
    'tasaResolucionChatbot' => round($tasaResolucionChatbot_baycodec, 1),
    'eventosRecientes' => $eventosRecientes_baycodec,
    'totalEventos' => count($eventos_baycodec),
]);
