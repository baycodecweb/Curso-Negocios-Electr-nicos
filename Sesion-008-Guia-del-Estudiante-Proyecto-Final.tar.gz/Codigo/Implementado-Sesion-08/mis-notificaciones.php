<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// MIS NOTIFICACIONES — mejora post-Sesión 8
// ------------------------------------------------------------
// Como este entorno no envía correos reales (ver notificaciones en
// auth-cliente.php), el cliente/vendedor las ve AQUÍ en vez de en su
// bandeja de entrada — así "pedido generado", "pago confirmado" o
// "te hicieron una venta" (si es C2C) sí llegan a alguna parte, no se
// quedan solo en la tabla sin que nadie las vea nunca.
// WHERE cliente_id = <su propia cuenta>, igual que el resto de
// páginas "Mis...": nunca ve las notificaciones de otro cliente.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

$clienteActual_baycodec = clienteActual_baycodec();
if (!$clienteActual_baycodec) {
    header('Location: login-cliente.php');
    exit;
}

$consulta_baycodec = $pdo_baycodec->prepare('SELECT * FROM notificaciones_tb_baycodec WHERE cliente_id = ? ORDER BY id DESC');
$consulta_baycodec->execute([$clienteActual_baycodec['id']]);
$misNotificaciones_baycodec = $consulta_baycodec->fetchAll();

function v_notifcli_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}

$ICONOS_TIPO_BAYCODEC = [
    'pedido_generado' => '🧾',
    'pago_exitoso' => '✅',
    'pago_rechazado' => '❌',
    'pedido_cancelado' => '✖',
    'pedido_reembolsado' => '↩',
    'venta_recibida' => '💰',
    'recuperacion_clave' => '🔑',
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Notificaciones — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 700px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .nota_baycodec { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 10px 14px; border-radius: 4px; font-size: 0.85rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .notif-tarjeta_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 14px 18px; margin: 10px 0; }
  .notif-asunto_baycodec { font-weight: 700; margin: 0 0 4px; }
  .notif-cuerpo_baycodec { color: #4b5563; font-size: 0.88rem; margin: 0; }
  .notif-fecha_baycodec { color: #9ca3af; font-size: 0.75rem; margin-top: 6px; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.9rem; }
</style>
</head>
<body>

<h1>📨 Mis Notificaciones — Grafiluz</h1>
<p class="subtitulo_baycodec">Avisos sobre tus pedidos (y tus ventas, si eres C2C).</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="tienda.php" style="background:#C41F25;">🌐 Ir al sitio</a>
  <a class="btn_baycodec secundario_baycodec" href="carrito.php" style="margin-left:8px;">🧾 Mi pedido</a>
</div>

<div class="nota_baycodec">
  ⚠️ Este entorno de práctica no tiene servidor de correo real — por eso estos avisos aparecen aquí en vez de
  llegar a tu email.
</div>

<?php if (empty($misNotificaciones_baycodec)): ?>
  <p class="vacio_baycodec">Todavía no tienes notificaciones.</p>
<?php else: foreach ($misNotificaciones_baycodec as $n_baycodec): ?>
  <div class="notif-tarjeta_baycodec">
    <p class="notif-asunto_baycodec"><?= $ICONOS_TIPO_BAYCODEC[$n_baycodec['tipo']] ?? '📨' ?> <?= v_notifcli_baycodec($n_baycodec['asunto']) ?></p>
    <p class="notif-cuerpo_baycodec"><?= v_notifcli_baycodec($n_baycodec['cuerpo']) ?></p>
    <p class="notif-fecha_baycodec"><?= v_notifcli_baycodec(date('d/m/Y H:i', strtotime($n_baycodec['creado_en']))) ?></p>
  </div>
<?php endforeach; endif; ?>

</body>
</html>
