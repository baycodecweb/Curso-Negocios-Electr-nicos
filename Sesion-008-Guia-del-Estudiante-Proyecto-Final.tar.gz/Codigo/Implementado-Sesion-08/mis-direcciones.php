<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// MIS DIRECCIONES (varias direcciones de envío) — mejora post-Sesión 8
// ------------------------------------------------------------
// Complemento de mi-perfil.php: clientes.direccion sigue siendo la
// dirección "de siempre" que se pidió al registrarse, pero un cliente
// real a veces recibe en casa y a veces en el trabajo. Aquí puede
// guardar varias direcciones, marcar una como predeterminada, y
// elegir cuál usar al generar un pedido (ver carrito.php).
// Todas las consultas van filtradas por "WHERE cliente_id = <su propia
// cuenta>", igual que en mis-pedidos.php y mis-productos.php: jamás ve
// ni toca la dirección de otro cliente, ni cambiando el id a mano.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

$clienteActual_baycodec = clienteActual_baycodec();
if (!$clienteActual_baycodec) {
    header('Location: login-cliente.php');
    exit;
}

$errorDireccion_baycodec = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar') {
    $etiqueta_baycodec = trim($_POST['etiqueta'] ?? '') ?: 'Principal';
    $direccion_baycodec = trim($_POST['direccion'] ?? '');
    $latitud_baycodec = is_numeric($_POST['latitud'] ?? '') ? (float) $_POST['latitud'] : null;
    $longitud_baycodec = is_numeric($_POST['longitud'] ?? '') ? (float) $_POST['longitud'] : null;

    if ($direccion_baycodec === '') {
        $errorDireccion_baycodec = 'Escribe la dirección.';
    } else {
        $pdo_baycodec->prepare(
            'INSERT INTO direcciones_tb_baycodec (cliente_id, etiqueta, direccion, latitud, longitud, predeterminada) VALUES (?, ?, ?, ?, ?, 0)'
        )->execute([$clienteActual_baycodec['id'], $etiqueta_baycodec, $direccion_baycodec, $latitud_baycodec, $longitud_baycodec]);
        header('Location: mis-direcciones.php?guardada=1');
        exit;
    }
}

// Marcar una dirección como predeterminada (por GET, con AND
// cliente_id = ? -> nunca puede tocar la de otro cliente).
if (isset($_GET['predeterminada'])) {
    $idAccion_baycodec = (int) $_GET['predeterminada'];
    $pdo_baycodec->prepare('UPDATE direcciones_tb_baycodec SET predeterminada = 0 WHERE cliente_id = ?')->execute([$clienteActual_baycodec['id']]);
    $pdo_baycodec->prepare('UPDATE direcciones_tb_baycodec SET predeterminada = 1 WHERE id = ? AND cliente_id = ?')->execute([$idAccion_baycodec, $clienteActual_baycodec['id']]);
    header('Location: mis-direcciones.php');
    exit;
}

// Eliminar una dirección propia.
if (isset($_GET['eliminar'])) {
    $pdo_baycodec->prepare('DELETE FROM direcciones_tb_baycodec WHERE id = ? AND cliente_id = ?')->execute([(int) $_GET['eliminar'], $clienteActual_baycodec['id']]);
    header('Location: mis-direcciones.php?eliminada=1');
    exit;
}

$consultaDirecciones_baycodec = $pdo_baycodec->prepare('SELECT * FROM direcciones_tb_baycodec WHERE cliente_id = ? ORDER BY predeterminada DESC, creado_en DESC');
$consultaDirecciones_baycodec->execute([$clienteActual_baycodec['id']]);
$misDirecciones_baycodec = $consultaDirecciones_baycodec->fetchAll();

function v_dir_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Direcciones — Grafiluz</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
<style>
  body { font-family: system-ui, sans-serif; max-width: 700px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  .btn_baycodec.peligro_baycodec { background: #fee2e2; color: #991b1b; }
  .error_baycodec { background: #fef2f2; border-left: 4px solid #dc2626; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 8px 12px; border-radius: 4px; font-size: 0.85rem; margin: 4px 0 14px; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 12px 0 4px; }
  input[type="text"] { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
  .mapa-envio_baycodec { height: 200px; border-radius: 6px; margin-top: 8px; border: 1px solid #d1d5db; }
  .mapa-acciones_baycodec { display: flex; align-items: center; gap: 10px; margin-top: 6px; flex-wrap: wrap; }
  .btn-ubicacion_baycodec { background: #f3f4f6; color: #1f2937; border: 1px solid #d1d5db; border-radius: 6px; padding: 6px 12px; font-size: 0.82rem; cursor: pointer; font-family: inherit; }
  .mapa-coordenadas_baycodec { font-size: 0.78rem; color: #6b7280; }
  .direccion-tarjeta_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 14px 18px; margin: 10px 0; display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; flex-wrap: wrap; }
  .direccion-etiqueta_baycodec { font-weight: 700; }
  .direccion-etiqueta_baycodec .badge-predeterminada_baycodec { background: #dbeafe; color: #1d4ed8; font-size: 0.7rem; font-weight: 600; border-radius: 10px; padding: 1px 8px; margin-left: 6px; }
  .direccion-texto_baycodec { color: #4b5563; font-size: 0.88rem; margin: 4px 0 0; }
  .direccion-acciones_baycodec { display: flex; gap: 6px; flex-wrap: wrap; }
  .direccion-acciones_baycodec .btn_baycodec { font-size: 0.75rem; padding: 5px 10px; }
  .vacio_baycodec { color: #9ca3af; font-size: 0.9rem; }
</style>
</head>
<body>

<h1>📍 Mis Direcciones — Grafiluz</h1>
<p class="subtitulo_baycodec">Guarda varias direcciones (casa, trabajo, regalo...) y elige cuál usar al generar tu pedido.</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="tienda.php" style="background:#C41F25;">🌐 Ir al sitio</a>
  <a class="btn_baycodec secundario_baycodec" href="carrito.php" style="margin-left:8px;">🧾 Mi pedido</a>
  <a class="btn_baycodec secundario_baycodec" href="mi-perfil.php" style="margin-left:8px;">👤 Mi perfil</a>
</div>

<?php if (isset($_GET['guardada'])): ?>
  <p class="exito_baycodec">✅ Dirección guardada.</p>
<?php endif; ?>
<?php if (isset($_GET['eliminada'])): ?>
  <p class="exito_baycodec">🗑️ Dirección eliminada.</p>
<?php endif; ?>
<?php if ($errorDireccion_baycodec): ?>
  <p class="error_baycodec">⚠️ <?= v_dir_baycodec($errorDireccion_baycodec) ?></p>
<?php endif; ?>

<h2 style="font-size:1.1rem;">➕ Agregar dirección nueva</h2>
<div class="caja_baycodec">
  <form method="post" action="mis-direcciones.php">
    <input type="hidden" name="accion" value="guardar">

    <label for="etiqueta">Etiqueta (para reconocerla rápido)</label>
    <input type="text" id="etiqueta" name="etiqueta" placeholder="Ej: Casa, Trabajo, Regalo para mamá">

    <label for="direccion">Dirección</label>
    <input type="text" id="direccion" name="direccion" placeholder="Ej: Calle Los Álamos 123, Cercado, Arequipa" required>

    <div id="mapa-envio_baycodec" class="mapa-envio_baycodec"></div>
    <div class="mapa-acciones_baycodec">
      <button type="button" class="btn-ubicacion_baycodec" onclick="dirUsarUbicacionActual_baycodec(this)">📍 Usar mi ubicación actual</button>
      <span class="mapa-coordenadas_baycodec" id="mapa-coordenadas_baycodec">Sin ubicación marcada (opcional).</span>
    </div>
    <input type="hidden" id="latitud" name="latitud" value="">
    <input type="hidden" id="longitud" name="longitud" value="">

    <button class="btn_baycodec" type="submit" style="margin-top:14px; width:auto;">💾 Guardar dirección</button>
  </form>
</div>

<h2 style="font-size:1.1rem;">Direcciones guardadas (<?= count($misDirecciones_baycodec) ?>)</h2>
<?php if (empty($misDirecciones_baycodec)): ?>
  <p class="vacio_baycodec">Todavía no guardaste ninguna dirección.</p>
<?php else: foreach ($misDirecciones_baycodec as $d_baycodec): ?>
  <div class="direccion-tarjeta_baycodec">
    <div>
      <div class="direccion-etiqueta_baycodec">
        <?= v_dir_baycodec($d_baycodec['etiqueta']) ?>
        <?php if ($d_baycodec['predeterminada']): ?><span class="badge-predeterminada_baycodec">Predeterminada</span><?php endif; ?>
      </div>
      <p class="direccion-texto_baycodec"><?= v_dir_baycodec($d_baycodec['direccion']) ?></p>
    </div>
    <div class="direccion-acciones_baycodec">
      <?php if (!$d_baycodec['predeterminada']): ?>
        <a class="btn_baycodec secundario_baycodec" href="mis-direcciones.php?predeterminada=<?= (int) $d_baycodec['id'] ?>">Usar como predeterminada</a>
      <?php endif; ?>
      <a class="btn_baycodec peligro_baycodec" href="mis-direcciones.php?eliminar=<?= (int) $d_baycodec['id'] ?>"
         onclick="return confirm('¿Eliminar esta dirección?');">🗑️</a>
    </div>
  </div>
<?php endforeach; endif; ?>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script>
  const CENTRO_AREQUIPA_BAYCODEC = [-16.3988, -71.5369];
  const dirMapaLeaflet_baycodec = L.map('mapa-envio_baycodec').setView(CENTRO_AREQUIPA_BAYCODEC, 13);
  let dirMarcadorLeaflet_baycodec;

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 19,
  }).addTo(dirMapaLeaflet_baycodec);

  dirMapaLeaflet_baycodec.on('click', function (e) {
    dirColocarMarcador_baycodec(e.latlng.lat, e.latlng.lng);
  });

  function dirColocarMarcador_baycodec(lat, lng) {
    if (dirMarcadorLeaflet_baycodec) {
      dirMarcadorLeaflet_baycodec.setLatLng([lat, lng]);
    } else {
      dirMarcadorLeaflet_baycodec = L.marker([lat, lng], { draggable: true }).addTo(dirMapaLeaflet_baycodec);
      dirMarcadorLeaflet_baycodec.on('dragend', function () {
        const posicion = dirMarcadorLeaflet_baycodec.getLatLng();
        dirActualizarCoordenadas_baycodec(posicion.lat, posicion.lng);
      });
    }
    dirActualizarCoordenadas_baycodec(lat, lng);
  }

  function dirActualizarCoordenadas_baycodec(lat, lng) {
    document.getElementById('latitud').value = lat.toFixed(7);
    document.getElementById('longitud').value = lng.toFixed(7);
    document.getElementById('mapa-coordenadas_baycodec').textContent = `📍 ${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  }

  function dirUsarUbicacionActual_baycodec(boton) {
    if (!navigator.geolocation) {
      alert('Tu navegador no soporta geolocalización. Puedes marcar el punto directamente en el mapa.');
      return;
    }
    const textoOriginal = boton.textContent;
    boton.textContent = '⏳ Obteniendo ubicación...';
    boton.disabled = true;

    navigator.geolocation.getCurrentPosition(
      function (posicion) {
        const { latitude, longitude } = posicion.coords;
        dirMapaLeaflet_baycodec.setView([latitude, longitude], 16);
        dirColocarMarcador_baycodec(latitude, longitude);
        boton.textContent = textoOriginal;
        boton.disabled = false;
      },
      function () {
        alert('No se pudo obtener tu ubicación (revisa los permisos del navegador). Puedes marcarla manualmente haciendo clic en el mapa.');
        boton.textContent = textoOriginal;
        boton.disabled = false;
      }
    );
  }
</script>

</body>
</html>
