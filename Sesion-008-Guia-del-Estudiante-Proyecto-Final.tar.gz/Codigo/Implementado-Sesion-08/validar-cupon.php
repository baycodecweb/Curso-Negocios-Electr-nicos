<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// VALIDAR CUPÓN (endpoint JSON) — mejora post-Sesión 8
// ------------------------------------------------------------
// Solo sirve para PREVISUALIZAR el descuento en carrito.php antes de
// generar el pedido (mejor experiencia: el cliente ve cuánto se
// ahorra antes de confirmar). No es el lugar donde el descuento se
// vuelve definitivo — crear-pedido.php vuelve a validar y calcular
// todo desde cero al generar el pedido de verdad, así que aunque
// alguien manipulara la respuesta de este endpoint no logra nada.
// ============================================================

require_once __DIR__ . '/auth-cliente.php';

header('Content-Type: application/json; charset=utf-8');

if (!clienteActual_baycodec()) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'mensaje' => 'Debes iniciar sesión.']);
    exit;
}

$cuerpo_baycodec = json_decode(file_get_contents('php://input'), true);
$codigo_baycodec = trim($cuerpo_baycodec['codigo_cupon'] ?? '');
$subtotal_baycodec = (float) ($cuerpo_baycodec['subtotal'] ?? 0);

if ($codigo_baycodec === '') {
    echo json_encode(['ok' => false, 'mensaje' => 'Escribe un código de cupón.']);
    exit;
}

$consultaCupon_baycodec = $pdo_baycodec->prepare('SELECT * FROM cupones_tb_baycodec WHERE codigo = ?');
$consultaCupon_baycodec->execute([$codigo_baycodec]);
$cupon_baycodec = $consultaCupon_baycodec->fetch();

$hoy_baycodec = date('Y-m-d');
$cuponValido_baycodec = $cupon_baycodec
    && (int) $cupon_baycodec['activo'] === 1
    && ($cupon_baycodec['fecha_inicio'] === null || $cupon_baycodec['fecha_inicio'] <= $hoy_baycodec)
    && ($cupon_baycodec['fecha_fin'] === null || $cupon_baycodec['fecha_fin'] >= $hoy_baycodec)
    && ($cupon_baycodec['usos_maximos'] === null || (int) $cupon_baycodec['usos_actuales'] < (int) $cupon_baycodec['usos_maximos']);

if (!$cuponValido_baycodec) {
    echo json_encode(['ok' => false, 'mensaje' => 'Ese cupón no es válido, ya expiró o alcanzó su límite de usos.']);
    exit;
}

$descuento_baycodec = $cupon_baycodec['tipo'] === 'porcentaje'
    ? round($subtotal_baycodec * ((float) $cupon_baycodec['valor'] / 100), 2)
    : min((float) $cupon_baycodec['valor'], $subtotal_baycodec);

echo json_encode([
    'ok' => true,
    'descuento' => $descuento_baycodec,
    'total_con_descuento' => round($subtotal_baycodec - $descuento_baycodec, 2),
    'descripcion' => $cupon_baycodec['tipo'] === 'porcentaje'
        ? ((float) $cupon_baycodec['valor']) . '% de descuento'
        : 'S/ ' . number_format((float) $cupon_baycodec['valor'], 2) . ' de descuento',
]);
