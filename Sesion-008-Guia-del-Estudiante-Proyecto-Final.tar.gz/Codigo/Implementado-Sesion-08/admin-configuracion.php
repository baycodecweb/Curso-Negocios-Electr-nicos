<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// CONFIGURACIÓN DEL SITIO — mejora post-Sesión 8
// ------------------------------------------------------------
// Edita la tabla configuracion (ver db-conexion.php): el número de
// WhatsApp que usan carrito.php/script.js, la tasa de IGV que usa
// crear-pedido.php para el desglose, la moneda base (informativa) y
// el porcentaje de comisión del marketplace que usa pagar-pedido.php.
// ============================================================

require __DIR__ . '/auth-admin.php';
exigirLogin_baycodec();

$CAMPOS_CONFIG_BAYCODEC = [
    'whatsapp_numero' => 'Número de WhatsApp (formato internacional, sin + ni espacios)',
    'igv_porcentaje' => 'Tasa de IGV (%) — informativa, el precio del catálogo ya la incluye',
    'moneda_base' => 'Moneda base (código, ej. PEN)',
    'comision_marketplace_porcentaje' => 'Comisión de Grafiluz sobre ventas C2C (%)',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (array_keys($CAMPOS_CONFIG_BAYCODEC) as $clave_baycodec) {
        $valor_baycodec = trim($_POST[$clave_baycodec] ?? '');
        $pdo_baycodec->prepare('INSERT INTO configuracion_tb_baycodec (clave, valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE valor = VALUES(valor)')
            ->execute([$clave_baycodec, $valor_baycodec]);
    }
    registrarAuditoriaAdmin_baycodec($pdo_baycodec, 'editar_configuracion', null);
    header('Location: admin-configuracion.php?guardado=1');
    exit;
}

$valoresActuales_baycodec = [];
foreach (array_keys($CAMPOS_CONFIG_BAYCODEC) as $clave_baycodec) {
    $valoresActuales_baycodec[$clave_baycodec] = obtenerConfiguracion_baycodec($pdo_baycodec, $clave_baycodec);
}

function v_conf_baycodec($valor) {
    return htmlspecialchars($valor ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Configuración — Grafiluz</title>
<style>
  body { font-family: system-ui, sans-serif; max-width: 700px; margin: 0 auto; padding: 0 20px 60px; color: #1f2937; background: #fafafa; line-height: 1.55; }
  h1 { font-size: 1.4rem; margin-bottom: 4px; }
  .subtitulo_baycodec { color: #6b7280; margin-top: 0; }
  .caja_baycodec { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px 20px; margin: 14px 0; }
  .exito_baycodec { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 10px 14px; border-radius: 4px; font-size: 0.88rem; margin: 14px 0; }
  .btn_baycodec { background: #1d4ed8; color: #fff; border: none; padding: 9px 16px; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600; text-decoration: none; display: inline-block; }
  .btn_baycodec.secundario_baycodec { background: #e5e7eb; color: #1f2937; }
  label { display: block; font-size: 0.85rem; font-weight: 600; margin: 14px 0 4px; }
  input[type="text"] { width: 100%; padding: 9px 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: inherit; font-size: 0.9rem; box-sizing: border-box; }
</style>
</head>
<body>

<h1>⚙️ Configuración del Sitio — Grafiluz</h1>
<p class="subtitulo_baycodec">Valores usados en varios lugares del sitio, editables sin tocar código.</p>

<div class="caja_baycodec">
  <a class="btn_baycodec" href="admin-productos.php" style="background:#C41F25;">🛠️ Panel de Productos</a>
</div>

<?php if (isset($_GET['guardado'])): ?><p class="exito_baycodec">✅ Configuración guardada.</p><?php endif; ?>

<div class="caja_baycodec">
  <form method="post" action="admin-configuracion.php">
    <?php foreach ($CAMPOS_CONFIG_BAYCODEC as $clave_baycodec => $etiqueta_baycodec): ?>
      <label for="<?= v_conf_baycodec($clave_baycodec) ?>"><?= v_conf_baycodec($etiqueta_baycodec) ?></label>
      <input type="text" id="<?= v_conf_baycodec($clave_baycodec) ?>" name="<?= v_conf_baycodec($clave_baycodec) ?>"
             value="<?= v_conf_baycodec($valoresActuales_baycodec[$clave_baycodec]) ?>">
    <?php endforeach; ?>
    <button class="btn_baycodec" type="submit" style="margin-top:18px;">💾 Guardar cambios</button>
  </form>
</div>

</body>
</html>
