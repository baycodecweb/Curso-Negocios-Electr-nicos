<?php
$__marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Código del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// CUENTAS DE CLIENTE (COMPRADOR) — Sesión 8: publicación real
// ------------------------------------------------------------
// Hasta ahora "Mi Pedido" (Sesión 3, db-modelo.js) creaba un cliente
// nuevo en localStorage cada vez que alguien compraba: no había
// cuenta real, ni login, ni forma de ver pedidos anteriores. Para
// que las compras funcionen como un marketplace real (que un
// comprador se registre eligiendo si es B2B, B2C o C2C, y que su
// pedido quede realmente guardado) hace falta una cuenta persistente
// en la base de datos — igual que se hizo para el panel interno en
// auth-admin.php, pero esta tabla es para los CLIENTES de la tienda,
// no para el equipo de Grafiluz.
//
// La contraseña nunca se guarda en texto plano (password_hash /
// password_verify), la misma buena práctica del panel de admin.
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db-conexion.php';

$pdo_baycodec->exec(
    "CREATE TABLE IF NOT EXISTS clientes_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario VARCHAR(120) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        nombre VARCHAR(180) NOT NULL,
        apellidos VARCHAR(180) NOT NULL DEFAULT '',
        dni VARCHAR(15) NOT NULL DEFAULT '',
        telefono VARCHAR(20) NOT NULL DEFAULT '',
        direccion VARCHAR(255) NOT NULL DEFAULT '',
        latitud DECIMAL(10,7) DEFAULT NULL,
        longitud DECIMAL(10,7) DEFAULT NULL,
        tipo_cliente ENUM('B2C','B2B','C2C') NOT NULL DEFAULT 'B2C',
        ruc VARCHAR(20) DEFAULT '',
        plataforma_reventa VARCHAR(180) DEFAULT '',
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
);

// Migracion para instalaciones que ya tenian la tabla "clientes" antes
// de agregar los datos de envio (Sesion 8: registro con apellidos,
// DNI, telefono y direccion, necesarios para saber a donde llega el
// producto si se envia).
$pdo_baycodec->exec("ALTER TABLE clientes_tb_baycodec ADD COLUMN IF NOT EXISTS apellidos VARCHAR(180) NOT NULL DEFAULT '' AFTER nombre");
$pdo_baycodec->exec("ALTER TABLE clientes_tb_baycodec ADD COLUMN IF NOT EXISTS dni VARCHAR(15) NOT NULL DEFAULT '' AFTER apellidos");
$pdo_baycodec->exec("ALTER TABLE clientes_tb_baycodec ADD COLUMN IF NOT EXISTS telefono VARCHAR(20) NOT NULL DEFAULT '' AFTER dni");
$pdo_baycodec->exec("ALTER TABLE clientes_tb_baycodec ADD COLUMN IF NOT EXISTS direccion VARCHAR(255) NOT NULL DEFAULT '' AFTER telefono");
// Sesion 8 (ampliacion): coordenadas exactas del mapa, para cuando la
// direccion escrita no basta y se necesita precision en la entrega.
$pdo_baycodec->exec("ALTER TABLE clientes_tb_baycodec ADD COLUMN IF NOT EXISTS latitud DECIMAL(10,7) DEFAULT NULL AFTER direccion");
$pdo_baycodec->exec("ALTER TABLE clientes_tb_baycodec ADD COLUMN IF NOT EXISTS longitud DECIMAL(10,7) DEFAULT NULL AFTER latitud");

$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS pedidos_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT NOT NULL,
        total DECIMAL(10,2) NOT NULL DEFAULT 0,
        estado VARCHAR(20) NOT NULL DEFAULT "Pendiente",
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (cliente_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// Envío / IGV (mejora post-Sesión 8): "total" (columna de arriba)
// sigue siendo lo que el cliente paga de verdad — subtotal, igv_monto
// y envio_costo son el DESGLOSE informativo de cómo se llegó a ese
// total (ver crear-pedido.php). El precio del catálogo ya incluye
// IGV (como en cualquier vitrina peruana orientada a consumidor
// final); igv_monto es la parte de ese precio que corresponde al
// impuesto, no un cobro adicional — lo único que SÍ se suma aparte es
// envio_costo, según la zona elegida en tarifas_envio.
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS subtotal DECIMAL(10,2) NOT NULL DEFAULT 0');
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS igv_monto DECIMAL(10,2) NOT NULL DEFAULT 0');
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS envio_costo DECIMAL(10,2) NOT NULL DEFAULT 0');
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS envio_zona VARCHAR(120) NOT NULL DEFAULT ""');

$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS detalle_pedido_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pedido_id INT NOT NULL,
        producto_codigo VARCHAR(60) NOT NULL,
        producto_nombre VARCHAR(180) NOT NULL,
        cantidad INT NOT NULL,
        precio_unitario DECIMAL(10,2) NOT NULL,
        vendedor_id INT DEFAULT NULL,
        FOREIGN KEY (pedido_id) REFERENCES pedidos_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);
// Marketplace multi-vendedor: quién vendió cada línea del pedido, para
// que un vendedor C2C vea "quién le compró" en mis-productos.php aunque
// después edite o borre ese producto (vendedor_id queda fijo en la
// venta ya hecha, no depende de cómo esté hoy la tabla productos).
$pdo_baycodec->exec('ALTER TABLE detalle_pedido_tb_baycodec ADD COLUMN IF NOT EXISTS vendedor_id INT DEFAULT NULL');
// Variantes de producto (mejora post-Sesión 8): igual que
// producto_nombre, variante_nombre queda fijo tal como estaba al
// momento de la compra (snapshot), aunque la variante luego cambie de
// nombre o se borre. variante_id es NULL si el producto no tenía
// variantes cuando se compró.
$pdo_baycodec->exec('ALTER TABLE detalle_pedido_tb_baycodec ADD COLUMN IF NOT EXISTS variante_id INT DEFAULT NULL');
$pdo_baycodec->exec('ALTER TABLE detalle_pedido_tb_baycodec ADD COLUMN IF NOT EXISTS variante_nombre VARCHAR(120) NOT NULL DEFAULT ""');

// ============================================================
// RESEÑAS / CALIFICACIONES DE PRODUCTOS (mejora post-Sesión 8)
// ------------------------------------------------------------
// Solo se puede reseñar un producto que de verdad se compró y pagó
// (ver guardar-resena.php); la calificación se muestra en las tarjetas
// del catálogo (tienda.php) y se deja/edita desde el historial de
// compras (mis-pedidos.php). UNIQUE (producto_codigo, cliente_id): un
// cliente tiene UNA sola reseña por producto — volver a calificarlo
// actualiza la que ya tenía, no crea una fila nueva. Sin FOREIGN KEY a
// productos.codigo, siguiendo la misma convención que detalle_pedido
// (producto_codigo es solo un identificador de texto, no una relación
// formal, para no depender de cómo esté hoy la tabla productos).
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS resenas_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        producto_codigo VARCHAR(60) NOT NULL,
        cliente_id INT NOT NULL,
        calificacion TINYINT NOT NULL,
        comentario VARCHAR(500) NOT NULL DEFAULT "",
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY resena_unica_baycodec (producto_codigo, cliente_id),
        FOREIGN KEY (cliente_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS pagos_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pedido_id INT NOT NULL,
        estado VARCHAR(20) NOT NULL DEFAULT "Pendiente",
        metodo VARCHAR(60) DEFAULT NULL,
        transaccion_id VARCHAR(60) DEFAULT NULL,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pedido_id) REFERENCES pedidos_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// ============================================================
// DIRECCIONES DE ENVÍO (mejora post-Sesión 8)
// ------------------------------------------------------------
// Hasta ahora clientes.direccion era UN solo campo por cuenta — quien
// enviaba a veces a casa y a veces al trabajo tenía que editar su
// perfil cada vez. Esta tabla permite guardar VARIAS direcciones y
// elegir una al generar el pedido (ver carrito.php / crear-pedido.php)
// sin tocar clientes.direccion, que se mantiene como antes (se sigue
// pidiendo al registrarse, y sirve de valor por defecto: la primera
// fila que se guarda aquí, ver registro-cliente.php).
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS direcciones_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT NOT NULL,
        etiqueta VARCHAR(60) NOT NULL DEFAULT "Principal",
        direccion VARCHAR(255) NOT NULL,
        latitud DECIMAL(10,7) DEFAULT NULL,
        longitud DECIMAL(10,7) DEFAULT NULL,
        predeterminada TINYINT(1) NOT NULL DEFAULT 0,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (cliente_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// direccion_envio_texto guarda una "foto" de la dirección al momento
// del pedido (igual que detalle_pedido guarda producto_nombre): si el
// cliente después edita o borra esa dirección de direcciones, el
// pedido ya generado no pierde el dato de a dónde se envió.
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS direccion_id INT DEFAULT NULL');
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS direccion_envio_texto VARCHAR(255) NOT NULL DEFAULT ""');

// ============================================================
// CUPONES DE DESCUENTO (mejora post-Sesión 8)
// ------------------------------------------------------------
// El descuento SIEMPRE se recalcula en el servidor al generar el
// pedido (ver crear-pedido.php) a partir del código — nunca se confía
// en un monto de descuento que mande el navegador, mismo principio
// que ya se aplicaba con el precio de cada producto.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS cupones_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        codigo VARCHAR(40) NOT NULL UNIQUE,
        tipo ENUM("porcentaje","fijo") NOT NULL DEFAULT "porcentaje",
        valor DECIMAL(10,2) NOT NULL,
        fecha_inicio DATE DEFAULT NULL,
        fecha_fin DATE DEFAULT NULL,
        usos_maximos INT DEFAULT NULL,
        usos_actuales INT NOT NULL DEFAULT 0,
        activo TINYINT(1) NOT NULL DEFAULT 1,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS cupon_id INT DEFAULT NULL');
$pdo_baycodec->exec('ALTER TABLE pedidos_tb_baycodec ADD COLUMN IF NOT EXISTS descuento_aplicado DECIMAL(10,2) NOT NULL DEFAULT 0');

// ============================================================
// FAVORITOS / WISHLIST (mejora post-Sesión 8)
// ------------------------------------------------------------
// UNIQUE (cliente_id, producto_codigo): guardar el mismo producto dos
// veces no duplica la fila, solo confirma que ya estaba guardado.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS favoritos_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT NOT NULL,
        producto_codigo VARCHAR(60) NOT NULL,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY favorito_unico_baycodec (cliente_id, producto_codigo),
        FOREIGN KEY (cliente_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// ============================================================
// CALIFICACIÓN AL VENDEDOR (mejora post-Sesión 8)
// ------------------------------------------------------------
// Distinta de "resenas" (que califica el PRODUCTO): en un marketplace
// C2C real (como MercadoLibre) el comprador también califica al
// VENDEDOR como tal — su trato, si envió a tiempo, etc. Un cliente
// tiene UNA sola calificación por vendedor (UNIQUE), igual que con
// las reseñas de producto.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS calificaciones_vendedor_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vendedor_id INT NOT NULL,
        cliente_id INT NOT NULL,
        calificacion TINYINT NOT NULL,
        comentario VARCHAR(500) NOT NULL DEFAULT "",
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY calificacion_vendedor_unica_baycodec (vendedor_id, cliente_id),
        FOREIGN KEY (vendedor_id) REFERENCES clientes_tb_baycodec(id),
        FOREIGN KEY (cliente_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// ============================================================
// CARRITO PERSISTENTE EN SERVIDOR (mejora post-Sesión 8)
// ------------------------------------------------------------
// El carrito sigue viviendo principalmente en localStorage (rápido,
// sin esperar al servidor para cada clic en "Agregar") — estas tablas
// son una COPIA de respaldo que solo se sincroniza cuando hay sesión
// de cliente iniciada (ver guardar-carrito.php / obtener-carrito.php),
// para que el carrito no se pierda si el cliente cambia de navegador
// o de dispositivo a mitad de una compra. Un cliente tiene UN solo
// carrito (UNIQUE cliente_id); sus líneas van en carrito_items.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS carritos_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT NOT NULL UNIQUE,
        actualizado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (cliente_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS carrito_items_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        carrito_id INT NOT NULL,
        producto_codigo VARCHAR(60) NOT NULL,
        cantidad INT NOT NULL,
        UNIQUE KEY carrito_item_unico_baycodec (carrito_id, producto_codigo),
        FOREIGN KEY (carrito_id) REFERENCES carritos_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

// ============================================================
// NOTIFICACIONES (mejora post-Sesión 8)
// ------------------------------------------------------------
// Registro de qué mensaje se le "avisaría" a un cliente y cuándo
// (pedido generado, pago confirmado, pedido cancelado/reembolsado,
// recuperación de contraseña). "enviado" queda en 0 a propósito: este
// entorno de práctica no tiene un servidor de correo real (mismo
// motivo que la nota de verificación de email en registro-cliente.php),
// así que esto funciona como una COLA/bitácora de lo que se ENVIARÍA
// en un despliegue real con SMTP configurado — ver admin-notificaciones.php.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS notificaciones_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cliente_id INT DEFAULT NULL,
        tipo VARCHAR(60) NOT NULL,
        asunto VARCHAR(180) NOT NULL,
        cuerpo VARCHAR(500) NOT NULL DEFAULT "",
        enviado TINYINT(1) NOT NULL DEFAULT 0,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (cliente_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

/** Registra una notificación pendiente. Nunca lanza error hacia afuera
 *  (igual que registrarAuditoriaAdmin_baycodec): perder el registro de
 *  una notificación no debe tumbar la acción real (pagar, cancelar...). */
function registrarNotificacion_baycodec($pdo, $clienteId, $tipo, $asunto, $cuerpo) {
    try {
        $pdo->prepare('INSERT INTO notificaciones_tb_baycodec (cliente_id, tipo, asunto, cuerpo) VALUES (?, ?, ?, ?)')
            ->execute([$clienteId, $tipo, $asunto, $cuerpo]);
    } catch (Throwable $error) {
        // No se propaga.
    }
}

// ============================================================
// COMISIONES DEL MARKETPLACE + PAGOS AL VENDEDOR (mejora post-Sesión 8)
// ------------------------------------------------------------
// Grafiluz es un marketplace con vendedores C2C (ver vendedor_id en
// productos/detalle_pedido) — hasta ahora no existía ninguna cuenta de
// cuánto le corresponde a Grafiluz y cuánto al vendedor por cada
// venta. "comisiones" se genera automáticamente al PAGARSE un pedido
// (ver pagar-pedido.php), una fila por vendedor distinto involucrado
// en ese pedido, usando el porcentaje vigente en configuracion
// ("comision_marketplace_porcentaje") al momento de la venta (no el
// de hoy, para no reescribir la historia si el porcentaje cambia
// después). Si el pedido se reembolsa, esa fila se borra (ver
// admin-productos.php): no hay comisión que cobrar sobre una venta
// que se devolvió. "pagos_vendedor" es cada pago que el admin
// registra manualmente hacia un vendedor (ver admin-comisiones.php),
// para llevar la cuenta de cuánto ya se le pagó vs. cuánto se le debe.
// ============================================================
$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS comisiones_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pedido_id INT NOT NULL,
        vendedor_id INT NOT NULL,
        monto_venta DECIMAL(10,2) NOT NULL,
        porcentaje_comision DECIMAL(5,2) NOT NULL,
        monto_comision DECIMAL(10,2) NOT NULL,
        monto_vendedor DECIMAL(10,2) NOT NULL,
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY comision_unica_baycodec (pedido_id, vendedor_id),
        FOREIGN KEY (pedido_id) REFERENCES pedidos_tb_baycodec(id),
        FOREIGN KEY (vendedor_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

$pdo_baycodec->exec(
    'CREATE TABLE IF NOT EXISTS pagos_vendedor_tb_baycodec (
        id INT AUTO_INCREMENT PRIMARY KEY,
        vendedor_id INT NOT NULL,
        monto DECIMAL(10,2) NOT NULL,
        metodo VARCHAR(60) NOT NULL DEFAULT "",
        referencia VARCHAR(120) NOT NULL DEFAULT "",
        creado_en TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (vendedor_id) REFERENCES clientes_tb_baycodec(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
);

/**
 * Devuelve la cuenta del cliente que tiene la sesión abierta, o null
 * si nadie inició sesión (navegar y agregar al carrito no requiere
 * cuenta: solo generar/pagar el pedido).
 */
function clienteActual_baycodec() {
    if (empty($_SESSION['cliente_id_baycodec'])) {
        return null;
    }
    return [
        'id'                 => $_SESSION['cliente_id_baycodec'],
        'usuario'            => $_SESSION['cliente_usuario_baycodec'],
        'nombre'             => $_SESSION['cliente_nombre_baycodec'],
        'tipo_cliente'       => $_SESSION['cliente_tipo_baycodec'],
    ];
}

function iniciarSesionCliente_baycodec(array $filaCliente_baycodec) {
    session_regenerate_id(true);
    $_SESSION['cliente_id_baycodec'] = (int) $filaCliente_baycodec['id'];
    $_SESSION['cliente_usuario_baycodec'] = $filaCliente_baycodec['usuario'];
    $_SESSION['cliente_nombre_baycodec'] = $filaCliente_baycodec['nombre'];
    $_SESSION['cliente_tipo_baycodec'] = $filaCliente_baycodec['tipo_cliente'];
}
