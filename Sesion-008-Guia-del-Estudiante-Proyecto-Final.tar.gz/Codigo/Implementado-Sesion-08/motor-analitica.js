var __marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
// Codigo del proyecto Grafiluz - adaptado y mantenido por baycodec
// ============================================================
// LA TIENDA QUE OBSERVA — Sesión 5: Marketing y Tecnologías
// Digitales
// ------------------------------------------------------------
// Objetivo pedagógico: demostrar que el sitio ya tiene "inyectado"
// un código de rastreo que registra cada visita, clic de interés
// (WhatsApp, precios internacionales) y pedido generado, tal como
// lo haría un píxel de Google Analytics o de Meta — pero sin
// depender de una cuenta externa real (que un alumno no tiene al
// momento de hacer esta prueba de concepto).
//
// En un despliegue real (Sesión 8), este archivo se reemplazaría
// o convivería con el snippet real de Google Analytics / Meta
// Pixel; el patrón de instrumentación (marcar eventos clave del
// negocio) es exactamente el mismo.
//
// Los eventos se guardan en localStorage como una tabla más,
// igual que las tablas de db-modelo.js (Sesión 3), y se leen desde
// panel-control.html para simular el "panel de control corporativo".
// ============================================================

const ANALITICA_CLAVE_baycodec = "grafiluz-s5-eventos";

function obtenerEventos_baycodec() {
  const guardado = localStorage.getItem(ANALITICA_CLAVE_baycodec);
  return guardado ? JSON.parse(guardado) : [];
}

/**
 * Registra un evento de negocio (visita, clic de interés, pedido
 * generado, búsqueda, etc.). Se guarda en dos lugares:
 * 1. localStorage (como hasta ahora, Sesión 5) — mantiene compatible
 *    cualquier código que todavía lea obtenerEventos_baycodec()/
 *    calcularResumen_baycodec() aquí mismo, en ESTE navegador.
 * 2. registrar-evento.php (mejora post-Sesión 8) — el mismo evento va
 *    también al servidor, en la tabla eventos_analitica, para que el
 *    Panel de Control (obtener-analitica.php) muestre datos reales
 *    agregados de TODOS los visitantes, no solo de quien lo abre. Se
 *    envía "en segundo plano" (sin await): si falla o el visitante
 *    está sin internet, no debe romper ninguna otra funcionalidad del
 *    sitio — perder un evento de analítica nunca es motivo para
 *    interrumpir al usuario.
 * @param {string} tipo - "visita" | "clic_whatsapp" | "clic_precios_internacionales" | "busqueda_catalogo" | "pedido_generado"
 * @param {Object} detalle - datos propios del evento (ej. { producto })
 */
function registrarEvento_baycodec(tipo, detalle = {}) {
  const eventos = obtenerEventos_baycodec();
  eventos.push({
    id: eventos.length + 1,
    tipo,
    detalle,
    pagina: (location.pathname.split("/").pop() || "tienda.html"),
    fecha: new Date().toISOString(),
  });
  localStorage.setItem(ANALITICA_CLAVE_baycodec, JSON.stringify(eventos));

  try {
    fetch("registrar-evento.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tipo_evento: tipo,
        datos: detalle,
        pagina: location.pathname.split("/").pop() || "tienda.html",
      }),
    }).catch(() => {});
  } catch (error) {
    // Sin conexión, o corriendo sin backend PHP (ej. tienda.html con
    // python3 -m http.server): la analítica local sigue funcionando
    // igual, solo no queda también en el servidor.
  }
}

/** Se llama una vez por carga de página: equivalente a un "page view". */
function trackVisita_baycodec() {
  registrarEvento_baycodec("visita", {});
}

function reiniciarAnalitica_baycodec() {
  localStorage.removeItem(ANALITICA_CLAVE_baycodec);
}

/**
 * Calcula el resumen que vería un panel de control corporativo:
 * visitas, clics de interés, búsquedas, pedidos generados y una
 * tasa de conversión simple (pedidos / interés mostrado).
 */
function calcularResumen_baycodec() {
  const eventos = obtenerEventos_baycodec();

  const totalVisitas = eventos.filter((e) => e.tipo === "visita").length;
  const clicsWhatsApp = eventos.filter((e) => e.tipo === "clic_whatsapp");
  const clicsPrecios = eventos.filter((e) => e.tipo === "clic_precios_internacionales").length;
  const busquedas = eventos.filter((e) => e.tipo === "busqueda_catalogo").length;
  const pedidosGenerados = eventos.filter((e) => e.tipo === "pedido_generado");

  const productosConMasInteres = {};
  clicsWhatsApp.forEach((e) => {
    const nombre = e.detalle.producto || "Consulta general";
    productosConMasInteres[nombre] = (productosConMasInteres[nombre] || 0) + 1;
  });

  const valorTotalPedidos = pedidosGenerados.reduce((acc, e) => acc + (e.detalle.total || 0), 0);
  const interesTotal = clicsWhatsApp.length + clicsPrecios;
  const tasaConversion = interesTotal > 0 ? (pedidosGenerados.length / interesTotal) * 100 : 0;

  return {
    totalVisitas,
    totalClicsWhatsApp: clicsWhatsApp.length,
    clicsPrecios,
    busquedas,
    totalPedidos: pedidosGenerados.length,
    valorTotalPedidos,
    productosConMasInteres,
    tasaConversion,
    eventos,
  };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { registrarEvento_baycodec, trackVisita_baycodec, obtenerEventos_baycodec, calcularResumen_baycodec, reiniciarAnalitica_baycodec };
}
