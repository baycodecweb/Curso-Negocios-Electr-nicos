var __marca_agua_baycodec = 'baycodec'; // marca de autoria, no se usa en la logica
/* ============================================================
   RECORRIDO INTERACTIVO POR SESIONES — integrado en tienda.php
   Panel flotante que, al hacer clic en una sesión, resalta en el
   propio sitio (con un borde de color + una etiqueta) qué se le
   agregó en esa sesión. No modifica script.js ni ningún motor
   real del proyecto: es un overlay aparte, puramente aditivo.

   Adaptado de ../Recorrido-Sesiones/recorrido.js para vivir
   dentro del sitio real (Sesión 8): los selectores usan los ids
   reales con sufijo "_baycodec", y las Sesiones 3 y 7 (Mi Pedido
   y el pago) apuntan al enlace del menú + carrito.php, porque esa
   sección dejó de vivir dentro de tienda.php desde la Sesión 8
   (ver carrito.php).
   ============================================================ */
(function () {
  "use strict";

  var SESIONES = [
    {
      n: 1,
      color: "#2563eb",
      glow: "rgba(37, 99, 235, .25)",
      titulo: "Catálogo base (Sesión 1)",
      desc: "El sitio original de Grafiluz: categorías, productos y el botón de contacto directo por WhatsApp. Es el estado “As-Is” — el punto de partida sobre el que se construyen, sin romperlo, todas las sesiones siguientes.",
      selector: '[data-sesion="1"]',
      entregables: [
        { titulo: "El ADN Corporativo", desc: "Un informe ejecutivo de la empresa o tienda que se va a transformar digitalmente, justificando su viabilidad y propósito en el mercado.", archivo: "Plantilla-ADN-Corporativo.html" },
        { titulo: "Los Planos de Transformación (As-Is y To-Be)", desc: "Los diagramas de arquitectura empresarial que contrastan el estado actual (cómo opera el negocio hoy) frente al estado futuro (cómo operará 100% digitalizado e integrado usando UML o ArchiMate).", archivo: "Plantilla-Planos-Transformacion.html" }
      ]
    },
    {
      n: 2,
      color: "#0891b2",
      glow: "rgba(8, 145, 178, .25)",
      titulo: "Puente Digital (Sesión 2)",
      desc: "Conexión a una API externa de tipo de cambio: convierte los precios del catálogo a USD/EUR en tiempo real. Es E-business y no E-commerce: no vende nada por sí mismo, solo le da soporte a la venta.",
      selector: '[data-sesion="2"]',
      entregables: [
        { titulo: "La Radiografía Técnica", desc: "Un cuadro comparativo enfocado en su propio proyecto para distinguir qué procesos de su tienda son simple comercio electrónico y cuáles forman parte de la estrategia integral de e-business.", archivo: "Plantilla-Radiografia-Tecnica.html" },
        { titulo: "El Puente Digital (Prueba de Concepto / Script)", desc: "Un reporte técnico o un pequeño script documentado que demuestra cómo su tienda se conecta o podría conectarse mediante una API externa (por ejemplo, extrayendo datos de redes sociales o integrando un servicio de terceros).", archivo: "Plantilla-Reporte-Puente-Digital.html" }
      ]
    },
    {
      n: 3,
      color: "#16a34a",
      glow: "rgba(22, 163, 74, .25)",
      titulo: "Mi Pedido — modelo de datos (Sesión 3)",
      desc: "Registro de clientes y generación de pedidos sobre un modelo relacional propio (Cliente, Pedido, DetallePedido, Pago). Desde la Sesión 8 ya no es una sección de esta página: es su propia página con backend real y base de datos, carrito.php — este enlace del menú es la puerta de entrada.",
      selector: '[data-sesion="3"]',
      enlace: { href: "carrito.php", texto: "Abrir Mi Pedido ↗" },
      entregables: [
        { titulo: "La Radiografía Comercial", desc: "La definición exacta del modelo de negocio (por ejemplo, B2C) bajo el cual opera y cobra su tienda la que creará.", archivo: "Plantilla-Radiografia-Comercial.html" },
        { titulo: "El Plano Maestro de la Memoria (DER)", desc: "El Diagrama Entidad-Relación optimizado que mapea cómo viven, se relacionan y se protegen los datos (clientes, productos, pedidos, pagos) en la base de datos de su propio proyecto.", archivo: "Plantilla-Plano-Maestro-DER.html" }
      ]
    },
    {
      n: 4,
      color: "#ca8a04",
      glow: "rgba(202, 138, 4, .25)",
      titulo: "Buscador de Catálogo (Sesión 4)",
      desc: "Índice en memoria + paginación: la misma idea que usan los grandes marketplaces (eBay, Alibaba, Amazon) para no tener que redibujar miles de productos cada vez que alguien busca algo.",
      selector: '[data-sesion="4"]',
      entregables: [
        { titulo: "El Mapa Maestro (Canvas Real)", desc: "El lienzo del Modelo de Negocio adaptado 100% a la realidad de su proyecto actual, demostrando cómo su tienda genera valor, a quién le vende y cómo sustentará los costos.", archivo: "Plantilla-Mapa-Maestro-Canvas.html" },
        { titulo: "La Arquitectura del Gigante (Diseño Lógico)", desc: "Un documento técnico que demuestra cómo su plataforma escala su lógica interna —inspirada en los grandes marketplaces— para gestionar catálogos, usuarios e interacciones sin colapsar.", archivo: "Plantilla-Arquitectura-Gigante.html" }
      ]
    },
    {
      n: 5,
      color: "#9333ea",
      glow: "rgba(147, 51, 234, .25)",
      titulo: "Analítica en vivo (Sesión 5)",
      desc: "Estos elementos ya están siendo medidos de forma invisible para el visitante: cada clic de interés, búsqueda y conversión de moneda queda registrado en el Panel de Control corporativo. Los eventos de pedido y pago se registran igual, desde carrito.php.",
      selector: '.btn-whatsapp_baycodec, #pd-estado_baycodec, #bc-texto_baycodec, #bc-info-pagina_baycodec, #chatbot-mensajes_baycodec',
      enlace: { href: "panel-control.html", texto: "Ver Panel de Control ↗" },
      entregables: [
        { titulo: "El Lanzamiento Invisible (Plan de Tráfico)", desc: "Una estrategia comercial con campañas simuladas de SEO y anuncios diseñadas específicamente para el nicho de su propia tienda.", archivo: "Plantilla-Plan-de-Trafico.html" },
        { titulo: "La Tienda que Observa (Analítica en Vivo)", desc: "Demostrar que su e-commerce ya tiene inyectados los códigos de rastreo (como Google Analytics o píxeles de conversión), probando que cada clic, visita o simulación de compra queda registrada en un panel de control corporativo.", archivo: "Plantilla-Tienda-que-Observa.html" }
      ]
    },
    {
      n: 6,
      color: "#db2777",
      glow: "rgba(219, 39, 119, .25)",
      titulo: "Asistente Virtual (Sesión 6)",
      desc: "Chatbot que responde por coincidencia de palabras clave sobre una base de conocimiento (FAQ + catálogo) — una técnica real de NLP, sin depender de una API de IA de pago. Si no encuentra una respuesta, deriva a WhatsApp en vez de inventar información.",
      selector: '[data-sesion="6"]',
      enlace: { href: "admin-chatbot.html", texto: "Configurar el Asistente ↗" },
      entregables: [
        { titulo: "El Benchmark Tecnológico", desc: "Un análisis estratégico de herramientas libres de e-commerce que complementan o validan la arquitectura de su proyecto.", archivo: "Plantilla-Benchmark-Tecnologico.html" },
        { titulo: "El Asistente Virtual en Acción (IA)", desc: "La implementación técnica y funcional de un chatbot inteligente incrustado directamente en su tienda, capaz de responder preguntas frecuentes, orientar sobre el catálogo y atender usuarios en tiempo real.", archivo: "Plantilla-Asistente-Virtual.html" }
      ]
    },
    {
      n: 7,
      color: "#dc2626",
      glow: "rgba(220, 38, 38, .25)",
      titulo: "Pago con Webhook (Sesión 7)",
      desc: "El botón “Pagar” sobre el pedido ya generado: usa un sandbox con el algoritmo real de Luhn y un webhook simulado que marca el pedido como “Pagado” al instante. Está anidado dentro de “Mi Pedido”, así que desde la Sesión 8 vive en la misma página real, carrito.php.",
      selector: '[data-sesion="3"]',
      enlace: { href: "carrito.php", texto: "Ver el pago dentro de Mi Pedido ↗" },
      entregables: [
        { titulo: "La Transacción Perfecta", desc: "Demostrar en vivo una compra completa dentro de su tienda ya construida, usando credenciales de prueba (Sandbox de Stripe, PayPal o MercadoPago) donde el sistema simula un cobro exitoso.", archivo: "Plantilla-Transaccion-Perfecta.html" },
        { titulo: "El Panel de Control Inteligente", desc: "Capturas y evidencias de que el Webhook configurado respondió al instante, cambiando el estado del pedido de \"Pendiente\" a \"Pagado\" y generando el registro automático en la base de datos de su e-commerce.", archivo: "Plantilla-Panel-Control-Inteligente.html" }
      ]
    },
    {
      n: 8,
      color: "#475569",
      glow: "rgba(71, 85, 105, .25)",
      titulo: "Ética y Publicación (Sesión 8)",
      desc: "Política de Privacidad y Términos de Servicio enlazados desde el pie de página, redactados según lo que el sitio realmente hace (no son plantillas genéricas copiadas de internet). Esta misma página, con backend PHP + MySQL real, es el resultado de la Sesión 8.",
      selector: '[data-sesion="8"]',
      entregables: [
        { titulo: "La Tienda Virtual Creada y Publicada", desc: "El sitio web de comercio electrónico completamente configurado (catálogo, carrito, pasarela integrada, chatbot) y desplegado públicamente en Internet (en un servidor Cloud o entorno de pruebas real).", archivo: "Plantilla-Tienda-Publicada.html" },
        { titulo: "Informe de Ética y Ciberseguridad", desc: "Documentación de cumplimiento normativo (políticas de privacidad, términos de servicio) y verificación de seguridad básica (certificados SSL/TLS).", archivo: "Plantilla-Informe-Etica-Ciberseguridad.html" }
      ]
    }
  ];

  function limpiarResaltado() {
    var resaltados = document.querySelectorAll(".recorrido-resaltado");
    for (var i = 0; i < resaltados.length; i++) {
      resaltados[i].classList.remove("recorrido-resaltado");
      resaltados[i].style.removeProperty("--rc");
      resaltados[i].style.removeProperty("--rc-glow");
    }
    var badges = document.querySelectorAll(".recorrido-badge");
    for (var j = 0; j < badges.length; j++) {
      badges[j].remove();
    }
    var activos = document.querySelectorAll("#recorrido-panel .rec-btn.activo");
    for (var k = 0; k < activos.length; k++) {
      activos[k].classList.remove("activo");
    }
  }

  function estaVisible(el) {
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  }

  function ancestroVisible(el) {
    var actual = el;
    while (actual && actual !== document.body && !estaVisible(actual)) {
      actual = actual.parentElement;
    }
    return actual || document.body;
  }

  function resaltarSesion(s) {
    limpiarResaltado();

    var elementos = document.querySelectorAll(s.selector);
    var hayOculto = false;
    elementos.forEach(function (el) {
      el.classList.add("recorrido-resaltado");
      el.style.setProperty("--rc", s.color);
      el.style.setProperty("--rc-glow", s.glow);

      var badge = document.createElement("span");
      badge.className = "recorrido-badge";
      badge.textContent = "Sesión " + s.n;
      el.prepend(badge);

      if (!estaVisible(el)) hayOculto = true;
    });

    if (elementos.length > 0) {
      var objetivo = estaVisible(elementos[0]) ? elementos[0] : ancestroVisible(elementos[0]);
      objetivo.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    var desc = document.getElementById("rec-desc");
    if (desc) {
      var html = "<strong>" + s.titulo + "</strong><br>" + s.desc;
      if (hayOculto) {
        html += '<br><em style="color:#f59e0b">⚠ Este bloque está oculto hasta que interactúas con el sitio (por ejemplo, generar un pedido en "Mi Pedido"). Se resaltó su contenedor; ábrelo para verlo aparecer.</em>';
      }
      if (s.enlace) {
        html += '<br><a href="' + s.enlace.href + '" target="_blank" rel="noopener" style="color:#93c5fd">' + s.enlace.texto + "</a>";
      }
      if (elementos.length === 0) {
        html += '<br><em style="color:#f59e0b">No se encontró ningún elemento visible para esta sesión en la página actual.</em>';
      }
      desc.innerHTML = html;
    }

    var botones = document.querySelectorAll('#recorrido-panel .rec-btn[data-n="' + s.n + '"]');
    botones.forEach(function (b) { b.classList.add("activo"); });
  }

  function construirPanel() {
    var panel = document.createElement("div");
    panel.id = "recorrido-panel";
    panel.innerHTML =
      '<div id="rec-header"><strong>🧭 Recorrido por sesiones</strong><span id="rec-toggle">–</span></div>' +
      '<div class="rec-body">' +
        '<div id="rec-desc" class="rec-desc">Elige una sesión de la lista para ver, resaltado en el propio sitio, qué se le agregó en esa sesión.</div>' +
        '<div class="rec-lista"></div>' +
        '<button class="rec-clear" id="rec-clear" type="button">✖ Quitar resaltado</button>' +
      "</div>";
    document.body.appendChild(panel);

    var lista = panel.querySelector(".rec-lista");
    SESIONES.forEach(function (s) {
      var fila = document.createElement("div");
      fila.className = "rec-fila";

      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "rec-btn";
      btn.dataset.n = String(s.n);
      btn.innerHTML =
        '<span class="rec-dot" style="background:' + s.color + '"></span>' +
        "Sesión " + s.n + " — " + s.titulo.replace(/\s*\(Sesión \d+\)\s*$/, "");
      btn.addEventListener("click", function () { resaltarSesion(s); });
      fila.appendChild(btn);

      if (s.entregables && s.entregables.length) {
        fila.appendChild(construirEntregables(s.entregables));
      }

      lista.appendChild(fila);
    });

    panel.querySelector("#rec-clear").addEventListener("click", limpiarResaltado);

    habilitarArrastreYColapso(panel);
  }

  /**
   * Desplegable (<details>) con los 2 entregables oficiales de una
   * sesión, según el formato institucional del curso. Es puramente
   * informativo: no resalta nada en el sitio, solo documenta qué
   * debe presentar el alumno en esa sesión. Un clic en el resumen
   * no dispara resaltarSesion() porque vive fuera del <button>.
   * Cuando el entregable trae "archivo", el título es un enlace a
   * su plantilla real (copiada aquí mismo desde la carpeta de la
   * sesión correspondiente, ej. Plantilla-ADN-Corporativo.html).
   */
  function construirEntregables(entregables) {
    var detalle = document.createElement("details");
    detalle.className = "rec-entregables";

    var resumen = document.createElement("summary");
    resumen.textContent = "Entregables";
    detalle.appendChild(resumen);

    var listaEntregables = document.createElement("ol");
    entregables.forEach(function (ent) {
      var item = document.createElement("li");

      if (ent.archivo) {
        var enlaceTitulo = document.createElement("a");
        enlaceTitulo.href = ent.archivo;
        enlaceTitulo.target = "_blank";
        enlaceTitulo.rel = "noopener";
        enlaceTitulo.textContent = ent.titulo;
        item.appendChild(enlaceTitulo);
      } else {
        var fuerte = document.createElement("strong");
        fuerte.textContent = ent.titulo;
        item.appendChild(fuerte);
      }

      item.appendChild(document.createTextNode(": " + ent.desc));
      listaEntregables.appendChild(item);
    });
    detalle.appendChild(listaEntregables);

    return detalle;
  }

  /**
   * Permite mover el panel flotante arrastrándolo desde su cabecera,
   * para que el docente pueda destaparlo si tapa algo que necesita
   * mostrarle al alumno. Un clic corto en la cabecera (sin arrastrar)
   * sigue colapsando/expandiendo el panel como antes. La posición
   * elegida se recuerda entre recargas (solo en escritorio/tablet;
   * en celulares el panel se queda anclado abajo, como ya hacía).
   */
  function habilitarArrastreYColapso(panel) {
    var CLAVE_POSICION = "recorrido-panel-pos";
    var UMBRAL_ARRASTRE = 4; // px de tolerancia antes de considerarlo arrastre y no clic
    var header = panel.querySelector("#rec-header");
    var toggle = panel.querySelector("#rec-toggle");

    var arrastrando = false;
    var huboMovimiento = false;
    var offsetX = 0, offsetY = 0;
    var inicioX = 0, inicioY = 0;

    function esEscritorio() {
      return window.innerWidth > 640;
    }

    function fijarPosicion(x, y) {
      var maxX = Math.max(4, window.innerWidth - panel.offsetWidth - 4);
      var maxY = Math.max(4, window.innerHeight - panel.offsetHeight - 4);
      panel.style.left = Math.min(Math.max(x, 4), maxX) + "px";
      panel.style.top = Math.min(Math.max(y, 4), maxY) + "px";
      panel.style.right = "auto";
    }

    function guardarPosicion() {
      try {
        var rect = panel.getBoundingClientRect();
        localStorage.setItem(CLAVE_POSICION, JSON.stringify({ x: rect.left, y: rect.top }));
      } catch (e) {
        /* localStorage puede no estar disponible (modo privado); no es crítico */
      }
    }

    function iniciar(clientX, clientY) {
      if (!esEscritorio()) return;
      var rect = panel.getBoundingClientRect();
      offsetX = clientX - rect.left;
      offsetY = clientY - rect.top;
      inicioX = clientX;
      inicioY = clientY;
      arrastrando = true;
      huboMovimiento = false;
    }

    function mover(clientX, clientY) {
      if (!arrastrando) return;
      if (!huboMovimiento && (Math.abs(clientX - inicioX) > UMBRAL_ARRASTRE || Math.abs(clientY - inicioY) > UMBRAL_ARRASTRE)) {
        huboMovimiento = true;
        panel.classList.add("arrastrando");
      }
      if (huboMovimiento) fijarPosicion(clientX - offsetX, clientY - offsetY);
    }

    function soltar() {
      if (!arrastrando) return;
      arrastrando = false;
      panel.classList.remove("arrastrando");
      if (huboMovimiento) guardarPosicion();
    }

    header.addEventListener("mousedown", function (e) {
      if (e.button !== 0) return;
      iniciar(e.clientX, e.clientY);
      e.preventDefault();
    });
    window.addEventListener("mousemove", function (e) { mover(e.clientX, e.clientY); });
    window.addEventListener("mouseup", soltar);

    header.addEventListener("touchstart", function (e) {
      var t = e.touches[0];
      iniciar(t.clientX, t.clientY);
    }, { passive: true });
    window.addEventListener("touchmove", function (e) {
      if (!arrastrando) return;
      var t = e.touches[0];
      mover(t.clientX, t.clientY);
    }, { passive: true });
    window.addEventListener("touchend", soltar);

    header.addEventListener("click", function () {
      if (huboMovimiento) {
        huboMovimiento = false;
        return;
      }
      panel.classList.toggle("colapsado");
      toggle.textContent = panel.classList.contains("colapsado") ? "+" : "–";
    });

    window.addEventListener("resize", function () {
      if (!esEscritorio()) {
        panel.style.left = "";
        panel.style.top = "";
        panel.style.right = "";
      } else if (panel.style.left) {
        var rect = panel.getBoundingClientRect();
        fijarPosicion(rect.left, rect.top);
      }
    });

    try {
      var guardada = JSON.parse(localStorage.getItem(CLAVE_POSICION) || "null");
      if (guardada && esEscritorio()) fijarPosicion(guardada.x, guardada.y);
    } catch (e) {
      /* ignorar posición guardada inválida */
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", construirPanel);
  } else {
    construirPanel();
  }
})();
